-- ==============================================================================
-- MediVoice AI - MySQL Database Initialization Script
-- Compatible with MySQL Server 8.0+, 9.0+, 26.7+ & MySQL Workbench
-- ==============================================================================

CREATE DATABASE IF NOT EXISTS medvoice_db 
CHARACTER SET utf8mb4 
COLLATE utf8mb4_unicode_ci;

USE medvoice_db;

-- 1. USERS TABLE
CREATE TABLE IF NOT EXISTS users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    created_at VARCHAR(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2. USER_PROFILE TABLE
CREATE TABLE IF NOT EXISTS user_profile (
    profile_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL UNIQUE,
    name VARCHAR(150) NOT NULL,
    gender VARCHAR(30) NOT NULL,
    age INT NOT NULL,
    height DOUBLE NOT NULL,
    weight DOUBLE NOT NULL,
    blood_group VARCHAR(10),
    emergency_contact VARCHAR(150),
    contact_phone VARCHAR(50),
    CONSTRAINT fk_profile_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 3. SYMPTOM_SESSION TABLE
CREATE TABLE IF NOT EXISTS symptom_session (
    session_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    input_text TEXT NOT NULL,
    language VARCHAR(20) NOT NULL,
    created_at VARCHAR(50) NOT NULL,
    CONSTRAINT fk_session_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 4. SYMPTOM TABLE
CREATE TABLE IF NOT EXISTS symptom (
    symptom_id INT AUTO_INCREMENT PRIMARY KEY,
    session_id INT NOT NULL,
    name VARCHAR(150) NOT NULL,
    severity VARCHAR(30) NOT NULL,
    duration_days INT NOT NULL,
    body_part VARCHAR(100),
    is_red_flag TINYINT(1) NOT NULL DEFAULT 0,
    CONSTRAINT fk_symptom_session FOREIGN KEY (session_id) REFERENCES symptom_session(session_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 5. TRIAGE_RESULT TABLE
CREATE TABLE IF NOT EXISTS triage_result (
    result_id INT AUTO_INCREMENT PRIMARY KEY,
    session_id INT NOT NULL UNIQUE,
    urgency VARCHAR(30) NOT NULL,
    recommendation TEXT NOT NULL,
    department VARCHAR(150) NOT NULL,
    reason TEXT NOT NULL,
    rule_matched VARCHAR(100),
    confidence_score DOUBLE NOT NULL,
    speech_response TEXT NOT NULL,
    created_at VARCHAR(50) NOT NULL,
    CONSTRAINT fk_triage_session FOREIGN KEY (session_id) REFERENCES symptom_session(session_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 6. CHAT_SESSION TABLE
CREATE TABLE IF NOT EXISTS chat_session (
    chat_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    language VARCHAR(20) NOT NULL,
    created_at VARCHAR(50) NOT NULL,
    CONSTRAINT fk_chat_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 7. CHAT_MESSAGE TABLE
CREATE TABLE IF NOT EXISTS chat_message (
    message_id INT AUTO_INCREMENT PRIMARY KEY,
    chat_id INT NOT NULL,
    sender VARCHAR(20) NOT NULL,
    message TEXT NOT NULL,
    intent VARCHAR(50) NOT NULL,
    created_at VARCHAR(50) NOT NULL,
    CONSTRAINT fk_msg_session FOREIGN KEY (chat_id) REFERENCES chat_session(chat_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 8. FOOD_PLAN TABLE
CREATE TABLE IF NOT EXISTS food_plan (
    plan_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    query VARCHAR(255) NOT NULL,
    meal_type VARCHAR(50) NOT NULL,
    plan_text TEXT NOT NULL,
    calories_target INT NOT NULL,
    dietary_advice TEXT,
    created_at VARCHAR(50) NOT NULL,
    CONSTRAINT fk_food_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 9. MEDICAL_RECORD TABLE
CREATE TABLE IF NOT EXISTS medical_record (
    record_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    type VARCHAR(50) NOT NULL,
    file_name VARCHAR(255) NOT NULL,
    file_path VARCHAR(500) NOT NULL,
    file_size BIGINT NOT NULL,
    upload_date VARCHAR(50) NOT NULL,
    description TEXT,
    CONSTRAINT fk_record_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 10. FIRST_AID_GUIDE TABLE
CREATE TABLE IF NOT EXISTS first_aid_guide (
    guide_id INT AUTO_INCREMENT PRIMARY KEY,
    scenario VARCHAR(50) NOT NULL UNIQUE,
    title VARCHAR(150) NOT NULL,
    language VARCHAR(20) NOT NULL,
    steps TEXT NOT NULL,
    red_flags TEXT NOT NULL,
    escalation TEXT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 11. SOS_EVENT TABLE
CREATE TABLE IF NOT EXISTS sos_event (
    sos_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    timestamp VARCHAR(50) NOT NULL,
    location VARCHAR(255) NOT NULL,
    contact VARCHAR(150) NOT NULL,
    phone VARCHAR(50) NOT NULL,
    status VARCHAR(50) NOT NULL,
    notes TEXT,
    CONSTRAINT fk_sos_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 12. MEDICATION TABLE
CREATE TABLE IF NOT EXISTS medication (
    medication_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    medicine_name VARCHAR(150) NOT NULL,
    dosage VARCHAR(100) NOT NULL,
    frequency VARCHAR(100) NOT NULL,
    instructions TEXT,
    created_at VARCHAR(50) NOT NULL,
    CONSTRAINT fk_med_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 13. REMINDER TABLE
CREATE TABLE IF NOT EXISTS reminder (
    reminder_id INT AUTO_INCREMENT PRIMARY KEY,
    medication_id INT NOT NULL,
    medicine_name VARCHAR(150) NOT NULL,
    dosage VARCHAR(100) NOT NULL,
    reminder_time VARCHAR(10) NOT NULL,
    frequency VARCHAR(50) NOT NULL,
    active TINYINT(1) NOT NULL DEFAULT 1,
    last_triggered VARCHAR(50),
    CONSTRAINT fk_reminder_med FOREIGN KEY (medication_id) REFERENCES medication(medication_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ==============================================================================
-- INITIAL SEED DATA
-- ==============================================================================

-- Seed Demo User (password: password123)
-- SHA-256 hash using salt "MedVoiceAssistant_Secure_Salt_2026"
INSERT IGNORE INTO users (user_id, username, password_hash, created_at)
VALUES (1, 'kaviya', '6048d085601a4e5114c5b3c58b543c7bba44b9b00da0ea903ae4aeb1f48624df', '2026-10-17 18:30:00');

-- Seed Patient Profile for Kaviyadharshini N
INSERT IGNORE INTO user_profile (profile_id, user_id, name, gender, age, height, weight, blood_group, emergency_contact, contact_phone)
VALUES (1, 1, 'Kaviyadharshini N', 'Female', 21, 165.0, 56.0, 'O+', 'Family Contact', '+91 98765 43210');

-- Seed Demo Medications
INSERT IGNORE INTO medication (medication_id, user_id, medicine_name, dosage, frequency, instructions, created_at)
VALUES 
(1, 1, 'Paracetamol', '500 mg', 'Twice daily', 'Take with full glass of water after food', '2026-10-17 18:30:00'),
(2, 1, 'Vitamin D3', '1000 IU', 'Once daily', 'Take in morning with breakfast', '2026-10-17 18:30:00');

-- Seed Medication Reminders
INSERT IGNORE INTO reminder (reminder_id, medication_id, medicine_name, dosage, reminder_time, frequency, active, last_triggered)
VALUES 
(1, 1, 'Paracetamol', '500 mg', '09:00', 'DAILY', 1, NULL),
(2, 1, 'Paracetamol', '500 mg', '21:00', 'DAILY', 1, NULL),
(3, 2, 'Vitamin D3', '1000 IU', '08:30', 'DAILY', 1, NULL);

-- Seed Validated First-Aid Guides
INSERT IGNORE INTO first_aid_guide (scenario, title, language, steps, red_flags, escalation)
VALUES 
(
    'MINOR_CUT',
    'Minor Cut or Scratch',
    'en',
    '1. Wash hands with soap and water before touching wound.\n2. Apply gentle pressure with a clean cloth or sterile gauze for 2-3 minutes to stop bleeding.\n3. Rinse wound gently under cool running tap water.\n4. Clean skin around wound with soap; do not get soap directly in deep wound.\n5. Apply a thin layer of antibacterial ointment or petroleum jelly.\n6. Cover with a sterile adhesive bandage.',
    '- Bleeding does not stop after 10 minutes of direct firm pressure\n- Cut is deep, gaping, or shows fat/muscle\n- Object is embedded in the wound\n- Dirt or debris cannot be washed out\n- Animal or human bite\n- Signs of infection: increasing redness, warmth, pus, or fever',
    'Seek immediate urgent care or emergency room if bleeding spurts or cannot be controlled.'
),
(
    'MINOR_BURN',
    'Minor First & Second Degree Burn',
    'en',
    '1. Immediately cool the burn under gentle, cool running water for 10-15 minutes. (Do NOT use ice, butter, or toothpaste).\n2. Gently remove jewelry, rings, or tight clothing around the burned area before swelling starts.\n3. Do NOT pop or break any blisters that form.\n4. Apply pure aloe vera gel or soothing burn moisturizer.\n5. Protect loosely with a sterile non-stick bandage or clean cling wrap.\n6. Take mild pain relief such as paracetamol or ibuprofen if needed.',
    '- Burn covers face, hands, joints, groin, or large body area\n- Skin appears charred, white, leathery, or blackened (third-degree)\n- Chemical or electrical burn\n- Inhalation of smoke or difficulty breathing\n- Burned victim is an infant or elderly person',
    'Immediately call Emergency Services (108/911/112) or go to the nearest Burn Emergency Department.'
),
(
    'NOSEBLEED',
    'Nosebleed (Epistaxis)',
    'en',
    '1. Sit upright and lean slightly forward (Do NOT lean head back, as blood may drain into throat).\n2. Pinch the soft part of the nostrils together firmly using your thumb and index finger.\n3. Breathe gently through your mouth.\n4. Maintain firm pressure continuously for 10 full minutes without releasing to check.\n5. Apply an ice pack or cold damp cloth across the bridge of the nose.\n6. Avoid blowing nose or strenuous activity for several hours afterward.',
    '- Bleeding continues for more than 20 minutes despite continuous pinching\n- Nosebleed was caused by severe head or facial trauma\n- Patient feels dizzy, lightheaded, faint, or disoriented\n- Very heavy blood loss or coughing up substantial blood\n- Patient is on blood thinners (anticoagulants)',
    'Proceed immediately to the Emergency Room if bleeding does not halt after 20 minutes.'
),
(
    'SPRAIN',
    'Joint Sprain / Muscle Strain',
    'en',
    'Follow the proven R.I.C.E. protocol:\n1. REST: Stop the activity immediately and avoid putting weight on the injured limb.\n2. ICE: Apply an ice pack wrapped in a damp towel for 15-20 minutes every 2-3 hours for the first 48 hours.\n3. COMPRESSION: Wrap the area with an elastic bandage snugly, but not so tight as to restrict blood circulation.\n4. ELEVATION: Keep the injured joint raised above heart level whenever resting to reduce swelling.',
    '- Inability to bear any weight or walk even a few steps\n- Severe deformity or visible bone displacement\n- Numbness, tingling, or coldness in toes or fingers\n- Severe pain directly over the bone\n- Audible popping or cracking sound during injury',
    'Visit an orthopedic urgent care clinic or emergency facility for an X-ray to rule out fracture.'
),
(
    'CHOKING',
    'Choking in Conscious Adult / Child',
    'en',
    '1. If person can cough forcefully or speak, encourage them to keep coughing.\n2. If person cannot breathe, speak, or make sound (universal sign of choking):\n3. Stand behind the person and lean them slightly forward.\n4. Deliver 5 sharp back blows between shoulder blades using the heel of your hand.\n5. If still choking, perform 5 abdominal thrusts (Heimlich Maneuver): Make a fist above navel, grasp with other hand, pull inward and upward sharply.\n6. Alternate 5 back blows and 5 abdominal thrusts until object is expelled.',
    '- Person turns blue, loses consciousness, or stops breathing\n- Victim is unable to make any vocal sound',
    'Call 108 / 911 / 112 immediately. If the person loses consciousness, lower them to the floor and begin CPR chest compressions.'
),
(
    'FAINTING',
    'Fainting / Syncope',
    'en',
    '1. If someone feels dizzy, help them lie down flat on their back immediately.\n2. Elevate their legs about 12 inches (30 cm) above heart level to restore blood flow to the brain.\n3. Loosen tight collars, belts, or restrictive clothing.\n4. Ensure fresh airflow; open windows or use a fan.\n5. Check responsiveness and breathing.\n6. Once awake, do not let them stand up rapidly. Offer small sips of cool water or fruit juice.',
    '- Person remains unconscious for more than 1 minute\n- Fainting was preceded by chest pain, heart palpitations, or shortness of breath\n- Person hit their head violently during the fall\n- Confusion or speech difficulty after waking\n- Seizure-like convulsions or loss of bladder/bowel control',
    'Call emergency medical assistance immediately if unconsciousness persists or if accompanied by chest pain.'
),
(
    'INSECT_BITE',
    'Insect Sting & Spider Bite',
    'en',
    '1. If a bee stinger is left in the skin, scrape it off immediately with a credit card or fingernail (do not squeeze the venom sac with tweezers).\n2. Wash the area thoroughly with soap and water.\n3. Apply a cold compress or ice pack wrapped in a cloth for 10 minutes at a time.\n4. Apply 1% hydrocortisone cream, calamine lotion, or baking soda paste to relieve itch.\n5. Take an oral antihistamine (e.g., Cetirizine) for itching and swelling.',
    '- Difficulty breathing, wheezing, or tightness in chest\n- Swelling of lips, tongue, throat, or entire face\n- Dizziness, confusion, or fainting\n- Generalized hives or widespread skin rash\n- Nausea, abdominal cramps, or vomiting (Signs of Anaphylaxis)',
    'ANAPHYLAXIS EMERGENCY: Administer Epinephrine auto-injector (EpiPen) if available into outer thigh and call 108 / 911 / 112 immediately.'
);
