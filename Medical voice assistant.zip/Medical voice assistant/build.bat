@echo off
echo ===============================================================
echo  Building MediVoice AI - Medical Voice Assistant
echo ===============================================================
if not exist bin mkdir bin
if not exist uploads mkdir uploads

echo Compiling Java source files...
python -c "import os, subprocess; jfs=[os.path.join(r, f).replace('\\', '/') for r, d, fs in os.walk('src/main/java') for f in fs if f.endswith('.java')]; open('sources.txt', 'w', encoding='utf-8').write('\n'.join(jfs)); subprocess.run(['javac', '-encoding', 'UTF-8', '-cp', 'lib/*', '-d', 'bin', '@sources.txt'], check=True)"

if %ERRORLEVEL% NEQ 0 (
    echo Compilation failed!
    pause
    exit /b %ERRORLEVEL%
)

echo.
echo Build successful! Starting application...
java -cp "bin;lib/*" com.medvoiceassistant.Main
