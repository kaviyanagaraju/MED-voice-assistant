/**
 * MediVoice AI - Universal Speech Processing & Natural Voice Synthesis Module
 * Supports all 20 clinical languages:
 * English, Tamil, Hindi, Telugu, Kannada, Malayalam, Bengali, Marathi, Urdu,
 * Arabic, Russian, Japanese, Korean, Chinese, Thai, Spanish, Portuguese, French, German, Italian.
 * 
 * Features:
 * - Dual Engine: High-fidelity natural audio streaming + Web Speech API fallback
 * - Global Voice Mute & Unmute controls with persistence
 * - Speech-to-Text input with real-time feedback
 */

class SpeechManager {
  constructor() {
    this.recognition = null;
    this.isListening = false;
    this.synthesis = window.speechSynthesis;
    this.currentLanguage = 'en-US';
    this.activeVoice = null;
    this.isSpeakingNow = false;
    this.speechRate = 0.92;
    this.speechPitch = 1.0;
    this.currentAudio = null;
    this.listeners = [];
    this.speechStateListeners = [];

    // Persisted Mute State (default: false / unmuted)
    this.isMuted = localStorage.getItem('medivoice_voice_muted') === 'true';

    this.initSpeechRecognition();
    this.loadVoices();

    if (this.synthesis && this.synthesis.onvoiceschanged !== undefined) {
      this.synthesis.onvoiceschanged = () => this.loadVoices();
    }
  }

  onMuteChange(callback) {
    if (typeof callback === 'function') {
      this.listeners.push(callback);
    }
  }

  onSpeechStateChange(callback) {
    if (typeof callback === 'function') {
      this.speechStateListeners.push(callback);
      try { callback(this.isSpeaking()); } catch (e) {}
    }
  }

  notifyStateListeners(isPlaying) {
    this.speechStateListeners.forEach(cb => {
      try { cb(isPlaying); } catch (e) { console.error(e); }
    });
  }

  isVoiceMuted() {
    return this.isMuted;
  }

  toggleMute(forceState) {
    if (typeof forceState === 'boolean') {
      this.isMuted = forceState;
    } else {
      this.isMuted = !this.isMuted;
    }

    localStorage.setItem('medivoice_voice_muted', this.isMuted ? 'true' : 'false');
    
    if (this.isMuted) {
      this.stopSpeaking();
    }

    this.listeners.forEach(cb => {
      try { cb(this.isMuted); } catch (e) { console.error(e); }
    });

    return this.isMuted;
  }

  setSpeed(rate) {
    this.speechRate = parseFloat(rate) || 0.92;
  }

  initSpeechRecognition() {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (SpeechRecognition) {
      this.recognition = new SpeechRecognition();
      this.recognition.continuous = false;
      this.recognition.interimResults = true;
      this.recognition.lang = this.currentLanguage;
    } else {
      console.warn("Speech Recognition API not supported natively in this browser.");
    }
  }

  setLanguage(langCode) {
    this.stopSpeaking();
    const langMap = {
      'en': 'en-US',
      'ta': 'ta-IN',
      'hi': 'hi-IN',
      'te': 'te-IN',
      'kn': 'kn-IN',
      'ml': 'ml-IN',
      'bn': 'bn-IN',
      'mr': 'mr-IN',
      'ur': 'ur-PK',
      'ar': 'ar-SA',
      'ru': 'ru-RU',
      'ja': 'ja-JP',
      'ko': 'ko-KR',
      'zh': 'zh-CN',
      'th': 'th-TH',
      'es': 'es-ES',
      'pt': 'pt-PT',
      'fr': 'fr-FR',
      'de': 'de-DE',
      'it': 'it-IT',
      'auto': 'en-US'
    };
    this.currentLanguage = langMap[langCode] || 'en-US';
    if (this.recognition) {
      this.recognition.lang = this.currentLanguage;
    }
    this.loadVoices();
  }

  startListening(onResult, onStatusChange) {
    if (!this.recognition) {
      if (onStatusChange) onStatusChange('not_supported');
      return false;
    }

    if (this.isListening) {
      this.stopListening();
      return false;
    }

    try {
      this.recognition.onstart = () => {
        this.isListening = true;
        if (onStatusChange) onStatusChange('listening');
      };

      this.recognition.onresult = (event) => {
        let transcript = '';
        for (let i = event.resultIndex; i < event.results.length; ++i) {
          transcript += event.results[i][0].transcript;
        }
        if (onResult) onResult(transcript, event.results[0].isFinal);
      };

      this.recognition.onerror = (event) => {
        console.warn("Speech recognition error:", event.error);
        this.isListening = false;
        if (onStatusChange) onStatusChange('error', event.error);
      };

      this.recognition.onend = () => {
        this.isListening = false;
        if (onStatusChange) onStatusChange('idle');
      };

      this.recognition.start();
      return true;
    } catch (e) {
      console.error("Failed to start speech recognition:", e);
      this.isListening = false;
      if (onStatusChange) onStatusChange('error', e.message);
      return false;
    }
  }

  stopListening() {
    if (this.recognition && this.isListening) {
      this.recognition.stop();
      this.isListening = false;
    }
  }

  hasNativeVoiceForLang(langPrefix) {
    if (!this.synthesis) return false;
    const voices = this.synthesis.getVoices() || [];
    const prefix = (langPrefix || '').substring(0, 2).toLowerCase();
    return voices.some(v => (v.lang || '').replace('_', '-').toLowerCase().startsWith(prefix));
  }

  selectBestVoice(targetLang) {
    if (!this.synthesis) return null;
    const voices = this.synthesis.getVoices();
    if (!voices || voices.length === 0) return null;

    const prefix = targetLang.substring(0, 2).toLowerCase();
    const cleanTarget = targetLang.replace('_', '-').toLowerCase();

    let bestVoice = null;
    let bestScore = -9999;

    for (const v of voices) {
      const vLang = (v.lang || '').replace('_', '-').toLowerCase();
      const name = (v.name || '').toLowerCase();
      let score = 0;

      // Strict matching for target language
      if (vLang === cleanTarget) {
        score += 100;
      } else if (vLang.startsWith(prefix)) {
        score += 60;
      } else {
        continue;
      }

      // Quality & naturalness scoring (prioritize smooth neural voices)
      if (name.includes('natural')) score += 80;
      if (name.includes('neural')) score += 75;
      if (name.includes('google')) score += 65;
      if (name.includes('online')) score += 50;
      if (name.includes('premium')) score += 40;

      if (name.includes('jenny') || name.includes('zira') || name.includes('neerja') ||
          name.includes('swara') || name.includes('pallavi') || name.includes('aria') ||
          name.includes('heera') || name.includes('shruti') || name.includes('pooja') ||
          name.includes('kalpana') || name.includes('hemant')) {
        score += 35;
      }

      // Penalize robotic legacy synthesizers
      if (name.includes('desktop') && name.includes('david')) score -= 50;
      if (name.includes('espeak')) score -= 60;

      if (score > bestScore) {
        bestScore = score;
        bestVoice = v;
      }
    }

    return bestVoice;
  }

  loadVoices() {
    if (!this.synthesis) return;
    this.activeVoice = this.selectBestVoice(this.currentLanguage);
  }

  cleanSpeechText(text, langCode) {
    if (!text) return '';
    let cleaned = text;

    // Remove emojis so TTS voices don't get confused
    cleaned = cleaned.replace(/[\u{1F300}-\u{1F9FF}\u{2600}-\u{26FF}\u{2700}-\u{27BF}]/gu, '');

    // Remove markdown symbols (bold, headings, bullet asterisks, backticks)
    cleaned = cleaned.replace(/[*#_`~>]+/g, ' ');

    // For non-English languages, remove parenthetical English translations like (Gynecology & Women's Health)
    if (langCode && !langCode.startsWith('en')) {
      cleaned = cleaned.replace(/\s*\([A-Za-z0-9\s&,/\\-–—]+\)/g, '');
    }

    // Remove extra whitespace
    return cleaned.replace(/\s{2,}/g, ' ').trim();
  }

  /**
   * Main Speak Method
   * Respects global mute switch and uses high-fidelity natural audio for all languages
   */
  speak(text, onComplete, overrideLang, force = false) {
    // 1. Check if user turned off voice narration (unless forced by explicit click)
    if (!force && this.isMuted) {
      console.log("Speech skipped: voice narration is muted.");
      this.isSpeakingNow = false;
      if (onComplete) onComplete();
      return;
    }

    if (!text) {
      this.isSpeakingNow = false;
      if (onComplete) onComplete();
      return;
    }

    // Cancel any previous speech
    this.stopSpeaking();
    this.isSpeakingNow = true;

    const langMap = {
      'en': 'en-US',
      'ta': 'ta-IN',
      'hi': 'hi-IN',
      'te': 'te-IN',
      'kn': 'kn-IN',
      'ml': 'ml-IN',
      'bn': 'bn-IN',
      'mr': 'mr-IN',
      'ur': 'ur-PK',
      'ar': 'ar-SA',
      'ru': 'ru-RU',
      'ja': 'ja-JP',
      'ko': 'ko-KR',
      'zh': 'zh-CN',
      'th': 'th-TH',
      'es': 'es-ES',
      'pt': 'pt-PT',
      'fr': 'fr-FR',
      'de': 'de-DE',
      'it': 'it-IT'
    };

    let targetLang = this.currentLanguage;
    if (overrideLang && langMap[overrideLang]) {
      targetLang = langMap[overrideLang];
    } else if (overrideLang && overrideLang.includes('-')) {
      targetLang = overrideLang;
    } else if (overrideLang && overrideLang.length === 2) {
      targetLang = langMap[overrideLang] || 'en-US';
    }

    const shortCode = targetLang.substring(0, 2).toLowerCase();
    const cleanedText = this.cleanSpeechText(text, shortCode);

    if (!cleanedText) {
      this.isSpeakingNow = false;
      if (onComplete) onComplete();
      return;
    }

    // Check if the browser actually has a high-quality native voice matching the language
    const nativeVoice = this.selectBestVoice(targetLang);

    // If it's English and a good native voice exists, Web Speech API is fast and smooth:
    if (shortCode === 'en' && nativeVoice) {
      this.speakWithBrowserSynthesis(cleanedText, targetLang, nativeVoice, onComplete);
      return;
    }

    // For all regional languages (Telugu, Tamil, Kannada, Malayalam, Bengali, Hindi, etc.)
    // or if no native voice was found in browser: stream Google's authentic neural voice!
    this.speakWithAudioStream(cleanedText, shortCode, onComplete, () => {
      // Fallback to browser synthesis ONLY IF a genuine native voice exists for this language!
      // NEVER use an English voice to speak an Indian regional language!
      if (nativeVoice && (nativeVoice.lang || '').toLowerCase().startsWith(shortCode)) {
        this.speakWithBrowserSynthesis(cleanedText, targetLang, nativeVoice, onComplete);
      } else {
        console.warn("No native voice installed for " + shortCode + "; avoiding robotic English fallback.");
        this.isSpeakingNow = false;
        this.notifyStateListeners(false);
        if (onComplete) onComplete();
      }
    });
  }

  speakWithAudioStream(text, langCode, onComplete, onFallback) {
    try {
      this.stopSpeaking();
      this.isSpeakingNow = true;
      this.notifyStateListeners(true);

      const url = `/api/tts?lang=${encodeURIComponent(langCode)}&text=${encodeURIComponent(text)}`;
      const audio = new Audio(url);
      audio.playbackRate = 0.94; // Optimized cadence and modulation for medical clarity
      this.currentAudio = audio;

      let finished = false;
      const finish = () => {
        if (finished) return;
        finished = true;
        this.isSpeakingNow = false;
        this.currentAudio = null;
        this.notifyStateListeners(false);
        if (onComplete) onComplete();
      };

      audio.onended = finish;
      audio.onerror = (e) => {
        console.warn("TTS audio stream error, invoking fallback:", e);
        this.currentAudio = null;
        this.isSpeakingNow = false;
        this.notifyStateListeners(false);
        if (onFallback) {
          onFallback();
        } else {
          finish();
        }
      };

      const playPromise = audio.play();
      if (playPromise !== undefined) {
        playPromise.catch(e => {
          console.warn("Audio play rejected (possible autoplay restriction):", e);
          this.currentAudio = null;
          this.isSpeakingNow = false;
          this.notifyStateListeners(false);
          if (onFallback) {
            onFallback();
          } else {
            finish();
          }
        });
      }
    } catch (err) {
      console.error("Audio stream exception:", err);
      this.isSpeakingNow = false;
      this.notifyStateListeners(false);
      if (onFallback) onFallback();
      else if (onComplete) onComplete();
    }
  }

  speakWithBrowserSynthesis(text, targetLang, voice, onComplete) {
    if (!this.synthesis) {
      this.isSpeakingNow = false;
      this.notifyStateListeners(false);
      if (onComplete) onComplete();
      return;
    }

    try {
      this.isSpeakingNow = true;
      this.notifyStateListeners(true);

      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = targetLang;
      if (voice) {
        utterance.voice = voice;
      }

      utterance.rate = this.speechRate || 0.92;
      utterance.pitch = this.speechPitch || 1.0;

      let finished = false;
      const finish = () => {
        if (finished) return;
        finished = true;
        this.isSpeakingNow = false;
        this.notifyStateListeners(false);
        if (onComplete) onComplete();
      };

      utterance.onend = finish;
      utterance.onerror = (e) => {
        console.warn("Browser SpeechSynthesis Error:", e);
        finish();
      };

      this.synthesis.speak(utterance);
    } catch (e) {
      console.error("Browser synthesis failed:", e);
      this.isSpeakingNow = false;
      this.notifyStateListeners(false);
      if (onComplete) onComplete();
    }
  }

  stopSpeaking() {
    this.isSpeakingNow = false;
    if (this.currentAudio) {
      try {
        this.currentAudio.pause();
        this.currentAudio.currentTime = 0;
        this.currentAudio.removeAttribute('src');
        this.currentAudio.load();
      } catch (ignored) {}
      this.currentAudio = null;
    }
    if (this.synthesis) {
      try {
        this.synthesis.cancel();
      } catch (ignored) {}
    }
    this.notifyStateListeners(false);
  }

  isSpeaking() {
    return this.isSpeakingNow || (this.currentAudio && !this.currentAudio.paused && !this.currentAudio.ended) || (this.synthesis && (this.synthesis.speaking || this.synthesis.pending));
  }
}

// Global instance
window.speechManager = new SpeechManager();
