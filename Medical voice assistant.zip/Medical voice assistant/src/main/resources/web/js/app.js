/**
 * MediVoice AI - Main Application Controller
 */

const API_BASE = '';
let currentUserId = 1;
let currentChatId = 0;
let lastTriageResult = null;
let sosCountdownTimer = null;
let countdownRemaining = 3;

document.addEventListener('DOMContentLoaded', () => {
  initNavigation();
  initVoiceToggle();
  initVoiceTriage();
  initChatbot();
  initFirstAid();
  initFoodPlan();
  initMedications();
  initRecords();
  initProfile();
  initSOSModal();
  startReminderPoller();
});

// ============================================================================
// 1. Navigation & Global Controls
// ============================================================================

function initNavigation() {
  const tabs = document.querySelectorAll('.nav-tab');
  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      const target = tab.dataset.tab;
      switchTab(target);
    });
  });

  const langSelect = document.getElementById('globalLanguageSelect');
  if (langSelect) {
    langSelect.addEventListener('change', (e) => {
      const selected = e.target.value;
      window.speechManager.setLanguage(selected);
      if (typeof window.applyDashboardLanguage === 'function') {
        window.applyDashboardLanguage(selected);
      }
      localStorage.setItem('medivoice_selected_lang', selected);
      window.speechManager.stopSpeaking();
      updateReadAloudBtnState(false);
      if (typeof window.updateVoiceUI === 'function') {
        window.updateVoiceUI(window.speechManager.isVoiceMuted());
      }
      if (typeof renderFirstAidGuides === 'function') {
        renderFirstAidGuides(selected);
      }
      if (lastTriageResult) {
        renderTriageOutcome(lastTriageResult);
      }
    });

    // Restore saved language preference on initial load
    const savedLang = localStorage.getItem('medivoice_selected_lang');
    if (savedLang && langSelect.querySelector(`option[value="${savedLang}"]`)) {
      langSelect.value = savedLang;
      window.speechManager.setLanguage(savedLang);
      if (typeof window.applyDashboardLanguage === 'function') {
        window.applyDashboardLanguage(savedLang);
      }
      if (typeof window.updateVoiceUI === 'function') {
        window.updateVoiceUI(window.speechManager.isVoiceMuted());
      }
      if (typeof renderFirstAidGuides === 'function') {
        renderFirstAidGuides(savedLang);
      }
    }
  }

  const profileBadge = document.getElementById('headerProfileBadge');
  if (profileBadge) {
    profileBadge.addEventListener('click', () => switchTab('profile'));
  }
}

function switchTab(tabId) {
  document.querySelectorAll('.nav-tab').forEach(t => {
    t.classList.toggle('active', t.dataset.tab === tabId);
  });

  document.querySelectorAll('.tab-pane').forEach(p => {
    p.classList.toggle('active', p.id === `tab-${tabId}`);
  });

  if (tabId === 'history') {
    loadClinicalHistory();
  } else if (tabId === 'medication') {
    loadMedications();
    loadReminders();
  } else if (tabId === 'records') {
    loadRecords();
  } else if (tabId === 'firstaid') {
    loadFirstAidGuides();
  }
}

// ============================================================================
// 1.5. Voice Narration Audio Toggle (Global & Chatbot)
// ============================================================================

function getVoiceToggleLabels(lang, isMuted) {
  const l = (lang || 'en').substring(0, 2).toLowerCase();
  const dict = {
    'ta': { on: 'குரல்: ஆன்', off: 'குரல்: ஆஃப்', chatOn: 'சாட்பாட் குரல்: ஆன்', chatOff: 'சாட்பாட் குரல்: ஆஃப்' },
    'te': { on: 'వాయిస్: ఆన్', off: 'వాయిస్: ఆఫ్', chatOn: 'చాట్‌బాట్ వాయిస్: ఆన్', chatOff: 'చాట్‌బాట్ వాయిస్: ఆఫ్' },
    'hi': { on: 'आवाज़: चालू', off: 'आवाज़: बंद', chatOn: 'चैटबॉट आवाज़: चालू', chatOff: 'चैटबॉट आवाज़: बंद' },
    'kn': { on: 'ಧ್ವನಿ: ಆನ್', off: 'ಧ್ವನಿ: ಆಫ್', chatOn: 'ಚಾಟ್‌ಬಾಟ್ ಧ್ವನಿ: ಆನ್', chatOff: 'ಚಾಟ್‌ಬಾಟ್ ಧ್ವನಿ: ಆಫ್' },
    'ml': { on: 'ശബ്ദം: ഓൺ', off: 'ശബ്ദം: ഓഫ്', chatOn: 'ചാറ്റ്ബോട്ട് ശബ്ദം: ഓൺ', chatOff: 'ചാറ്റ്ബോട്ട് ശബ്ദം: ഓഫ്' },
    'bn': { on: 'ভয়েস: অন', off: 'ভয়েস: অফ', chatOn: 'চ্যাটবট ভয়েস: অন', chatOff: 'চ্যাটবট ভয়েস: অফ' },
    'mr': { on: 'आवाज: सुरू', off: 'आवाज: बंद', chatOn: 'चॅटबॉट आवाज: सुरू', chatOff: 'चॅटबॉट आवाज: बंद' },
    'ur': { on: 'آواز: آن', off: 'آواز: بند', chatOn: 'چیٹ بوٹ آواز: آن', chatOff: 'چیٹ بوٹ آواز: بند' },
    'ar': { on: 'الصوت: تشغيل', off: 'الصوت: إيقاف', chatOn: 'صوت المحادثة: تشغيل', chatOff: 'صوت المحادثة: إيقاف' },
    'es': { on: 'Voz: ON', off: 'Voz: OFF', chatOn: 'Voz Chat: ON', chatOff: 'Voz Chat: OFF' },
    'fr': { on: 'Voix: ACTIVÉE', off: 'Voix: DÉSACTIVÉE', chatOn: 'Voix Chat: ON', chatOff: 'Voix Chat: OFF' },
    'de': { on: 'Stimme: AN', off: 'Stimme: AUS', chatOn: 'Chatbot-Stimme: AN', chatOff: 'Chatbot-Stimme: AUS' },
    'ru': { on: 'Голос: ВКЛ', off: 'Голос: ВЫКЛ', chatOn: 'Голос чата: ВКЛ', chatOff: 'Голос чата: ВЫКЛ' },
    'ja': { on: '音声: オン', off: '音声: オフ', chatOn: 'チャット音声: オン', chatOff: 'チャット音声: オフ' },
    'zh': { on: '语音: 开启', off: '语音: 关闭', chatOn: '聊天语音: 开启', chatOff: '聊天语音: 关闭' }
  };
  const labels = dict[l] || { on: 'Voice: ON', off: 'Voice: OFF', chatOn: 'Chatbot Voice: ON', chatOff: 'Chatbot Voice: OFF' };
  return {
    text: isMuted ? labels.off : labels.on,
    chatText: isMuted ? labels.chatOff : labels.chatOn
  };
}

function updateVoiceUI(isMuted) {
  const globalBtn = document.getElementById('globalVoiceToggleBtn');
  const chatBtn = document.getElementById('chatbotVoiceToggleBtn');
  const currentLang = document.getElementById('globalLanguageSelect')?.value || 'en';
  const labels = getVoiceToggleLabels(currentLang, isMuted);

  if (globalBtn) {
    const icon = document.getElementById('voiceToggleIcon');
    const text = document.getElementById('voiceToggleText');
    if (isMuted) {
      globalBtn.classList.add('muted');
      globalBtn.title = 'Voice narration is OFF (Click to turn ON)';
      if (icon) icon.textContent = '🔇';
      if (text) text.textContent = labels.text;
    } else {
      globalBtn.classList.remove('muted');
      globalBtn.title = 'Voice narration is ON (Click to turn OFF)';
      if (icon) icon.textContent = '🔊';
      if (text) text.textContent = labels.text;
    }
  }

  if (chatBtn) {
    const chatIcon = document.getElementById('chatVoiceIcon');
    const chatLabel = document.getElementById('chatVoiceLabel');
    if (isMuted) {
      chatBtn.classList.add('muted');
      chatBtn.title = 'Chatbot voice replies are OFF (Click to turn ON)';
      if (chatIcon) chatIcon.textContent = '🔇';
      if (chatLabel) chatLabel.textContent = labels.chatText;
    } else {
      chatBtn.classList.remove('muted');
      chatBtn.title = 'Chatbot voice replies are ON (Click to turn OFF)';
      if (chatIcon) chatIcon.textContent = '🔊';
      if (chatLabel) chatLabel.textContent = labels.chatText;
    }
  }
}
window.updateVoiceUI = updateVoiceUI;

function initVoiceToggle() {
  const globalBtn = document.getElementById('globalVoiceToggleBtn');
  const chatBtn = document.getElementById('chatbotVoiceToggleBtn');

  if (globalBtn) {
    globalBtn.addEventListener('click', () => {
      window.speechManager.toggleMute();
    });
  }

  if (chatBtn) {
    chatBtn.addEventListener('click', () => {
      window.speechManager.toggleMute();
    });
  }

  if (window.speechManager) {
    if (typeof window.speechManager.onMuteChange === 'function') {
      window.speechManager.onMuteChange((isMuted) => {
        updateVoiceUI(isMuted);
      });
    }
    if (typeof window.speechManager.onSpeechStateChange === 'function') {
      window.speechManager.onSpeechStateChange((isPlaying) => {
        updateReadAloudBtnState(isPlaying);
        updateReadPlanBtnState(isPlaying);
      });
    }
    updateVoiceUI(window.speechManager.isVoiceMuted());
  }
}

// ============================================================================
// 2. Voice Symptom Triage
// ============================================================================

function updateReadAloudBtnState(isPlaying) {
  const readAloudBtn = document.getElementById('readAloudBtn');
  if (!readAloudBtn) return;
  const langSelect = document.getElementById('globalLanguageSelect');
  const currentLang = (langSelect && langSelect.value !== 'auto')
    ? langSelect.value
    : (lastTriageResult?.detectedLanguage || 'en');
  const t = (k) => (window.getTranslation ? window.getTranslation(k, currentLang) : k);

  if (isPlaying) {
    readAloudBtn.classList.add('btn-speaking');
    readAloudBtn.classList.remove('btn-secondary');
    readAloudBtn.innerHTML = `
      <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor">
        <rect x="6" y="6" width="12" height="12" rx="2"/>
      </svg>
      <span>${t('btn_stop_reading') || 'Stop Reading'}</span>
    `;
    readAloudBtn.title = "Click to stop reading";
  } else {
    readAloudBtn.classList.remove('btn-speaking');
    readAloudBtn.classList.add('btn-secondary');
    readAloudBtn.innerHTML = `
      <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2">
        <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/>
        <path d="M19.07 4.93a10 10 0 0 1 0 14.14M15.54 8.46a5 5 0 0 1 0 7.07"/>
      </svg>
      <span data-i18n="btn_read_aloud">${t('btn_read_aloud') || 'Read Diagnosis Aloud'}</span>
    `;
    readAloudBtn.title = "Read diagnosis aloud";
  }
}

function initVoiceTriage() {
  const micBtn = document.getElementById('mainMicBtn');
  const micCaption = document.getElementById('micCaption');
  const micStatusPill = document.getElementById('micStatusPill');
  const textInput = document.getElementById('symptomTextInput');
  const evalBtn = document.getElementById('evaluateTriageBtn');
  const clearBtn = document.getElementById('clearSymptomBtn');
  const readAloudBtn = document.getElementById('readAloudBtn');

  // Mic Button Click
  micBtn.addEventListener('click', () => {
    if (window.speechManager.isListening) {
      window.speechManager.stopListening();
    } else {
      window.speechManager.startListening(
        (transcript, isFinal) => {
          textInput.value = transcript;
        },
        (status, err) => {
          if (status === 'listening') {
            micBtn.classList.add('recording');
            micCaption.textContent = 'Listening... Speak your symptoms now';
            micStatusPill.textContent = 'Recording Audio...';
            micStatusPill.classList.add('recording');
          } else if (status === 'idle') {
            micBtn.classList.remove('recording');
            micCaption.textContent = 'Click to start voice recording';
            micStatusPill.textContent = 'Microphone Ready';
            micStatusPill.classList.remove('recording');
          } else if (status === 'not_supported') {
            micCaption.textContent = 'Speech recognition not available. Please type above.';
            micStatusPill.textContent = 'Voice Not Supported';
          }
        }
      );
    }
  });

  // Evaluate Triage Engine
  evalBtn.addEventListener('click', () => {
    const text = textInput.value.trim();
    if (!text) {
      alert('Please enter or speak your symptoms first.');
      return;
    }
    evaluateSymptoms(text);
  });

  // Clear Input
  clearBtn.addEventListener('click', () => {
    textInput.value = '';
    document.getElementById('triageEmptyState').style.display = 'flex';
    document.getElementById('triageOutcomeContainer').style.display = 'none';
    window.speechManager.stopSpeaking();
    updateReadAloudBtnState(false);
  });

  // Preset Scenarios
  document.querySelectorAll('.preset-chip').forEach(chip => {
    chip.addEventListener('click', () => {
      // Strip emojis and leading icons cleanly without stripping Unicode characters
      const cleanText = chip.textContent.replace(/^[\s\p{Emoji}\p{Extended_Pictographic}🚨⚠️✅]+/u, '').trim();
      textInput.value = cleanText;
      evaluateSymptoms(cleanText);
    });
  });

  // Read Diagnosis Aloud Button Toggle Handler
  readAloudBtn.addEventListener('click', () => {
    // If already speaking, STOP speaking immediately
    if (window.speechManager.isSpeaking()) {
      window.speechManager.stopSpeaking();
      return;
    }

    // Otherwise, start reading diagnosis aloud (explicit click forces speech even if muted)
    if (lastTriageResult && lastTriageResult.speechResponse) {
      const targetLang = (lastTriageResult.detectedLanguage && lastTriageResult.detectedLanguage !== 'auto')
        ? lastTriageResult.detectedLanguage
        : (document.getElementById('globalLanguageSelect')?.value || 'en');
      window.speechManager.speak(
        lastTriageResult.speechResponse,
        null,
        targetLang,
        true // force speech on explicit user request
      );
    }
  });
}

async function evaluateSymptoms(text) {
  const evalBtn = document.getElementById('evaluateTriageBtn');
  const langSelect = document.getElementById('globalLanguageSelect');
  const lang = langSelect ? langSelect.value : 'auto';
  const activeLang = (lang !== 'auto') ? lang : 'en';
  const t = (k) => (window.getTranslation ? window.getTranslation(k, activeLang) : k);

  evalBtn.disabled = true;
  evalBtn.innerHTML = t('btn_analyzing') || 'Analyzing with Triage Engine...';

  try {
    const res = await fetch(`${API_BASE}/api/triage/evaluate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        userId: currentUserId,
        inputText: text,
        language: lang
      })
    });

    const data = await res.json();
    if (res.ok) {
      lastTriageResult = data;
      renderTriageOutcome(data);
      // Automatically speak the triage diagnosis only if voice narration is ON
      if (data.speechResponse && !window.speechManager.isVoiceMuted()) {
        updateReadAloudBtnState(true);
        window.speechManager.speak(
          data.speechResponse,
          () => {
            updateReadAloudBtnState(false);
          },
          data.detectedLanguage
        );
      }
    } else {
      alert('Error during triage: ' + (data.error || 'Evaluation failed'));
    }
  } catch (e) {
    console.error(e);
    alert('Unable to contact triage server. Please ensure Java backend is running.');
  } finally {
    evalBtn.disabled = false;
    evalBtn.innerHTML = `
      <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/>
        <polyline points="22 4 12 14.01 9 11.01"/>
      </svg>
      <span data-i18n="btn_analyze">${t('btn_analyze') || 'Analyze & Run Triage Engine'}</span>
    `;
  }
}

function renderTriageOutcome(data) {
  document.getElementById('triageEmptyState').style.display = 'none';
  const container = document.getElementById('triageOutcomeContainer');
  container.style.display = 'block';

  const banner = document.getElementById('urgencyBanner');
  const icon = document.getElementById('urgencyIcon');
  const badgeText = document.getElementById('urgencyBadgeText');
  const heading = document.getElementById('urgencyHeading');
  const confidence = document.getElementById('confidenceValue');

  // Reset classes
  banner.className = 'urgency-banner';

  const urgency = data.urgency ? data.urgency.toUpperCase() : 'UNCERTAIN';
  confidence.textContent = Math.round((data.confidenceScore || 0.9) * 100) + '%';

  const langSelect = document.getElementById('globalLanguageSelect');
  const activeLang = (langSelect && langSelect.value !== 'auto')
    ? langSelect.value
    : (data.detectedLanguage || 'en');
  const t = (key) => (window.getTranslation ? window.getTranslation(key, activeLang) : key);

  if (urgency === 'EMERGENCY') {
    banner.classList.add('urgency-emergency');
    icon.textContent = '🚨';
    badgeText.textContent = t('urgency_emergency') || 'EMERGENCY';
    heading.textContent = t('heading_emergency') || 'Immediate Medical Attention Required';
  } else if (urgency === 'MODERATE') {
    banner.classList.add('urgency-moderate');
    icon.textContent = '⚠️';
    badgeText.textContent = t('urgency_moderate') || 'MODERATE';
    heading.textContent = t('heading_moderate') || 'Medical Consultation Recommended';
  } else if (urgency === 'SELF_CARE') {
    banner.classList.add('urgency-selfcare');
    icon.textContent = '✅';
    badgeText.textContent = t('urgency_selfcare') || 'SELF-CARE';
    heading.textContent = t('heading_selfcare') || 'Suitable for Home Self-Care';
  } else {
    banner.classList.add('urgency-uncertain');
    icon.textContent = '❓';
    badgeText.textContent = t('urgency_uncertain') || 'UNCERTAIN';
    heading.textContent = t('heading_uncertain') || 'Clinical Follow-Up Required';
  }

  document.getElementById('deptName').textContent = data.department || 'General Medicine';
  document.getElementById('clinicalRecommendationText').textContent = data.recommendation;
  document.getElementById('ruleIdPill').textContent = data.ruleMatched || 'CLINICAL_RULE';
  document.getElementById('explainReasonText').textContent = data.reason;
  document.getElementById('voiceScriptText').textContent = `"${data.speechResponse}"`;

  // Render Extracted Entities
  const tagsContainer = document.getElementById('extractedEntityTags');
  tagsContainer.innerHTML = '';
  if (data.symptoms && data.symptoms.length > 0) {
    data.symptoms.forEach(s => {
      const tag = document.createElement('span');
      tag.className = 'entity-tag' + (s.isRedFlag ? ' tag-redflag' : '');
      tag.innerHTML = `
        ${s.isRedFlag ? '⚠️ ' : ''}
        <strong>${escapeHtml(s.name)}</strong>
        (${s.severity}, ${s.bodyPart || 'General'})
      `;
      tagsContainer.appendChild(tag);
    });
  } else {
    const defaultLabel = activeLang === 'ta' ? 'பொதுவான அசௌகரியம்' : 'General Discomfort';
    tagsContainer.innerHTML = `<span class="entity-tag">${defaultLabel}</span>`;
  }

  // Update button state in case speech is active
  updateReadAloudBtnState(window.speechManager.isSpeaking());
}

// ============================================================================
// 3. AI Health Chatbot
// ============================================================================

function initChatbot() {
  const sendBtn = document.getElementById('sendChatBtn');
  const chatInput = document.getElementById('chatTextInput');
  const chatMicBtn = document.getElementById('chatMicBtn');
  const clearChatBtn = document.getElementById('clearChatBtn');

  sendBtn.addEventListener('click', sendChatMessage);
  chatInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') sendChatMessage();
  });

  chatMicBtn.addEventListener('click', () => {
    if (window.speechManager.isListening) {
      window.speechManager.stopListening();
    } else {
      window.speechManager.startListening(
        (transcript, isFinal) => {
          chatInput.value = transcript;
          if (isFinal) sendChatMessage();
        },
        (status) => {
          chatMicBtn.classList.toggle('recording', status === 'listening');
        }
      );
    }
  });

  clearChatBtn.addEventListener('click', () => {
    const messages = document.getElementById('chatMessages');
    messages.innerHTML = `
      <div class="chat-bubble bot-bubble">
        <div class="bubble-sender"><img src="images/logo.png" class="bubble-sender-icon" alt=""> MediVoice Assistant</div>
        <div class="bubble-content">Chat history cleared. How can I assist you with your health today?</div>
        <span class="bubble-time">Just now</span>
      </div>
    `;
  });
}

async function sendChatMessage() {
  const input = document.getElementById('chatTextInput');
  const text = input.value.trim();
  if (!text) return;

  appendChatBubble('USER', text);
  input.value = '';

  try {
    const res = await fetch(`${API_BASE}/api/chat/message`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        userId: currentUserId,
        chatId: currentChatId,
        message: text,
        language: document.getElementById('globalLanguageSelect').value
      })
    });

    const data = await res.json();
    if (res.ok) {
      currentChatId = data.chatId;
      appendChatBubble('ASSISTANT', data.reply, data.intent);
      // Auto voice reply only if voice narration is ON
      if (!window.speechManager.isVoiceMuted()) {
        const activeLang = document.getElementById('globalLanguageSelect')?.value || 'en';
        window.speechManager.speak(data.reply, null, activeLang);
      }

      // If emergency intent detected, prompt SOS modal
      if (data.isEmergency) {
        setTimeout(() => triggerEmergencySOSModal(), 1500);
      }
    } else {
      appendChatBubble('ASSISTANT', 'Sorry, I encountered an issue processing your request.');
    }
  } catch (e) {
    console.error(e);
    appendChatBubble('ASSISTANT', 'Error communicating with medical server.');
  }
}

function appendChatBubble(sender, text, intent) {
  const container = document.getElementById('chatMessages');
  const bubble = document.createElement('div');
  const isUser = sender === 'USER';
  bubble.className = `chat-bubble ${isUser ? 'user-bubble' : 'bot-bubble'}`;

  const now = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  bubble.innerHTML = `
    ${!isUser ? `<div class="bubble-sender"><img src="images/logo.png" class="bubble-sender-icon" alt=""> MediVoice Assistant ${intent ? `• <span style="color:#f59e0b">${intent}</span>` : ''}</div>` : ''}
    <div class="bubble-content">${escapeHtml(text).replace(/\n/g, '<br>')}</div>
    <span class="bubble-time">${now}</span>
  `;

  container.appendChild(bubble);
  container.scrollTop = container.scrollHeight;
}

// ============================================================================
// 4. First-Aid Guides
// ============================================================================

async function initFirstAid() {
  loadFirstAidGuides();
}

let cachedFirstAidGuides = [];

async function loadFirstAidGuides() {
  const grid = document.getElementById('firstAidGrid');
  if (!grid) return;
  try {
    const res = await fetch(`${API_BASE}/api/firstaid`);
    cachedFirstAidGuides = await res.json();
    const currentLang = document.getElementById('globalLanguageSelect')?.value || localStorage.getItem('medivoice_selected_lang') || 'en';
    renderFirstAidGuides(currentLang);
  } catch (e) {
    console.error('Failed to load first aid guides:', e);
  }
}

function renderFirstAidGuides(lang) {
  const grid = document.getElementById('firstAidGrid');
  if (!grid) return;

  // If no cached guides yet, trigger fetch
  if (!cachedFirstAidGuides || cachedFirstAidGuides.length === 0) {
    loadFirstAidGuides();
    return;
  }

  const currentLang = (!lang || lang === 'auto')
    ? (document.getElementById('globalLanguageSelect')?.value || localStorage.getItem('medivoice_selected_lang') || 'en')
    : lang;

  grid.innerHTML = '';

  const iconMap = {
    'MINOR_CUT': '🩹',
    'MINOR_BURN': '🔥',
    'NOSEBLEED': '🩸',
    'SPRAIN': '🦶',
    'CHOKING': '🫁',
    'FAINTING': '💫',
    'INSECT_BITE': '🐝'
  };

  cachedFirstAidGuides.forEach(g => {
    const card = document.createElement('div');
    card.className = 'firstaid-card';

    // Retrieve localized title, steps, and red flags for the selected language
    let title = g.title;
    let steps = g.steps;
    let redFlags = g.redFlags;
    let redFlagsHeader = '⚠️ Immediate Escalation Red Flags:';

    if (typeof window.getLocalFirstAid === 'function') {
      const loc = window.getLocalFirstAid(g.scenario, currentLang);
      if (loc && loc.title) {
        title = loc.title;
        steps = loc.steps;
        redFlags = loc.redFlags;
        redFlagsHeader = loc.redFlagsHeader;
      }
    }

    card.innerHTML = `
      <div class="firstaid-card-header">
        <span class="firstaid-badge-icon">${iconMap[g.scenario] || '⚕️'}</span>
        <h3>${escapeHtml(title)}</h3>
      </div>
      <div class="firstaid-steps-content">
        ${escapeHtml(steps)}
      </div>
      <div class="firstaid-redflags-box">
        <strong>${escapeHtml(redFlagsHeader)}</strong><br>
        ${escapeHtml(redFlags)}
      </div>
    `;
    grid.appendChild(card);
  });
}

window.renderFirstAidGuides = renderFirstAidGuides;

// ============================================================================
// 5. Food & Nutrition Plan
// ============================================================================

function initFoodPlan() {
  document.querySelectorAll('.food-chip').forEach(chip => {
    chip.addEventListener('click', () => {
      const q = chip.dataset.query;
      document.getElementById('foodCustomQuery').value = q;
      generateDietPlan(q);
    });
  });

  const genBtn = document.getElementById('generateFoodPlanBtn');
  const foodInput = document.getElementById('foodCustomQuery');
  if (foodInput) {
    foodInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        const q = foodInput.value.trim() || 'Healthy balanced meal plan';
        generateDietPlan(q);
      }
    });
  }

  genBtn.addEventListener('click', () => {
    const q = document.getElementById('foodCustomQuery').value.trim() || 'Healthy balanced meal plan';
    generateDietPlan(q);
  });

  const readPlanBtn = document.getElementById('readFoodPlanBtn');
  if (readPlanBtn) {
    readPlanBtn.addEventListener('click', () => {
      if (window.speechManager.isSpeaking()) {
        window.speechManager.stopSpeaking();
        return;
      }

      const mealTitle = document.getElementById('planMealTypeTitle')?.textContent || '';
      const planBody = document.getElementById('planBodyContent')?.textContent || '';
      const advice = document.getElementById('planAdviceBox')?.textContent || '';
      const fullText = `${mealTitle}. ${planBody}. ${advice}`;

      if (fullText.trim().length > 5) {
        const currentLang = document.getElementById('globalLanguageSelect')?.value || 'en';
        window.speechManager.speak(
          fullText,
          null,
          currentLang,
          true
        );
      }
    });
  }
}

function updateReadPlanBtnState(isPlaying) {
  const btn = document.getElementById('readFoodPlanBtn');
  if (!btn) return;
  const icon = document.getElementById('readFoodPlanIcon');
  const text = document.getElementById('readFoodPlanText');
  if (isPlaying) {
    btn.classList.add('btn-speaking');
    if (icon) icon.textContent = '⏹️';
    if (text) text.textContent = 'Stop Reading';
  } else {
    btn.classList.remove('btn-speaking');
    if (icon) icon.textContent = '🔊';
    if (text) text.textContent = 'Read Plan Aloud';
  }
}

async function generateDietPlan(query) {
  const btn = document.getElementById('generateFoodPlanBtn');
  btn.disabled = true;
  btn.textContent = 'Generating Advice...';

  try {
    const currentLang = document.getElementById('globalLanguageSelect')?.value || 'en';
    const res = await fetch(`${API_BASE}/api/food/generate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId: currentUserId, query: query, language: currentLang })
    });

    const plan = await res.json();
    if (res.ok) {
      document.getElementById('planMealTypeTitle').textContent = plan.mealType.replace(/_/g, ' ') + ' Nutrition Plan';
      document.getElementById('planCaloriesBadge').textContent = `Target: ${plan.caloriesTarget} kcal / day`;
      document.getElementById('planBodyContent').textContent = plan.planText;
      document.getElementById('planAdviceBox').innerHTML = `<strong>Clinical Nutrition Note:</strong> ${escapeHtml(plan.dietaryAdvice)}`;
    }
  } catch (e) {
    console.error(e);
  } finally {
    btn.disabled = false;
    btn.textContent = 'Generate Food Advice';
  }
}

// ============================================================================
// 6. Medications & Reminders
// ============================================================================

function initMedications() {
  loadMedications();
  loadReminders();

  const form = document.getElementById('addMedicationForm');
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const name = document.getElementById('medNameInput').value.trim();
    const dosage = document.getElementById('medDosageInput').value.trim();
    const freq = document.getElementById('medFrequencyInput').value;
    const time = document.getElementById('medTimeInput').value;
    const inst = document.getElementById('medInstructionsInput').value.trim();

    try {
      const res = await fetch(`${API_BASE}/api/medication/add`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: currentUserId,
          medicineName: name,
          dosage: dosage,
          frequency: freq,
          reminderTime: time,
          instructions: inst
        })
      });

      if (res.ok) {
        form.reset();
        document.getElementById('medTimeInput').value = '09:00';
        loadMedications();
        loadReminders();
        alert('Medication schedule and voice reminder activated!');
      }
    } catch (err) {
      console.error(err);
    }
  });

  const testBtn = document.getElementById('testVoiceAlertBtn');
  testBtn.addEventListener('click', async () => {
    await fetch(`${API_BASE}/api/reminder/test-alert`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ medicineName: 'Paracetamol', dosage: '500 mg' })
    });
    // Immediately check reminders
    checkPendingVoiceAlerts();
  });

  document.getElementById('toastCloseBtn').addEventListener('click', () => {
    document.getElementById('voiceAlertToast').style.display = 'none';
  });
}

async function loadMedications() {
  try {
    const res = await fetch(`${API_BASE}/api/medication/list?userId=${currentUserId}`);
    const list = await res.json();
    // Update reminder badge
    document.getElementById('activeRemindersCount').textContent = list.length;
  } catch (e) {
    console.error(e);
  }
}

async function loadReminders() {
  const tbody = document.getElementById('medicationsTableBody');
  try {
    const res = await fetch(`${API_BASE}/api/reminder/list?userId=${currentUserId}`);
    const reminders = await res.json();

    tbody.innerHTML = '';
    if (reminders.length === 0) {
      tbody.innerHTML = '<tr><td colspan="5" style="text-align:center;color:#6b7280;">No active medication reminders configured.</td></tr>';
      return;
    }

    reminders.forEach(r => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td><strong>${escapeHtml(r.medicineName)}</strong></td>
        <td>${escapeHtml(r.dosage)}</td>
        <td><span class="badge-time">${r.reminderTime}</span> (${r.frequency})</td>
        <td>
          <label class="toggle-switch">
            <input type="checkbox" ${r.active ? 'checked' : ''} onchange="toggleReminder(${r.reminderId}, this.checked)">
            <span class="toggle-slider"></span>
          </label>
        </td>
        <td>
          <button class="btn btn-sm btn-secondary" onclick="deleteReminder(${r.reminderId})">Delete</button>
        </td>
      `;
      tbody.appendChild(tr);
    });
  } catch (e) {
    console.error(e);
  }
}

window.toggleReminder = async function(reminderId, active) {
  await fetch(`${API_BASE}/api/reminder/toggle`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ reminderId: reminderId, active: active })
  });
};

window.deleteReminder = async function(reminderId) {
  if (!confirm('Are you sure you want to delete this medication reminder?')) return;
  await fetch(`${API_BASE}/api/reminder/delete`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ reminderId: reminderId })
  });
  loadReminders();
};

function startReminderPoller() {
  setInterval(checkPendingVoiceAlerts, 5000);
}

async function checkPendingVoiceAlerts() {
  try {
    const res = await fetch(`${API_BASE}/api/reminder/poll`);
    if (res.ok) {
      const alerts = await res.json();
      if (alerts && alerts.length > 0) {
        alerts.forEach(a => {
          showVoiceToast(a);
          if (!window.speechManager.isVoiceMuted()) {
            const currentLang = document.getElementById('globalLanguageSelect')?.value || 'en';
            window.speechManager.speak(a.alertMessage, null, currentLang);
          }
        });
      }
    }
  } catch (ignored) {}
}

function showVoiceToast(alertData) {
  const toast = document.getElementById('voiceAlertToast');
  document.getElementById('toastTitle').textContent = `Medication Reminder: ${alertData.medicineName}`;
  document.getElementById('toastMessage').textContent = alertData.alertMessage;
  toast.style.display = 'flex';

  setTimeout(() => {
    toast.style.display = 'none';
  }, 12000);
}

// ============================================================================
// 7. Medical Records & Scans
// ============================================================================

let stagedFile = null;

function initRecords() {
  const dropzone = document.getElementById('uploadDropzone');
  const fileInput = document.getElementById('recordFileInput');
  const prompt = document.getElementById('dropzonePrompt');
  const preview = document.getElementById('selectedFilePreview');
  const fileName = document.getElementById('selectedFileName');
  const removeBtn = document.getElementById('removeSelectedFileBtn');
  const uploadBtn = document.getElementById('uploadRecordBtn');

  dropzone.addEventListener('click', () => fileInput.click());

  fileInput.addEventListener('change', (e) => {
    if (e.target.files.length > 0) {
      stagedFile = e.target.files[0];
      fileName.textContent = stagedFile.name;
      prompt.style.display = 'none';
      preview.style.display = 'block';
    }
  });

  removeBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    stagedFile = null;
    fileInput.value = '';
    prompt.style.display = 'block';
    preview.style.display = 'none';
  });

  uploadBtn.addEventListener('click', async () => {
    if (!stagedFile) {
      alert('Please select a file to upload first.');
      return;
    }

    const type = document.getElementById('recordTypeSelect').value;
    const desc = document.getElementById('recordDescInput').value.trim();

    uploadBtn.disabled = true;
    uploadBtn.textContent = 'Uploading...';

    const reader = new FileReader();
    reader.onload = async () => {
      const base64 = reader.result;
      try {
        const res = await fetch(`${API_BASE}/api/records/upload`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            userId: currentUserId,
            type: type,
            fileName: stagedFile.name,
            fileBase64: base64,
            description: desc
          })
        });

        if (res.ok) {
          alert('Medical record uploaded successfully!');
          stagedFile = null;
          fileInput.value = '';
          prompt.style.display = 'block';
          preview.style.display = 'none';
          document.getElementById('recordDescInput').value = '';
          loadRecords();
        }
      } catch (e) {
        console.error(e);
      } finally {
        uploadBtn.disabled = false;
        uploadBtn.textContent = 'Upload Record';
      }
    };
    reader.readAsDataURL(stagedFile);
  });
}

async function loadRecords() {
  const grid = document.getElementById('recordsGrid');
  try {
    const res = await fetch(`${API_BASE}/api/records/list?userId=${currentUserId}`);
    const records = await res.json();

    document.getElementById('recordsCountBadge').textContent = `${records.length} Records`;
    grid.innerHTML = '';

    if (records.length === 0) {
      grid.innerHTML = '<p style="color:#6b7280;grid-column:1/-1;">No medical records or scans uploaded yet.</p>';
      return;
    }

    records.forEach(r => {
      const card = document.createElement('div');
      card.className = 'record-card';
      card.innerHTML = `
        <div>
          <span class="record-type-pill">${r.type.replace('_', ' ')}</span>
          <div class="record-title">${escapeHtml(r.fileName)}</div>
          <div class="record-meta">${escapeHtml(r.description || 'Uploaded on ' + r.uploadDate)}</div>
        </div>
        <div class="record-actions">
          <a href="${API_BASE}/api/records/file?recordId=${r.recordId}" target="_blank" class="btn btn-sm btn-secondary">View / Download</a>
          <button class="btn btn-sm btn-secondary" onclick="deleteRecord(${r.recordId})">Delete</button>
        </div>
      `;
      grid.appendChild(card);
    });
  } catch (e) {
    console.error(e);
  }
}

window.deleteRecord = async function(recordId) {
  if (!confirm('Are you sure you want to delete this record?')) return;
  await fetch(`${API_BASE}/api/records/delete`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ recordId: recordId, userId: currentUserId })
  });
  loadRecords();
};

// ============================================================================
// 8. Longitudinal Clinical History & Doctor's Summary
// ============================================================================

async function loadClinicalHistory() {
  const timeline = document.getElementById('historyTimeline');
  try {
    const res = await fetch(`${API_BASE}/api/history/full?userId=${currentUserId}`);
    const data = await res.json();

    timeline.innerHTML = '';
    const results = data.triageResults || [];

    if (results.length === 0) {
      timeline.innerHTML = '<p style="color:#6b7280;">No previous triage interactions recorded yet.</p>';
      return;
    }

    results.forEach(tr => {
      const item = document.createElement('div');
      const urgencyClass = tr.urgency ? tr.urgency.toLowerCase() : '';
      item.className = `timeline-item ${urgencyClass}`;
      item.innerHTML = `
        <div class="timeline-date">${tr.createdAt || 'Recent Consultation'}</div>
        <div class="timeline-content">
          <span class="urgency-badge" style="background:${getUrgencyColor(tr.urgency)}">${tr.urgency}</span>
          <h4 style="margin:0.4rem 0;">Department: ${escapeHtml(tr.department)}</h4>
          <p style="font-size:0.88rem;color:#e5e7eb;">${escapeHtml(tr.recommendation)}</p>
          <p style="font-size:0.78rem;color:#9ca3af;margin-top:0.4rem;"><em>Rationale: ${escapeHtml(tr.reason)}</em></p>
        </div>
      `;
      timeline.appendChild(item);
    });
  } catch (e) {
    console.error(e);
  }
}

function getUrgencyColor(urgency) {
  if (urgency === 'EMERGENCY') return '#ef4444';
  if (urgency === 'MODERATE') return '#f59e0b';
  if (urgency === 'SELF_CARE') return '#10b981';
  return '#8b5cf6';
}

// ============================================================================
// 9. Health Profile & Vitals
// ============================================================================

function initProfile() {
  const form = document.getElementById('profileForm');
  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    const name = document.getElementById('profName').value.trim();
    const gender = document.getElementById('profGender').value;
    const age = parseInt(document.getElementById('profAge').value);
    const height = parseFloat(document.getElementById('profHeight').value);
    const weight = parseFloat(document.getElementById('profWeight').value);
    const blood = document.getElementById('profBloodGroup').value;
    const emergencyContact = document.getElementById('profEmergencyContact').value.trim();
    const contactPhone = document.getElementById('profContactPhone').value.trim();

    try {
      const res = await fetch(`${API_BASE}/api/user/profile`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: currentUserId,
          name: name,
          gender: gender,
          age: age,
          height: height,
          weight: weight,
          bloodGroup: blood,
          emergencyContact: emergencyContact,
          contactPhone: contactPhone
        })
      });

      const data = await res.json();
      if (res.ok) {
        alert('Health profile updated successfully!');
        updateProfileUI(data.profile);
      }
    } catch (err) {
      console.error(err);
    }
  });

  // Calculate live BMI on height or weight change
  const hInput = document.getElementById('profHeight');
  const wInput = document.getElementById('profWeight');
  const updateBmiDisplay = () => {
    const h = parseFloat(hInput.value) / 100;
    const w = parseFloat(wInput.value);
    if (h > 0 && w > 0) {
      const bmi = Math.round((w / (h * h)) * 10) / 10;
      document.getElementById('displayBmiValue').textContent = bmi;
    }
  };
  hInput.addEventListener('input', updateBmiDisplay);
  wInput.addEventListener('input', updateBmiDisplay);
}

function updateProfileUI(p) {
  if (!p) return;
  document.getElementById('headerUserName').textContent = p.name;
  document.getElementById('headerAvatar').textContent = p.name.charAt(0);
  document.getElementById('headerVitals').textContent = `${p.age}y • ${p.bloodGroup || 'O+'} • BMI ${p.bmi || '20.6'}`;
  document.getElementById('sosPatientName').textContent = p.name;
  document.getElementById('sosContactTarget').textContent = `${p.emergencyContact} (${p.contactPhone})`;
  document.getElementById('displayBmiValue').textContent = p.bmi || '20.6';
  document.getElementById('displayBmiCategory').textContent = p.bmiCategory || 'Normal weight';
  document.getElementById('foodPlanBmiTag').textContent = `BMI: ${p.bmi} (${p.bmiCategory})`;
}

// ============================================================================
// 10. Emergency SOS Modal & Workflow
// ============================================================================

function initSOSModal() {
  const quickBtn = document.getElementById('quickSosBtn');
  const modal = document.getElementById('sosModal');
  const cancelBtn = document.getElementById('cancelSosBtn');
  const confirmBtn = document.getElementById('confirmSosBtn');
  const closeDispatchedBtn = document.getElementById('closeDispatchedSosBtn');

  quickBtn.addEventListener('click', triggerEmergencySOSModal);

  cancelBtn.addEventListener('click', () => {
    clearInterval(sosCountdownTimer);
    modal.style.display = 'none';
  });

  confirmBtn.addEventListener('click', dispatchConfirmedSOS);

  if (closeDispatchedBtn) {
    closeDispatchedBtn.addEventListener('click', () => {
      const dispatchedModal = document.getElementById('sosDispatchedModal');
      if (dispatchedModal) dispatchedModal.style.display = 'none';
    });
  }
}

function triggerEmergencySOSModal() {
  const modal = document.getElementById('sosModal');
  modal.style.display = 'flex';

  countdownRemaining = 3;
  document.getElementById('countdownNumber').textContent = countdownRemaining;

  clearInterval(sosCountdownTimer);
  sosCountdownTimer = setInterval(() => {
    countdownRemaining--;
    document.getElementById('countdownNumber').textContent = countdownRemaining;
    if (countdownRemaining <= 0) {
      clearInterval(sosCountdownTimer);
      dispatchConfirmedSOS();
    }
  }, 1000);
}

async function dispatchConfirmedSOS() {
  clearInterval(sosCountdownTimer);
  const modal = document.getElementById('sosModal');

  try {
    const res = await fetch(`${API_BASE}/api/sos/trigger`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        userId: currentUserId,
        contactPhone: '+91 8220664059',
        location: '12.8230° N, 80.0450° E (SRM Campus / Medical Center)',
        reason: 'Patient triggered critical SOS emergency protocol.'
      })
    });

    const data = await res.json();
    modal.style.display = 'none';

    // Populate the Dispatched SOS Action Modal
    const dispatchedModal = document.getElementById('sosDispatchedModal');
    if (dispatchedModal) {
      const pName = document.getElementById('dispatchedPatientName');
      const cTarget = document.getElementById('dispatchedContactTarget');
      const loc = document.getElementById('dispatchedLocation');
      const smsBtn = document.getElementById('sosSmsActionBtn');
      const waBtn = document.getElementById('sosWhatsAppActionBtn');

      if (pName) pName.textContent = data.patientName || 'Kaviyadharshini N';
      if (cTarget) cTarget.textContent = `${data.emergencyContact || 'Family Guardian'} (${data.emergencyPhone || '+91 8220664059'})`;
      if (loc) loc.textContent = data.location || '12.8230° N, 80.0450° E (SRM Campus)';

      const smsUri = data.smsUri || `sms:${data.emergencyPhone || '+918220664059'}?body=EMERGENCY+SOS+ALERT`;
      const waUri = data.whatsappUri || `https://wa.me/918220664059?text=EMERGENCY+SOS+ALERT`;

      if (smsBtn) {
        smsBtn.href = smsUri;
        smsBtn.innerHTML = `<span>📱</span> <strong>Send SMS to Phone (${data.emergencyPhone || '+91 8220664059'})</strong>`;
      }
      if (waBtn) {
        waBtn.href = waUri;
        waBtn.innerHTML = `<span>💬</span> <strong>Send Emergency WhatsApp to ${data.emergencyPhone || '+91 8220664059'}</strong>`;
      }

      dispatchedModal.style.display = 'flex';

      // Automatically trigger WhatsApp / SMS dispatch in background
      try {
        if (data.whatsappUri) {
          window.open(data.whatsappUri, '_blank');
        }
      } catch (err) {
        console.warn('Auto-popup blocked, user can click direct dispatch button', err);
      }
    }

    // Vocal spoken alert in current language only if voice narration is ON
    if (!window.speechManager.isVoiceMuted()) {
      const currentLang = document.getElementById('globalLanguageSelect')?.value || 'en';
      window.speechManager.speak(
        "Emergency SOS Dispatched. Nearby responders and your emergency contact have been alerted with your coordinates. Please remain seated.",
        null,
        currentLang
      );
    }

  } catch (e) {
    console.error(e);
  }
}

// Utility
function escapeHtml(str) {
  if (!str) return '';
  return str.replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');
}
