package com.medvoiceassistant.database;

import com.medvoiceassistant.util.DateTimeUtil;
import com.medvoiceassistant.util.PasswordUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseSeeder {

    public static void seedDefaults(Connection conn) {
        try {
            seedUsers(conn);
            seedFirstAidGuides(conn);
        } catch (SQLException e) {
            System.err.println("Database seeding error: " + e.getMessage());
        }
    }

    private static void seedUsers(Connection conn) throws SQLException {
        // Check if user table is already seeded
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT COUNT(*) FROM users;")) {
            if (rs.next() && rs.getInt(1) > 0) {
                return; // already seeded
            }
        }

        String now = DateTimeUtil.now();
        String passHash = PasswordUtil.hashPassword("password123");

        // 1. Create Demo User
        String insertUserSql = "INSERT INTO users (username, password_hash, created_at) VALUES (?, ?, ?);";
        int userId = -1;
        try (PreparedStatement ps = conn.prepareStatement(insertUserSql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, "kaviya");
            ps.setString(2, passHash);
            ps.setString(3, now);
            ps.executeUpdate();
            try (ResultSet gk = ps.getGeneratedKeys()) {
                if (gk.next()) {
                    userId = gk.getInt(1);
                }
            }
        }

        if (userId > 0) {
            // Seed profile
            String insertProfileSql = """
                INSERT INTO user_profile (user_id, name, gender, age, height, weight, blood_group, emergency_contact, contact_phone)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?);
            """;
            try (PreparedStatement ps = conn.prepareStatement(insertProfileSql)) {
                ps.setInt(1, userId);
                ps.setString(2, "Kaviyadharshini N");
                ps.setString(3, "Female");
                ps.setInt(4, 21);
                ps.setDouble(5, 165.0);
                ps.setDouble(6, 56.0);
                ps.setString(7, "O+");
                ps.setString(8, "Family Contact");
                ps.setString(9, "+91 98765 43210");
                ps.executeUpdate();
            }

            // Seed demo medications
            String insertMedSql = """
                INSERT INTO medication (user_id, medicine_name, dosage, frequency, instructions, created_at)
                VALUES (?, ?, ?, ?, ?, ?);
            """;
            int medId1 = -1;
            int medId2 = -1;
            try (PreparedStatement ps = conn.prepareStatement(insertMedSql, Statement.RETURN_GENERATED_KEYS)) {
                ps.setInt(1, userId);
                ps.setString(2, "Paracetamol");
                ps.setString(3, "500 mg");
                ps.setString(4, "Twice daily");
                ps.setString(5, "Take with full glass of water after food");
                ps.setString(6, now);
                ps.executeUpdate();
                try (ResultSet gk = ps.getGeneratedKeys()) {
                    if (gk.next()) medId1 = gk.getInt(1);
                }

                ps.setInt(1, userId);
                ps.setString(2, "Vitamin D3");
                ps.setString(3, "1000 IU");
                ps.setString(4, "Once daily");
                ps.setString(5, "Take in morning with breakfast");
                ps.setString(6, now);
                ps.executeUpdate();
                try (ResultSet gk = ps.getGeneratedKeys()) {
                    if (gk.next()) medId2 = gk.getInt(1);
                }
            }

            // Seed reminders
            String insertRemSql = """
                INSERT INTO reminder (medication_id, medicine_name, dosage, reminder_time, frequency, active, last_triggered)
                VALUES (?, ?, ?, ?, ?, 1, NULL);
            """;
            try (PreparedStatement ps = conn.prepareStatement(insertRemSql)) {
                if (medId1 > 0) {
                    ps.setInt(1, medId1);
                    ps.setString(2, "Paracetamol");
                    ps.setString(3, "500 mg");
                    ps.setString(4, "09:00");
                    ps.setString(5, "DAILY");
                    ps.executeUpdate();

                    ps.setInt(1, medId1);
                    ps.setString(2, "Paracetamol");
                    ps.setString(3, "500 mg");
                    ps.setString(4, "21:00");
                    ps.setString(5, "DAILY");
                    ps.executeUpdate();
                }

                if (medId2 > 0) {
                    ps.setInt(1, medId2);
                    ps.setString(2, "Vitamin D3");
                    ps.setString(3, "1000 IU");
                    ps.setString(4, "08:30");
                    ps.setString(5, "DAILY");
                    ps.executeUpdate();
                }
            }
        }
    }

    private static void seedFirstAidGuides(Connection conn) throws SQLException {
        // Check if first aid is already populated
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT COUNT(*) FROM first_aid_guide;")) {
            if (rs.next() && rs.getInt(1) > 0) {
                return;
            }
        }

        String insertSql = """
            INSERT INTO first_aid_guide (scenario, title, language, steps, red_flags, escalation)
            VALUES (?, ?, ?, ?, ?, ?);
        """;

        Object[][] guides = {
            {
                "MINOR_CUT",
                "Minor Cut or Scratch",
                "en",
                "1. Wash hands with soap and water before touching wound.\n2. Apply gentle pressure with a clean cloth or sterile gauze for 2-3 minutes to stop bleeding.\n3. Rinse wound gently under cool running tap water.\n4. Clean skin around wound with soap; do not get soap directly in deep wound.\n5. Apply a thin layer of antibacterial ointment or petroleum jelly.\n6. Cover with a sterile adhesive bandage.",
                "- Bleeding does not stop after 10 minutes of direct firm pressure\n- Cut is deep, gaping, or shows fat/muscle\n- Object is embedded in the wound\n- Dirt or debris cannot be washed out\n- Animal or human bite\n- Signs of infection: increasing redness, warmth, pus, or fever",
                "Seek immediate urgent care or emergency room if bleeding spurts or cannot be controlled."
            },
            {
                "MINOR_BURN",
                "Minor First & Second Degree Burn",
                "en",
                "1. Immediately cool the burn under gentle, cool running water for 10-15 minutes. (Do NOT use ice, butter, or toothpaste).\n2. Gently remove jewelry, rings, or tight clothing around the burned area before swelling starts.\n3. Do NOT pop or break any blisters that form.\n4. Apply pure aloe vera gel or soothing burn moisturizer.\n5. Protect loosely with a sterile non-stick bandage or clean cling wrap.\n6. Take mild pain relief such as paracetamol or ibuprofen if needed.",
                "- Burn covers face, hands, joints, groin, or large body area\n- Skin appears charred, white, leathery, or blackened (third-degree)\n- Chemical or electrical burn\n- Inhalation of smoke or difficulty breathing\n- Burned victim is an infant or elderly person",
                "Immediately call Emergency Services (108/911/112) or go to the nearest Burn Emergency Department."
            },
            {
                "NOSEBLEED",
                "Nosebleed (Epistaxis)",
                "en",
                "1. Sit upright and lean slightly forward (Do NOT lean head back, as blood may drain into throat).\n2. Pinch the soft part of the nostrils together firmly using your thumb and index finger.\n3. Breathe gently through your mouth.\n4. Maintain firm pressure continuously for 10 full minutes without releasing to check.\n5. Apply an ice pack or cold damp cloth across the bridge of the nose.\n6. Avoid blowing nose or strenuous activity for several hours afterward.",
                "- Bleeding continues for more than 20 minutes despite continuous pinching\n- Nosebleed was caused by severe head or facial trauma\n- Patient feels dizzy, lightheaded, faint, or disoriented\n- Very heavy blood loss or coughing up substantial blood\n- Patient is on blood thinners (anticoagulants)",
                "Proceed immediately to the Emergency Room if bleeding does not halt after 20 minutes."
            },
            {
                "SPRAIN",
                "Joint Sprain / Muscle Strain",
                "en",
                "Follow the proven R.I.C.E. protocol:\n1. REST: Stop the activity immediately and avoid putting weight on the injured limb.\n2. ICE: Apply an ice pack wrapped in a damp towel for 15-20 minutes every 2-3 hours for the first 48 hours.\n3. COMPRESSION: Wrap the area with an elastic bandage snugly, but not so tight as to restrict blood circulation.\n4. ELEVATION: Keep the injured joint raised above heart level whenever resting to reduce swelling.",
                "- Inability to bear any weight or walk even a few steps\n- Severe deformity or visible bone displacement\n- Numbness, tingling, or coldness in toes or fingers\n- Severe pain directly over the bone\n- Audible popping or cracking sound during injury",
                "Visit an orthopedic urgent care clinic or emergency facility for an X-ray to rule out fracture."
            },
            {
                "CHOKING",
                "Choking in Conscious Adult / Child",
                "en",
                "1. If person can cough forcefully or speak, encourage them to keep coughing.\n2. If person cannot breathe, speak, or make sound (universal sign of choking):\n3. Stand behind the person and lean them slightly forward.\n4. Deliver 5 sharp back blows between shoulder blades using the heel of your hand.\n5. If still choking, perform 5 abdominal thrusts (Heimlich Maneuver): Make a fist above navel, grasp with other hand, pull inward and upward sharply.\n6. Alternate 5 back blows and 5 abdominal thrusts until object is expelled.",
                "- Person turns blue, loses consciousness, or stops breathing\n- Victim is unable to make any vocal sound",
                "Call 108 / 911 / 112 immediately. If the person loses consciousness, lower them to the floor and begin CPR chest compressions."
            },
            {
                "FAINTING",
                "Fainting / Syncope",
                "en",
                "1. If someone feels dizzy, help them lie down flat on their back immediately.\n2. Elevate their legs about 12 inches (30 cm) above heart level to restore blood flow to the brain.\n3. Loosen tight collars, belts, or restrictive clothing.\n4. Ensure fresh airflow; open windows or use a fan.\n5. Check responsiveness and breathing.\n6. Once awake, do not let them stand up rapidly. Offer small sips of cool water or fruit juice.",
                "- Person remains unconscious for more than 1 minute\n- Fainting was preceded by chest pain, heart palpitations, or shortness of breath\n- Person hit their head violently during the fall\n- Confusion or speech difficulty after waking\n- Seizure-like convulsions or loss of bladder/bowel control",
                "Call emergency medical assistance immediately if unconsciousness persists or if accompanied by chest pain."
            },
            {
                "INSECT_BITE",
                "Insect Sting & Spider Bite",
                "en",
                "1. If a bee stinger is left in the skin, scrape it off immediately with a credit card or fingernail (do not squeeze the venom sac with tweezers).\n2. Wash the area thoroughly with soap and water.\n3. Apply a cold compress or ice pack wrapped in a cloth for 10 minutes at a time.\n4. Apply 1% hydrocortisone cream, calamine lotion, or baking soda paste to relieve itch.\n5. Take an oral antihistamine (e.g., Cetirizine) for itching and swelling.",
                "- Difficulty breathing, wheezing, or tightness in chest\n- Swelling of lips, tongue, throat, or entire face\n- Dizziness, confusion, or fainting\n- Generalized hives or widespread skin rash\n- Nausea, abdominal cramps, or vomiting (Signs of Anaphylaxis)",
                "ANAPHYLAXIS EMERGENCY: Administer Epinephrine auto-injector (EpiPen) if available into outer thigh and call 108 / 911 / 112 immediately."
            }
        };

        try (PreparedStatement ps = conn.prepareStatement(insertSql)) {
            for (Object[] g : guides) {
                ps.setString(1, (String) g[0]);
                ps.setString(2, (String) g[1]);
                ps.setString(3, (String) g[2]);
                ps.setString(4, (String) g[3]);
                ps.setString(5, (String) g[4]);
                ps.setString(6, (String) g[5]);
                ps.executeUpdate();
            }
        }
    }
}
