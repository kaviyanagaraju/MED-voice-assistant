package com.medvoiceassistant.database;

import java.io.File;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

public class DatabaseManager {
    private static DatabaseManager instance;

    private String dbType = "mysql"; // "mysql" or "sqlite"
    private String mysqlHost = "localhost";
    private int mysqlPort = 3306;
    private String mysqlDb = "medvoice_db";
    private String mysqlUser = "root";
    private String mysqlPass = "root";
    private String mysqlParams = "?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC&createDatabaseIfNotExist=true";
    private String sqliteUrl = "jdbc:sqlite:medical.db";

    private boolean isConnectedToMySQL = false;

    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            System.err.println("MySQL Connector/J Driver not found: " + e.getMessage());
        }
        try {
            Class.forName("org.sqlite.JDBC");
        } catch (ClassNotFoundException e) {
            System.err.println("SQLite JDBC Driver not found: " + e.getMessage());
        }
    }

    private DatabaseManager() {
        loadProperties();
        initializeDatabase();
    }

    public static synchronized DatabaseManager getInstance() {
        if (instance == null) {
            instance = new DatabaseManager();
        }
        return instance;
    }

    private void loadProperties() {
        File propFile = new File("db.properties");
        if (propFile.exists()) {
            Properties p = new Properties();
            try (FileInputStream fis = new FileInputStream(propFile)) {
                p.load(fis);
                dbType = p.getProperty("db.type", dbType).trim();
                mysqlHost = p.getProperty("db.mysql.host", mysqlHost).trim();
                mysqlPort = Integer.parseInt(p.getProperty("db.mysql.port", String.valueOf(mysqlPort)).trim());
                mysqlDb = p.getProperty("db.mysql.database", mysqlDb).trim();
                mysqlUser = p.getProperty("db.mysql.username", mysqlUser).trim();
                mysqlPass = p.getProperty("db.mysql.password", mysqlPass).trim();
                mysqlParams = p.getProperty("db.mysql.params", mysqlParams).trim();
                sqliteUrl = p.getProperty("db.sqlite.url", sqliteUrl).trim();
            } catch (Exception e) {
                System.err.println("Notice: Could not load db.properties, using defaults: " + e.getMessage());
            }
        }
    }

    public Connection getConnection() throws SQLException {
        if ("mysql".equalsIgnoreCase(dbType)) {
            try {
                String url = "jdbc:mysql://" + mysqlHost + ":" + mysqlPort + "/" + mysqlDb + mysqlParams;
                return DriverManager.getConnection(url, mysqlUser, mysqlPass);
            } catch (SQLException e) {
                if (!isConnectedToMySQL) {
                    System.err.println("==================================================================");
                    System.err.println(" [MYSQL NOTICE] Could not connect to MySQL at " + mysqlHost + ":" + mysqlPort);
                    System.err.println(" Error: " + e.getMessage());
                    System.err.println(" -> Please set your MySQL Workbench password in 'db.properties' file.");
                    System.err.println(" -> Falling back to SQLite (" + sqliteUrl + ") for now.");
                    System.err.println("==================================================================");
                }
                return DriverManager.getConnection(sqliteUrl);
            }
        } else {
            return DriverManager.getConnection(sqliteUrl);
        }
    }

    public void initializeDatabase() {
        boolean usingMySQL = "mysql".equalsIgnoreCase(dbType);

        if (usingMySQL) {
            // First attempt to create database in MySQL if not present
            try {
                String serverUrl = "jdbc:mysql://" + mysqlHost + ":" + mysqlPort + "/?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
                try (Connection rootConn = DriverManager.getConnection(serverUrl, mysqlUser, mysqlPass);
                     Statement stmt = rootConn.createStatement()) {
                    stmt.execute("CREATE DATABASE IF NOT EXISTS " + mysqlDb + " CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;");
                }
                isConnectedToMySQL = true;
                System.out.println(">>> Connected successfully to MySQL database '" + mysqlDb + "' at " + mysqlHost + ":" + mysqlPort);
            } catch (SQLException e) {
                isConnectedToMySQL = false;
                System.err.println("[MYSQL INIT] MySQL connection failed. Will use SQLite fallback until password is configured in db.properties.");
            }
        }

        try (Connection conn = getConnection(); Statement stmt = conn.createStatement()) {
            boolean isActualMySQL = conn.getMetaData().getDatabaseProductName().toLowerCase().contains("mysql");

            if (isActualMySQL) {
                initMySQLTables(stmt);
            } else {
                initSQLiteTables(stmt);
            }

            // Seed initial data
            DatabaseSeeder.seedDefaults(conn);

        } catch (SQLException e) {
            System.err.println("Error initializing database schema: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void initMySQLTables(Statement stmt) throws SQLException {
        // 1. users
        stmt.execute("""
            CREATE TABLE IF NOT EXISTS users (
                user_id INT AUTO_INCREMENT PRIMARY KEY,
                username VARCHAR(100) NOT NULL UNIQUE,
                password_hash VARCHAR(255) NOT NULL,
                created_at VARCHAR(50) NOT NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        """);

        // 2. user_profile
        stmt.execute("""
            CREATE TABLE IF NOT EXISTS user_profile (
                profile_id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL UNIQUE,
                name VARCHAR(150) NOT NULL,
                gender VARCHAR(30) NOT NULL,
                age INT NOT NULL,
                height DOUBLE NOT NULL,
                weight DOUBLE NOT NULL,
                blood_group VARCHAR(10),
                emergency_contact VARCHAR(150),
                contact_phone VARCHAR(50),
                CONSTRAINT fk_profile_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        """);

        // 3. symptom_session
        stmt.execute("""
            CREATE TABLE IF NOT EXISTS symptom_session (
                session_id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                input_text TEXT NOT NULL,
                language VARCHAR(20) NOT NULL,
                created_at VARCHAR(50) NOT NULL,
                CONSTRAINT fk_session_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        """);

        // 4. symptom
        stmt.execute("""
            CREATE TABLE IF NOT EXISTS symptom (
                symptom_id INT AUTO_INCREMENT PRIMARY KEY,
                session_id INT NOT NULL,
                name VARCHAR(150) NOT NULL,
                severity VARCHAR(30) NOT NULL,
                duration_days INT NOT NULL,
                body_part VARCHAR(100),
                is_red_flag TINYINT(1) NOT NULL DEFAULT 0,
                CONSTRAINT fk_symptom_session FOREIGN KEY (session_id) REFERENCES symptom_session(session_id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        """);

        // 5. triage_result
        stmt.execute("""
            CREATE TABLE IF NOT EXISTS triage_result (
                result_id INT AUTO_INCREMENT PRIMARY KEY,
                session_id INT NOT NULL UNIQUE,
                urgency VARCHAR(30) NOT NULL,
                recommendation TEXT NOT NULL,
                department VARCHAR(150) NOT NULL,
                reason TEXT NOT NULL,
                rule_matched VARCHAR(100),
                confidence_score DOUBLE NOT NULL,
                speech_response TEXT NOT NULL,
                created_at VARCHAR(50) NOT NULL,
                CONSTRAINT fk_triage_session FOREIGN KEY (session_id) REFERENCES symptom_session(session_id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        """);

        // 6. chat_session
        stmt.execute("""
            CREATE TABLE IF NOT EXISTS chat_session (
                chat_id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                language VARCHAR(20) NOT NULL,
                created_at VARCHAR(50) NOT NULL,
                CONSTRAINT fk_chat_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        """);

        // 7. chat_message
        stmt.execute("""
            CREATE TABLE IF NOT EXISTS chat_message (
                message_id INT AUTO_INCREMENT PRIMARY KEY,
                chat_id INT NOT NULL,
                sender VARCHAR(20) NOT NULL,
                message TEXT NOT NULL,
                intent VARCHAR(50) NOT NULL,
                created_at VARCHAR(50) NOT NULL,
                CONSTRAINT fk_msg_session FOREIGN KEY (chat_id) REFERENCES chat_session(chat_id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        """);

        // 8. food_plan
        stmt.execute("""
            CREATE TABLE IF NOT EXISTS food_plan (
                plan_id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                query VARCHAR(255) NOT NULL,
                meal_type VARCHAR(50) NOT NULL,
                plan_text TEXT NOT NULL,
                calories_target INT NOT NULL,
                dietary_advice TEXT,
                created_at VARCHAR(50) NOT NULL,
                CONSTRAINT fk_food_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        """);

        // 9. medical_record
        stmt.execute("""
            CREATE TABLE IF NOT EXISTS medical_record (
                record_id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                type VARCHAR(50) NOT NULL,
                file_name VARCHAR(255) NOT NULL,
                file_path VARCHAR(500) NOT NULL,
                file_size BIGINT NOT NULL,
                upload_date VARCHAR(50) NOT NULL,
                description TEXT,
                CONSTRAINT fk_record_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        """);

        // 10. first_aid_guide
        stmt.execute("""
            CREATE TABLE IF NOT EXISTS first_aid_guide (
                guide_id INT AUTO_INCREMENT PRIMARY KEY,
                scenario VARCHAR(50) NOT NULL UNIQUE,
                title VARCHAR(150) NOT NULL,
                language VARCHAR(20) NOT NULL,
                steps TEXT NOT NULL,
                red_flags TEXT NOT NULL,
                escalation TEXT NOT NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        """);

        // 11. sos_event
        stmt.execute("""
            CREATE TABLE IF NOT EXISTS sos_event (
                sos_id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                timestamp VARCHAR(50) NOT NULL,
                location VARCHAR(255) NOT NULL,
                contact VARCHAR(150) NOT NULL,
                phone VARCHAR(50) NOT NULL,
                status VARCHAR(50) NOT NULL,
                notes TEXT,
                CONSTRAINT fk_sos_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        """);

        // 12. medication
        stmt.execute("""
            CREATE TABLE IF NOT EXISTS medication (
                medication_id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                medicine_name VARCHAR(150) NOT NULL,
                dosage VARCHAR(100) NOT NULL,
                frequency VARCHAR(100) NOT NULL,
                instructions TEXT,
                created_at VARCHAR(50) NOT NULL,
                CONSTRAINT fk_med_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        """);

        // 13. reminder
        stmt.execute("""
            CREATE TABLE IF NOT EXISTS reminder (
                reminder_id INT AUTO_INCREMENT PRIMARY KEY,
                medication_id INT NOT NULL,
                medicine_name VARCHAR(150) NOT NULL,
                dosage VARCHAR(100) NOT NULL,
                reminder_time VARCHAR(10) NOT NULL,
                frequency VARCHAR(50) NOT NULL,
                active TINYINT(1) NOT NULL DEFAULT 1,
                last_triggered VARCHAR(50),
                CONSTRAINT fk_reminder_med FOREIGN KEY (medication_id) REFERENCES medication(medication_id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        """);
    }

    private void initSQLiteTables(Statement stmt) throws SQLException {
        stmt.execute("PRAGMA foreign_keys = ON;");
        stmt.execute("PRAGMA journal_mode = WAL;");

        stmt.execute("""
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                created_at TEXT NOT NULL
            );
        """);

        stmt.execute("""
            CREATE TABLE IF NOT EXISTS user_profile (
                profile_id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER UNIQUE NOT NULL,
                name TEXT NOT NULL,
                gender TEXT NOT NULL,
                age INTEGER NOT NULL,
                height REAL NOT NULL,
                weight REAL NOT NULL,
                blood_group TEXT,
                emergency_contact TEXT,
                contact_phone TEXT,
                FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
            );
        """);

        stmt.execute("""
            CREATE TABLE IF NOT EXISTS symptom_session (
                session_id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                input_text TEXT NOT NULL,
                language TEXT NOT NULL,
                created_at TEXT NOT NULL,
                FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
            );
        """);

        stmt.execute("""
            CREATE TABLE IF NOT EXISTS symptom (
                symptom_id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id INTEGER NOT NULL,
                name TEXT NOT NULL,
                severity TEXT NOT NULL,
                duration_days INTEGER NOT NULL,
                body_part TEXT,
                is_red_flag INTEGER NOT NULL DEFAULT 0,
                FOREIGN KEY (session_id) REFERENCES symptom_session(session_id) ON DELETE CASCADE
            );
        """);

        stmt.execute("""
            CREATE TABLE IF NOT EXISTS triage_result (
                result_id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id INTEGER UNIQUE NOT NULL,
                urgency TEXT NOT NULL,
                recommendation TEXT NOT NULL,
                department TEXT NOT NULL,
                reason TEXT NOT NULL,
                rule_matched TEXT,
                confidence_score REAL NOT NULL,
                speech_response TEXT NOT NULL,
                created_at TEXT NOT NULL,
                FOREIGN KEY (session_id) REFERENCES symptom_session(session_id) ON DELETE CASCADE
            );
        """);

        stmt.execute("""
            CREATE TABLE IF NOT EXISTS chat_session (
                chat_id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                language TEXT NOT NULL,
                created_at TEXT NOT NULL,
                FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
            );
        """);

        stmt.execute("""
            CREATE TABLE IF NOT EXISTS chat_message (
                message_id INTEGER PRIMARY KEY AUTOINCREMENT,
                chat_id INTEGER NOT NULL,
                sender TEXT NOT NULL,
                message TEXT NOT NULL,
                intent TEXT NOT NULL,
                created_at TEXT NOT NULL,
                FOREIGN KEY (chat_id) REFERENCES chat_session(chat_id) ON DELETE CASCADE
            );
        """);

        stmt.execute("""
            CREATE TABLE IF NOT EXISTS food_plan (
                plan_id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                query TEXT NOT NULL,
                meal_type TEXT NOT NULL,
                plan_text TEXT NOT NULL,
                calories_target INTEGER NOT NULL,
                dietary_advice TEXT,
                created_at TEXT NOT NULL,
                FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
            );
        """);

        stmt.execute("""
            CREATE TABLE IF NOT EXISTS medical_record (
                record_id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                type TEXT NOT NULL,
                file_name TEXT NOT NULL,
                file_path TEXT NOT NULL,
                file_size INTEGER NOT NULL,
                upload_date TEXT NOT NULL,
                description TEXT,
                FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
            );
        """);

        stmt.execute("""
            CREATE TABLE IF NOT EXISTS first_aid_guide (
                guide_id INTEGER PRIMARY KEY AUTOINCREMENT,
                scenario TEXT UNIQUE NOT NULL,
                title TEXT NOT NULL,
                language TEXT NOT NULL,
                steps TEXT NOT NULL,
                red_flags TEXT NOT NULL,
                escalation TEXT NOT NULL
            );
        """);

        stmt.execute("""
            CREATE TABLE IF NOT EXISTS sos_event (
                sos_id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                timestamp TEXT NOT NULL,
                location TEXT NOT NULL,
                contact TEXT NOT NULL,
                phone TEXT NOT NULL,
                status TEXT NOT NULL,
                notes TEXT,
                FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
            );
        """);

        stmt.execute("""
            CREATE TABLE IF NOT EXISTS medication (
                medication_id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                medicine_name TEXT NOT NULL,
                dosage TEXT NOT NULL,
                frequency TEXT NOT NULL,
                instructions TEXT,
                created_at TEXT NOT NULL,
                FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
            );
        """);

        stmt.execute("""
            CREATE TABLE IF NOT EXISTS reminder (
                reminder_id INTEGER PRIMARY KEY AUTOINCREMENT,
                medication_id INTEGER NOT NULL,
                medicine_name TEXT NOT NULL,
                dosage TEXT NOT NULL,
                reminder_time TEXT NOT NULL,
                frequency TEXT NOT NULL,
                active INTEGER NOT NULL DEFAULT 1,
                last_triggered TEXT,
                FOREIGN KEY (medication_id) REFERENCES medication(medication_id) ON DELETE CASCADE
            );
        """);
    }

    public boolean isConnectedToMySQL() {
        return isConnectedToMySQL;
    }
}
