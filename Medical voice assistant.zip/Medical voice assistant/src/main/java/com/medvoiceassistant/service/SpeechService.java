package com.medvoiceassistant.service;

import java.util.HashMap;
import java.util.Map;

public class SpeechService {

    public String generateSpokenResponse(String urgency, String department, String recommendation, String language) {
        StringBuilder sb = new StringBuilder();
        String lang = (language != null && !language.isEmpty()) ? language.toLowerCase() : "en";

        department = cleanForSpeech(department, lang);
        recommendation = cleanForSpeech(recommendation, lang);

        switch (urgency.toUpperCase()) {
            case "EMERGENCY":
                if ("ta".equals(lang)) {
                    sb.append("அவசர எச்சரிக்கை! உங்களுக்கு உடனடி மருத்துவ கவனிப்பு தேவை. ");
                    sb.append("தயவுசெய்து உடனடியாக அவசர சிகிச்சை பிரிவு அல்லது 108 ஐ தொடர்பு கொள்ளவும். ");
                    sb.append(recommendation);
                } else if ("hi".equals(lang)) {
                    sb.append("आपातकालीन चेतावनी! आपको तत्काल चिकित्सा सहायता की आवश्यकता है। ");
                    sb.append("कृपया तुरंत निकटतम आपातकालीन कक्ष या 108 पर संपर्क करें। ");
                    sb.append(recommendation);
                } else if ("te".equals(lang)) {
                    sb.append("అత్యవసర హెచ్చరిక! మీకు తక్షణ వైద్య సహాయం అవసరం. ");
                    sb.append("దయచేసి వెంటనే 108 లేదా సమీపంలోని అత్యవసర విభాగానికి వెళ్ళండి. ");
                    sb.append(recommendation);
                } else if ("kn".equals(lang)) {
                    sb.append("ತುರ್ತು ಎಚ್ಚರಿಕೆ! ನಿಮಗೆ ತಕ್ಷಣದ ವೈದ್ಯಕೀಯ ನೆರವು ಅಗತ್ಯವಿದೆ. ");
                    sb.append("ದಯವಿಟ್ಟು ತಕ್ಷಣ 108 ಅಥವಾ ಹತ್ತಿರದ ತುರ್ತು ಚಿಕಿತ್ಸಾ ವಿಭಾಗಕ್ಕೆ ಸಂಪರ್ಕಿಸಿ. ");
                    sb.append(recommendation);
                } else if ("ml".equals(lang)) {
                    sb.append("അടിയന്തര മുന്നറിയിപ്പ്! നിങ്ങൾക്ക് ഉടനടി വൈദ്യസഹായം ആവശ്യമാണ്. ");
                    sb.append("ദയവായി ഉടൻ 108 അല്ലെങ്കിൽ അടുത്തുള്ള അത്യാഹിത വിഭാഗവുമായി ബന്ധപ്പെടുക. ");
                    sb.append(recommendation);
                } else if ("bn".equals(lang)) {
                    sb.append("জরুরি সতর্কতা! আপনার অবিলম্বে চিকিৎসা মূল্যায়ন প্রয়োজন। অবিলম্বে জরুরি পরিষেবা (108 বা 999) এর সাথে যোগাযোগ করুন। ");
                    sb.append(recommendation);
                } else if ("mr".equals(lang)) {
                    sb.append("तातडीचा इशारा! तुमच्या लक्षणांसाठी त्वरित वैद्यकीय उपचारांची आवश्यकता आहे. कृपया ताबडतोब 108 वर संपर्क साधा. ");
                    sb.append(recommendation);
                } else if ("ur".equals(lang)) {
                    sb.append("ہنگامی انتباہ! آپ کی علامات فوری طبی امداد کا تقاضا کرتی ہیں۔ براہ کرم فوراً ایمرجنسی سروسز سے رابطہ کریں۔ ");
                    sb.append(recommendation);
                } else if ("ar".equals(lang)) {
                    sb.append("تنبيه طوارئ! تشير أعراضك إلى حالة حرجة تتطلب تقييماً طبياً فورياً. يرجى الاتصال بالإسعاف أو التوجه لأقرب طوارئ. ");
                    sb.append(recommendation);
                } else if ("ru".equals(lang)) {
                    sb.append("Экстренное предупреждение! Ваши симптомы требуют немедленной медицинской помощи. Пожалуйста, срочно обратитесь в скорую помощь (112 или 103) или в ближайшее отделение неотложной помощи. ");
                    sb.append(recommendation);
                } else if ("ja".equals(lang)) {
                    sb.append("緊急警告！直ちに医療評価が必要です。至急119番通報するか、最寄りの救急外来を受診してください。");
                    sb.append(recommendation);
                } else if ("ko".equals(lang)) {
                    sb.append("응급 경고! 즉각적인 응급 의료 평가가 필요합니다. 즉시 119로 연락하거나 가까운 응급실을 방문하세요. ");
                    sb.append(recommendation);
                } else if ("zh".equals(lang)) {
                    sb.append("紧急警报！您的症状需要立即进行医疗评估。请立即拨打急救电话（120或911）或前往急诊室。");
                    sb.append(recommendation);
                } else if ("th".equals(lang)) {
                    sb.append("แจ้งเตือนฉุกเฉิน! อาการของคุณต้องได้รับการรักษาทางการแพทย์ทันที กรุณาโทร 1669 หรือไปห้องฉุกเฉินทันที ");
                    sb.append(recommendation);
                } else if ("pt".equals(lang)) {
                    sb.append("Alerta de emergência! Seus sintomas indicam uma condição crítica que requer atenção médica imediata. ");
                    sb.append("Por favor, ligue para os serviços de emergência ou vá ao pronto-socorro mais próximo. ");
                    sb.append(recommendation);
                } else if ("es".equals(lang)) {
                    sb.append("¡Alerta de emergencia! Sus síntomas requieren atención médica inmediata. ");
                    sb.append("Por favor llame a emergencias o acuda al hospital más cercano. ");
                    sb.append(recommendation);
                } else if ("fr".equals(lang)) {
                    sb.append("Alerte d'urgence ! Vos symptômes nécessitent une évaluation médicale immédiate. ");
                    sb.append("Veuillez contacter le Samu ou les urgences immédiatement. ");
                    sb.append(recommendation);
                } else if ("de".equals(lang)) {
                    sb.append("Notfallwarnung! Ihre Symptome erfordern sofortige ärztliche Behandlung. ");
                    sb.append("Bitte rufen Sie den Notruf an oder suchen Sie die Notaufnahme auf. ");
                    sb.append(recommendation);
                } else if ("it".equals(lang)) {
                    sb.append("Allarme di emergenza! I suoi sintomi richiedono un intervento medico immediato. ");
                    sb.append("Chiami il 118 o si rechi al pronto soccorso più vicino. ");
                    sb.append(recommendation);
                } else {
                    sb.append("Emergency Alert! Your symptoms indicate a potentially serious condition requiring immediate medical evaluation. ");
                    sb.append("Please contact emergency services (such as 108 or 911) or proceed immediately to the nearest emergency department. ");
                    sb.append(recommendation);
                }
                break;

            case "MODERATE":
                if ("ta".equals(lang)) {
                    sb.append("கவனிக்கத்தக்க நிலைமை. விரைவில் ஒரு மருத்துவரை அணுகுமாறு பரிந்துரைக்கிறோம். ");
                    sb.append("பரிந்துரைக்கப்படும் பிரிவு: ").append(department).append(". ");
                    sb.append(recommendation);
                } else if ("hi".equals(lang)) {
                    sb.append("मध्यम स्थिति। हम सलाह देते हैं कि आप शीघ्र ही डॉक्टर से परामर्श लें। ");
                    sb.append("सुझाया गया विभाग: ").append(department).append(". ");
                    sb.append(recommendation);
                } else if ("te".equals(lang)) {
                    sb.append("మధ్యస్థ ప్రాధాన్యత. మీరు త్వరలోనే ఒక వైద్యుడిని సంప్రదించాలని సిఫార్సు చేస్తున్నాము. ");
                    sb.append("సిఫార్సు చేయబడిన విభాగం: ").append(department).append(". ");
                    sb.append(recommendation);
                } else if ("kn".equals(lang)) {
                    sb.append("ಮಧ್ಯಮ ಆದ್ಯತೆ. ನೀವು ಶೀಘ್ರದಲ್ಲೇ ವೈದ್ಯರನ್ನು ಸಂಪರ್ಕಿಸಲು ಶಿಫಾರಸು ಮಾಡುತ್ತೇವೆ. ");
                    sb.append("ಶಿಫಾರಸು ಮಾಡಿದ ವಿಭಾಗ: ").append(department).append(". ");
                    sb.append(recommendation);
                } else if ("ml".equals(lang)) {
                    sb.append("മിതമായ മുൻഗണന. ഉടൻ തന്നെ ഒരു ഡോക്ടറെ കാണാൻ നിർദ്ദേശിക്കുന്നു. ");
                    sb.append("ശുപാർശ ചെയ്യുന്ന വിഭാഗം: ").append(department).append(". ");
                    sb.append(recommendation);
                } else if ("bn".equals(lang)) {
                    sb.append("মাঝারি অগ্রাধিকার। আমরা শীঘ্রই একজন ডাক্তারের সাথে পরামর্শ করার পরামর্শ দিচ্ছি। ");
                    sb.append("প্রস্তাবিত বিভাগ: ").append(department).append(". ");
                    sb.append(recommendation);
                } else if ("mr".equals(lang)) {
                    sb.append("मध्यम प्राधान्य. आम्ही शिफारस करतो की तुम्ही लवकरच डॉक्टरांचा सल्ला घ्यावा. ");
                    sb.append("शिफारस केलेले विभाग: ").append(department).append(". ");
                    sb.append(recommendation);
                } else if ("ur".equals(lang)) {
                    sb.append("درمیانی ترجیح۔ ہم مشورہ دیتے ہیں کہ آپ جلد ہی ڈاکٹر سے رجوع کریں۔ ");
                    sb.append("تجویز کردہ شعبہ: ").append(department).append(". ");
                    sb.append(recommendation);
                } else if ("ar".equals(lang)) {
                    sb.append("أولوية متوسطة. نوصي باستشارة طبيب مختص قريباً. ");
                    sb.append("التخصص الموصى به: ").append(department).append(". ");
                    sb.append(recommendation);
                } else if ("ru".equals(lang)) {
                    sb.append("Умеренный приоритет. Рекомендуем в ближайшее время проконсультироваться с врачом. ");
                    sb.append("Рекомендуемое отделение: ").append(department).append(". ");
                    sb.append(recommendation);
                } else if ("ja".equals(lang)) {
                    sb.append("中等度の優先度です。早めに医師の診察を受けることをお勧めします。");
                    sb.append("推奨診療科: ").append(department).append("。");
                    sb.append(recommendation);
                } else if ("ko".equals(lang)) {
                    sb.append("중간 우선순위입니다. 빠른 시일 내에 전문의 진료를 권장합니다. ");
                    sb.append("권장 진료과: ").append(department).append(". ");
                    sb.append(recommendation);
                } else if ("zh".equals(lang)) {
                    sb.append("中等优先级。建议您尽快预约专科医生就诊。");
                    sb.append("推荐科室：").append(department).append("。");
                    sb.append(recommendation);
                } else if ("th".equals(lang)) {
                    sb.append("ระดับความสำคัญปานกลาง แนะนำให้ปรึกษาแพทย์ในเร็วๆ นี้ ");
                    sb.append("แผนกที่แนะนำ: ").append(department).append(". ");
                    sb.append(recommendation);
                } else if ("pt".equals(lang)) {
                    sb.append("Prioridade moderada. Recomendamos agendar uma consulta médica em breve. ");
                    sb.append("Especialidade recomendada: ").append(department).append(". ");
                    sb.append(recommendation);
                } else if ("es".equals(lang)) {
                    sb.append("Prioridad moderada. Le recomendamos consultar a un médico pronto. ");
                    sb.append("Especialidad recomendada: ").append(department).append(". ");
                    sb.append(recommendation);
                } else if ("fr".equals(lang)) {
                    sb.append("Priorité modérée. Nous vous recommandons de consulter un médecin prochainement. ");
                    sb.append("Spécialité recommandée : ").append(department).append(". ");
                    sb.append(recommendation);
                } else if ("de".equals(lang)) {
                    sb.append("Mäßige Dringlichkeit. Wir empfehlen zeitnah einen Arzttermin zu vereinbaren. ");
                    sb.append("Empfohlene Fachrichtung: ").append(department).append(". ");
                    sb.append(recommendation);
                } else if ("it".equals(lang)) {
                    sb.append("Priorità moderata. Si raccomanda di consultare un medico a breve. ");
                    sb.append("Reparto consigliato: ").append(department).append(". ");
                    sb.append(recommendation);
                } else {
                    sb.append("Moderate priority. We recommend scheduling an appointment with a healthcare professional soon. ");
                    sb.append("Recommended specialty: ").append(department).append(". ");
                    sb.append(recommendation);
                }
                break;

            case "SELF_CARE":
                if ("ta".equals(lang)) {
                    sb.append("உங்கள் அறிகுறிகள் மிதமானவை. வீட்டில் சுய பாதுகாப்பு வழிமுறைகளைப் பின்பற்றலாம். ");
                    sb.append(recommendation);
                    sb.append(" அறிகுறிகள் தீவிரமடைந்தால் மருத்துவரை அணுகவும்.");
                } else if ("hi".equals(lang)) {
                    sb.append("आपके लक्षण हल्के दिखाई देते हैं। आप घर पर स्व-देखभाल के उपाय कर सकते हैं। ");
                    sb.append(recommendation);
                    sb.append(" यदि लक्षण बिगड़ें तो डॉक्टर से मिलें।");
                } else if ("te".equals(lang)) {
                    sb.append("మీ లక్షణాలు స్వల్పంగా ఉన్నాయి. ఇంటి వద్ద సాధారణ స్వీయ సంరక్షణ పాటించవచ్చు. ");
                    sb.append(recommendation);
                    sb.append(" లక్షణాలు తీవ్రమైతే వెంటనే వైద్యుడిని సంప్రదించండి.");
                } else if ("kn".equals(lang)) {
                    sb.append("ನಿಮ್ಮ ಲಕ್ಷಣಗಳು ಸೌಮ್ಯವಾಗಿವೆ. ಮನೆಯಲ್ಲಿ ಸಾಮಾನ್ಯ ಆರೈಕೆ ಕ್ರಮಗಳನ್ನು ಅನುಸರಿಸಬಹುದು. ");
                    sb.append(recommendation);
                    sb.append(" ಲಕ್ಷಣಗಳು ಉಲ್ಬಣಿಸಿದರೆ ವೈದ್ಯರನ್ನು ಸಂಪರ್ಕಿಸಿ.");
                } else if ("ml".equals(lang)) {
                    sb.append("നിങ്ങളുടെ ലക്ഷണങ്ങൾ ലഘുവാണ്. വീട്ടിലെ സ്വയം പരിചരണ മാർഗ്ഗങ്ങൾ പാലിക്കാം. ");
                    sb.append(recommendation);
                    sb.append(" ലക്ഷണങ്ങൾ കൂടിയാൽ ഡോക്ടറെ സമീപിക്കുക.");
                } else if ("bn".equals(lang)) {
                    sb.append("আপনার লক্ষণগুলি মৃদু এবং ঘরে প্রাথমিক যত্নের জন্য উপযুক্ত। ");
                    sb.append(recommendation);
                    sb.append(" লক্ষণ খারাপ হলে ডাক্তারের পরামর্শ নিন।");
                } else if ("mr".equals(lang)) {
                    sb.append("तुमची लक्षणे सौम्य आहेत आणि घरगुती काळजीसाठी योग्य आहेत. ");
                    sb.append(recommendation);
                    sb.append(" लक्षणे वाढल्यास डॉक्टरांचा सल्ला घ्या.");
                } else if ("ur".equals(lang)) {
                    sb.append("آپ کی علامات ہلکی ہیں اور گھریلو دیکھ بھال کے لیے مناسب ہیں۔ ");
                    sb.append(recommendation);
                    sb.append(" اگر علامات بگڑیں تو ڈاکٹر سے رجوع کریں۔");
                } else if ("ar".equals(lang)) {
                    sb.append("أعراضك تبدو خفيفة ومناسبة للرعاية المنزلية. ");
                    sb.append(recommendation);
                    sb.append(" إذا تفاقمت الأعراض يرجى مراجعة الطبيب.");
                } else if ("ru".equals(lang)) {
                    sb.append("Ваши симптомы кажутся лёгкими и подходят для домашнего ухода. ");
                    sb.append(recommendation);
                    sb.append(" Если симптомы ухудшатся, обратитесь к врачу.");
                } else if ("ja".equals(lang)) {
                    sb.append("症状は軽度であり、ご自宅でのセルフケアに適しています。");
                    sb.append(recommendation);
                    sb.append(" 症状が悪化する場合は医師にご相談ください。");
                } else if ("ko".equals(lang)) {
                    sb.append("증상이 경미하여 자택에서의 자가 관리에 적합합니다. ");
                    sb.append(recommendation);
                    sb.append(" 증상이 악화되면 의사와 상담하세요.");
                } else if ("zh".equals(lang)) {
                    sb.append("您的症状较轻微，适合居家日常调理。");
                    sb.append(recommendation);
                    sb.append(" 若症状加重，请及时就医。");
                } else if ("th".equals(lang)) {
                    sb.append("อาการของคุณดูไม่รุนแรง สามารถดูแลตัวเองเบื้องต้นได้ ");
                    sb.append(recommendation);
                    sb.append(" หากอาการไม่ดีขึ้นโปรดพบแพทย์");
                } else if ("pt".equals(lang)) {
                    sb.append("Seus sintomas parecem ser leves e adequados para cuidados gerais em casa. ");
                    sb.append(recommendation);
                    sb.append(" Se os sintomas piorarem, consulte um médico.");
                } else if ("es".equals(lang)) {
                    sb.append("Sus síntomas parecen leves y adecuados para el cuidado personal en el hogar. ");
                    sb.append(recommendation);
                    sb.append(" Si los síntomas empeoran, consulte a un médico.");
                } else if ("fr".equals(lang)) {
                    sb.append("Vos symptômes semblent légers et adaptés à des soins à domicile. ");
                    sb.append(recommendation);
                    sb.append(" Si les symptômes s'aggravent, consultez un médecin.");
                } else if ("de".equals(lang)) {
                    sb.append("Ihre Symptome scheinen mild zu sein und eignen sich für häusliche Selbstpflege. ");
                    sb.append(recommendation);
                    sb.append(" Sollten sich die Symptome verschlimmern, suchen Sie einen Arzt auf.");
                } else if ("it".equals(lang)) {
                    sb.append("I suoi sintomi sembrano lievi e adatti a cure domiciliari generali. ");
                    sb.append(recommendation);
                    sb.append(" Se i sintomi pegjorano, consultare un medico.");
                } else {
                    sb.append("Your symptoms appear to be mild and suitable for general self-care. ");
                    sb.append(recommendation);
                    sb.append(" If symptoms worsen or do not improve within 48 to 72 hours, please consult a physician.");
                }
                break;

            default:
                if ("ta".equals(lang)) {
                    sb.append("உங்கள் அறிகுறிகளைப் பகிர்ந்தமைக்கு நன்றி. ").append(recommendation).append(" உடல்நிலை சரியில்லாததாக உணர்ந்தால் உடனடியாக மருத்துவரை அணுகவும்.");
                } else if ("hi".equals(lang)) {
                    sb.append("अपने लक्षण साझा करने के लिए धन्यवाद। ").append(recommendation).append(" यदि आप अस्वस्थ महसूस करते हैं, तो कृपया तुरंत डॉक्टर से संपर्क करें।");
                } else if ("te".equals(lang)) {
                    sb.append("మీ లక్షణాలను తెలిపినందుకు ధన్యవాదాలు. ").append(recommendation).append(" మీకు అసౌకర్యంగా ఉంటే వెంటనే వైద్యుడిని సంప్రదించండి.");
                } else if ("kn".equals(lang)) {
                    sb.append("ನಿಮ್ಮ ರೋಗಲಕ್ಷಣಗಳನ್ನು ತಿಳಿಸಿದ್ದಕ್ಕಾಗಿ ಧನ್ಯವಾದಗಳು. ").append(recommendation).append(" ನಿಮಗೆ ಅಸ್ವಸ್ಥತೆ ಎನಿಸಿದರೆ ತಕ್ಷಣ ವೈದ್ಯರನ್ನು ಸಂಪರ್ಕಿಸಿ.");
                } else if ("ml".equals(lang)) {
                    sb.append("നിങ്ങളുടെ ലക്ഷണങ്ങൾ പങ്കുവെച്ചതിന് നന്ദി. ").append(recommendation).append(" നിങ്ങൾക്ക് അസ്വസ്ഥത തോന്നുകയാണെങ്കിൽ ഉടൻ തന്നെ ഡോക്ടറെ സമീപിക്കുക.");
                } else if ("bn".equals(lang)) {
                    sb.append("আপনার লক্ষণগুলি ভাগ করার জন্য ধন্যবাদ। ").append(recommendation).append(" আপনার অসুস্থ বোধ হলে অবিলম্বে ডাক্তারের পরামর্শ নিন।");
                } else if ("mr".equals(lang)) {
                    sb.append("तुमची लक्षणे सांगितल्याबद्दल धन्यवाद. ").append(recommendation).append(" त्रास जाणवत असल्यास कृपया त्वरित डॉक्टरांचा सल्ला घ्या.");
                } else if ("ur".equals(lang)) {
                    sb.append("اپنی علامات بتانے کا شکریہ۔ ").append(recommendation).append(" اگر آپ کی طبیعت خراب ہو تو فوراً ڈاکٹر سے رجوع کریں۔");
                } else if ("ar".equals(lang)) {
                    sb.append("شكراً لمشاركتك أعراضك. ").append(recommendation).append(" إذا شعرت بتوعك يرجى استشارة الطبيب على الفور.");
                } else if ("ru".equals(lang)) {
                    sb.append("Спасибо, что описали свои симптомы. ").append(recommendation).append(" Если почувствуете ухудшение, обратитесь к врачу.");
                } else if ("ja".equals(lang)) {
                    sb.append("症状をお知らせいただきありがとうございます。").append(recommendation).append(" 体調がすぐれない場合は、速やかに医師にご相談ください。");
                } else if ("ko".equals(lang)) {
                    sb.append("증상을 공유해 주셔서 감사합니다. ").append(recommendation).append(" 몸 상태가 좋지 않으면 즉시 의사와 상담하세요.");
                } else if ("zh".equals(lang)) {
                    sb.append("感谢您说明病情。").append(recommendation).append(" 如有身体不适，请及时就医咨询医生。");
                } else if ("th".equals(lang)) {
                    sb.append("ขอบคุณที่แจ้งอาการของคุณ ").append(recommendation).append(" หากรู้สึกไม่สบายโปรดปรึกษาแพทย์ทันที");
                } else if ("es".equals(lang)) {
                    sb.append("Gracias por compartir sus síntomas. ").append(recommendation).append(" Si no se siente bien, consulte a un médico pronto.");
                } else if ("pt".equals(lang)) {
                    sb.append("Obrigado por compartilhar seus sintomas. ").append(recommendation).append(" Se não se sentir bem, consulte um médico em breve.");
                } else if ("fr".equals(lang)) {
                    sb.append("Merci de nous avoir décrit vos symptômes. ").append(recommendation).append(" Si vous ne vous sentez pas bien, consultez rapidement un médecin.");
                } else if ("de".equals(lang)) {
                    sb.append("Vielen Dank für Ihre Symptombeschreibung. ").append(recommendation).append(" Sollten Sie sich unwohl fühlen, wenden Sie sich bitte an einen Arzt.");
                } else if ("it".equals(lang)) {
                    sb.append("Grazie per aver descritto i suoi sintomi. ").append(recommendation).append(" Se non si sente bene, consulti tempestivamente un medico.");
                } else {
                    sb.append("Thank you for sharing your symptoms. ").append(recommendation).append(" If you feel unwell or in distress, please seek medical advice promptly.");
                }
                break;
        }

        return sb.toString();
    }

    private String cleanForSpeech(String text, String lang) {
        if (text == null) return "";
        if ("en".equals(lang)) return text;
        // For non-English languages, strip English parenthesized notes like (Orthopedics & Trauma Care), (Cardiology & Emergency), (X-Ray), etc.
        // so the TTS engine speaks purely in the target language!
        String cleaned = text.replaceAll("\\s*\\([A-Za-z0-9\\s&,/\\-–—]+\\)", "");
        return cleaned.replaceAll("\\s{2,}", " ").trim();
    }

    public Map<String, Object> getSpeechConfig(String language) {
        Map<String, Object> cfg = new HashMap<>();
        String lang = (language != null) ? language.toLowerCase() : "en";
        switch (lang) {
            case "ta":
                cfg.put("langCode", "ta-IN");
                cfg.put("voiceName", "Tamil India");
                cfg.put("rate", 0.95);
                cfg.put("pitch", 1.0);
                break;
            case "hi":
                cfg.put("langCode", "hi-IN");
                cfg.put("voiceName", "Hindi India");
                cfg.put("rate", 0.95);
                cfg.put("pitch", 1.0);
                break;
            case "te":
                cfg.put("langCode", "te-IN");
                cfg.put("voiceName", "Telugu India");
                cfg.put("rate", 0.95);
                cfg.put("pitch", 1.0);
                break;
            case "kn":
                cfg.put("langCode", "kn-IN");
                cfg.put("voiceName", "Kannada India");
                cfg.put("rate", 0.95);
                cfg.put("pitch", 1.0);
                break;
            case "ml":
                cfg.put("langCode", "ml-IN");
                cfg.put("voiceName", "Malayalam India");
                cfg.put("rate", 0.95);
                cfg.put("pitch", 1.0);
                break;
            case "bn":
                cfg.put("langCode", "bn-IN");
                cfg.put("voiceName", "Bengali India");
                cfg.put("rate", 0.95);
                cfg.put("pitch", 1.0);
                break;
            case "mr":
                cfg.put("langCode", "mr-IN");
                cfg.put("voiceName", "Marathi India");
                cfg.put("rate", 0.95);
                cfg.put("pitch", 1.0);
                break;
            case "ur":
                cfg.put("langCode", "ur-PK");
                cfg.put("voiceName", "Urdu Pakistan");
                cfg.put("rate", 0.95);
                cfg.put("pitch", 1.0);
                break;
            case "ar":
                cfg.put("langCode", "ar-SA");
                cfg.put("voiceName", "Arabic Saudi Arabia");
                cfg.put("rate", 0.95);
                cfg.put("pitch", 1.0);
                break;
            case "ru":
                cfg.put("langCode", "ru-RU");
                cfg.put("voiceName", "Russian Russia");
                cfg.put("rate", 1.0);
                cfg.put("pitch", 1.0);
                break;
            case "ja":
                cfg.put("langCode", "ja-JP");
                cfg.put("voiceName", "Japanese Japan");
                cfg.put("rate", 1.0);
                cfg.put("pitch", 1.0);
                break;
            case "ko":
                cfg.put("langCode", "ko-KR");
                cfg.put("voiceName", "Korean South Korea");
                cfg.put("rate", 1.0);
                cfg.put("pitch", 1.0);
                break;
            case "zh":
                cfg.put("langCode", "zh-CN");
                cfg.put("voiceName", "Chinese China");
                cfg.put("rate", 1.0);
                cfg.put("pitch", 1.0);
                break;
            case "th":
                cfg.put("langCode", "th-TH");
                cfg.put("voiceName", "Thai Thailand");
                cfg.put("rate", 1.0);
                cfg.put("pitch", 1.0);
                break;
            case "es":
                cfg.put("langCode", "es-ES");
                cfg.put("voiceName", "Spanish");
                cfg.put("rate", 1.0);
                cfg.put("pitch", 1.0);
                break;
            case "pt":
                cfg.put("langCode", "pt-PT");
                cfg.put("voiceName", "Portuguese");
                cfg.put("rate", 1.0);
                cfg.put("pitch", 1.0);
                break;
            case "fr":
                cfg.put("langCode", "fr-FR");
                cfg.put("voiceName", "French");
                cfg.put("rate", 1.0);
                cfg.put("pitch", 1.0);
                break;
            case "de":
                cfg.put("langCode", "de-DE");
                cfg.put("voiceName", "German");
                cfg.put("rate", 1.0);
                cfg.put("pitch", 1.0);
                break;
            case "it":
                cfg.put("langCode", "it-IT");
                cfg.put("voiceName", "Italian");
                cfg.put("rate", 1.0);
                cfg.put("pitch", 1.0);
                break;
            default:
                cfg.put("langCode", "en-US");
                cfg.put("voiceName", "English US");
                cfg.put("rate", 1.0);
                cfg.put("pitch", 1.0);
                break;
        }
        return cfg;
    }
}
