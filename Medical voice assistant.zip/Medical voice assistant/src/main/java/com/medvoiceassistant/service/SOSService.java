package com.medvoiceassistant.service;

import com.medvoiceassistant.model.SOSEvent;
import com.medvoiceassistant.model.UserProfile;
import com.medvoiceassistant.repository.SOSRepository;
import com.medvoiceassistant.repository.UserProfileRepository;
import com.medvoiceassistant.util.DateTimeUtil;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public class SOSService {
    private final SOSRepository repository = new SOSRepository();
    private final UserProfileRepository profileRepo = new UserProfileRepository();

    public Map<String, Object> triggerSOS(int userId, String customLocation, String reason) {
        return triggerSOS(userId, customLocation, reason, null);
    }

    public Map<String, Object> triggerSOS(int userId, String customLocation, String reason, String customPhone) {
        String now = DateTimeUtil.now();
        Optional<UserProfile> profileOpt = profileRepo.findByUserId(userId);

        String contact = "Family Guardian";
        String phone = "+91 8220664059";
        String userName = "Patient #" + userId;

        if (profileOpt.isPresent()) {
            UserProfile p = profileOpt.get();
            userName = p.getName();
            if (p.getEmergencyContact() != null && !p.getEmergencyContact().isEmpty()) {
                contact = p.getEmergencyContact();
            }
            if (p.getContactPhone() != null && !p.getContactPhone().isEmpty()) {
                phone = p.getContactPhone();
            }
        }

        if (customPhone != null && !customPhone.trim().isEmpty()) {
            phone = customPhone.trim();
        }

        String location = (customLocation != null && !customLocation.trim().isEmpty())
                ? customLocation
                : "12.8230° N, 80.0450° E (SRM University Campus / Medical Center)";

        String notes = (reason != null && !reason.trim().isEmpty())
                ? reason
                : "Immediate critical SOS alarm triggered from Medical Voice Assistant application.";

        SOSEvent event = new SOSEvent(0, userId, now, location, contact, phone, "ACTIVE_TRIGGERED", notes);
        int eventId = repository.saveEvent(event);
        event.setSosId(eventId);

        String rawDigits = phone.replaceAll("[^0-9+]", "");
        String cleanPhone = rawDigits.startsWith("+") ? rawDigits.substring(1) : rawDigits;
        String alertMessage = "🚨 EMERGENCY SOS ALERT! " + userName + " requires immediate medical assistance! Location: " + location + ". Emergency Helpline: 108. Please contact immediately!";
        String encodedMsg;
        try {
            encodedMsg = java.net.URLEncoder.encode(alertMessage, "UTF-8");
        } catch (Exception e) {
            encodedMsg = "EMERGENCY+SOS+ALERT";
        }
        String smsUri = "sms:" + (rawDigits.isEmpty() ? "108" : rawDigits) + "?body=" + encodedMsg;
        String whatsappUri = "https://wa.me/" + (cleanPhone.isEmpty() ? "918220664059" : cleanPhone) + "?text=" + encodedMsg;

        Map<String, Object> resp = new HashMap<>();
        resp.put("eventId", eventId);
        resp.put("status", "EMERGENCY_DISPATCHED");
        resp.put("timestamp", now);
        resp.put("patientName", userName);
        resp.put("emergencyContact", contact);
        resp.put("emergencyPhone", phone);
        resp.put("location", location);
        resp.put("dialNumber", "108");
        resp.put("smsUri", smsUri);
        resp.put("whatsappUri", whatsappUri);
        resp.put("alertText", alertMessage);
        resp.put("instructions", List.of(
            "Emergency contacts and nearby responders have been notified with your current coordinates.",
            "Stay where you are in a comfortable sitting or semi-reclined position.",
            "If possible, unlock your front door to ensure easy access for paramedics.",
            "Gather any active prescription bottles or medical records for the emergency team.",
            "Emergency helpline 108 / 112 is ready for direct dialing."
        ));

        return resp;
    }

    public List<SOSEvent> getEventsByUserId(int userId) {
        return repository.getEventsByUserId(userId);
    }
}
