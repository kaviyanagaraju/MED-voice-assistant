package com.medvoiceassistant.service;

import com.medvoiceassistant.model.FoodPlan;
import com.medvoiceassistant.model.UserProfile;
import com.medvoiceassistant.repository.FoodPlanRepository;
import com.medvoiceassistant.util.DateTimeUtil;

import java.util.List;

public class FoodPlanService {
    private final FoodPlanRepository repository = new FoodPlanRepository();

    public FoodPlan generatePlan(int userId, String query, UserProfile profile) {
        return generatePlan(userId, query, profile, "en");
    }

    public FoodPlan generatePlan(int userId, String query, UserProfile profile, String language) {
        String lower = (query != null) ? query.toLowerCase() : "";
        String lang = (language != null && !language.isEmpty()) ? language.toLowerCase() : "en";
        if (lang.contains("-")) {
            lang = lang.substring(0, 2);
        }

        String mealType = "FULL_DAY";
        int targetCalories = 2000;
        double bmi = (profile != null) ? profile.getBmi() : 22.0;
        int age = (profile != null) ? profile.getAge() : 25;

        // Base calorie adjustment from profile if not explicitly overridden by query
        if (bmi >= 25.0) {
            targetCalories = 1700;
        } else if (bmi < 18.5) {
            targetCalories = 2500;
        }

        StringBuilder planText = new StringBuilder();
        StringBuilder advice = new StringBuilder();

        // --------------------------------------------------------------------
        // 1. UNDERWEIGHT / HEALTHY WEIGHT GAIN / CALORIE SURPLUS / HIGH CALORIE / PROTEIN-RICH
        // --------------------------------------------------------------------
        if (lower.contains("underweight") || lower.contains("gain weight") || lower.contains("weight gain")
            || lower.contains("healthy weight gain") || lower.contains("increase weight") || lower.contains("put on weight")
            || lower.contains("calorie-rich") || lower.contains("calorie rich") || lower.contains("calorie surplus")
            || lower.contains("bulking") || lower.contains("bulk") || lower.contains("gain mass")
            || (lower.contains("protein") && lower.contains("gain")) || lower.contains("skinny")
            || lower.contains("வजन बढ़ाना") || lower.contains("वजन बढ़ाने") || lower.contains("दुबला")
            || lower.contains("எடை அதிகரிக்க") || lower.contains("எடை கூட") || lower.contains("மெலிந்த")
            || lower.contains("బరువు పెరగడం") || lower.contains("బరువు పెంచుకోవడానికి")
            || lower.contains("ತೂಕ ಹೆಚ್ಚಳ") || lower.contains("തൂക്കം കൂട്ടാൻ") || lower.contains("ওজন বৃদ্ধি")
            || lower.contains("وزن بڑھانا") || lower.contains("زيادة الوزن") || lower.contains("aumento de peso")
            || lower.contains("prendre du poids") || lower.contains("gewichtszunahme")) {

            mealType = "HEALTHY_WEIGHT_GAIN_CALORIE_SURPLUS";
            targetCalories = 2800;

            if ("ta".equals(lang)) {
                planText.append("💪 அதிக கலோரி மற்றும் ஆரோக்கியமான எடை அதிகரிப்பு ஊட்டச்சத்து திட்டம்:\n\n");
                planText.append("• அதிகாலை ஊட்டம் (350 கலோரி):\n");
                planText.append("  8-10 ஊறவைத்த பாதாம், 4 அக்ரூட் பருப்புகள், 2 பேரீச்சம்பழம் மற்றும் 1 ஸ்பூன் சுத்தமான நெய் சேர்த்த சூடான பசும்பால்.\n\n");
                planText.append("• காலை உணவு (650 கலோரி):\n");
                planText.append("  2 பன்னீர்/உருளைக்கிழங்கு பராத்தா தயிருடன், அல்லது 3 முட்டை ஆம்லெட் முழு கோதுமை பிரெட்டுடன்.\n");
                planText.append("  கூடவே வாழைப்பழம், 2 ஸ்பூன் வேர்க்கடலை வெண்ணெய் (பீனட் பட்டர்), சியா விதைகள் மற்றும் ஓட்ஸ் கலந்த அதிக கலோரி ஸ்மூத்தி.\n\n");
                planText.append("• இடைவேளை சிற்றுண்டி (350 கலோரி):\n");
                planText.append("  வறுத்த முந்திரி, பூசணி விதைகள், உலர் திராட்சை மற்றும் வறுத்த வேர்க்கடலை சேர்த்த முளைகட்டிய பயறு சுண்டல்.\n\n");
                planText.append("• மதிய உணவு (750 கலோரி):\n");
                planText.append("  2 கப் நெய் சேர்த்த சாதம் அல்லது 3 சப்பாத்தி, கெட்டி பருப்பு அல்லது கொண்டைக்கடலை குழம்பு, வறுத்த பன்னீர்/சிக்கன்/மீன் மற்றும் கெட்டித் தயிர்.\n\n");
                planText.append("• மாலை சிற்றுண்டி (400 கலோரி):\n");
                planText.append("  வேர்க்கடலை வெண்ணெய் டோஸ்ட் அல்லது பன்னீர் புர்ஜி சாண்ட்விச், 2 வேகவைத்த முட்டை அல்லது சர்க்கரைவள்ளிக்கிழங்கு மற்றும் இளநீர்.\n\n");
                planText.append("• இரவு உணவு (600 கலோரி):\n");
                planText.append("  நெய் தடவிய 3 சப்பாத்தி, பாசிப்பருப்பு கூட்டு, பன்னீர்/சோயா சங்க்ஸ் கறி மற்றும் வதக்கிய கீரைகள்.\n\n");
                planText.append("• உறங்கும் முன் (200 கலோரி):\n");
                planText.append("  பிஸ்தா, குங்குமப்பூ, மஞ்சள் மற்றும் தேன் கலந்த மிதமான சூடான பால்.");

                advice.append("முக்கிய மருத்துவ வழிகாட்டுதல்: எடை அதிகரிக்க உங்கள் தினசரி தேவைக்கு மேல் 400-500 கலோரி உபரியாக உட்கொள்ளவும். கொழுப்பு சேராமல் தசை உருவாக உடல் எடையில் ஒரு கிலோவுக்கு 1.6 முதல் 2.0 கிராம் வரை புரதம் உட்கொள்ளவும். வேர்க்கடலை வெண்ணெய், நெய், நட்ஸ், அவகேடோ போன்ற ஆரோக்கியமான அடர்த்தியான கொழுப்புகளைச் சேர்க்கவும். வாரத்திற்கு 3-4 நாட்கள் தசை வலுவூட்டும் உடற்பயிற்சிகளை தவறாமல் செய்யவும்.");

            } else if ("hi".equals(lang)) {
                planText.append("💪 स्वस्थ वजन बढ़ाने और कैलोरी सरप्लस पोषण योजना:\n\n");
                planText.append("• सुबह का एनर्जाइज़र (350 कैलोरी):\n");
                planText.append("  8-10 भीगे बादाम, 4 अखरोट, 2 खजूर, और 1 चम्मच शुद्ध देसी घी के साथ एक गिलास गुनगुना दूध।\n\n");
                planText.append("• पौष्टिक नाश्ता (650 कैलोरी):\n");
                planText.append("  2 भरवां पनीर पराठे ताज़ा दही के साथ, या 3 अंडे भुर्जी और ब्राउन ब्रेड टोस्ट। साथ में केला, पीनट बटर, ओट्स और चिया सीड्स शेक।\n\n");
                planText.append("• मध्याह्न स्नैक (350 कैलोरी):\n");
                planText.append("  भुने काजू, कद्दू के बीज, किशमिश और भुनी मूंगफली के साथ अंकुरित मूंग चाट।\n\n");
                planText.append("• दोपहर का मुख्य भोजन (750 कैलोरी):\n");
                planText.append("  2 कटोरी चावल या 3 घी लगी रोटियां, गाढ़ी दाल या छोले, ग्रिल्ड पनीर या चिकन/मछली, मौसमी हरी सब्ज़ी और एक कटोरी गाढ़ा दही।\n\n");
                planText.append("• शाम का प्रोटीन स्नैक (400 कैलोरी):\n");
                planText.append("  पीनट बटर सैंडविच या पनीर भुर्जी टोस्ट, उबले अंडे या उबला शकरकंद, साथ में ताज़ा नारियल पानी।\n\n");
                planText.append("• रात का भोजन (600 कैलोरी):\n");
                planText.append("  3 रोटियां (देसी घी के साथ), मूंग दाल, सोयाबीन या पनीर करी, और उबली हुई सब्ज़ियाँ।\n\n");
                planText.append("• सोने से पहले (200 कैलोरी):\n");
                planText.append("  हल्दी, केसर, बादाम और एक चम्मच शहद वाला गुनगुना दूध मांसपेशियों की रिकवरी के लिए।");

                advice.append("प्रमुख चिकित्सीय सलाह: स्वस्थ वजन बढ़ाने के लिए अपनी दैनिक ऊर्जा आवश्यकता से 400-500 कैलोरी अतिरिक्त लें। दुबलेपन से उबरने और स्वस्थ मांसपेशियां बनाने के लिए प्रति किलो वजन पर 1.6 से 2.0 ग्राम प्रोटीन का उपभोग करें। स्वस्थ वसा (घी, मेवे, पीनट बटर, बीज) का उपयोग करें और सप्ताह में 3-4 दिन स्ट्रेंथ ट्रेनिंग व्यायाम अवश्य करें।");

            } else if ("te".equals(lang)) {
                planText.append("💪 ఆరోగ్యకరమైన బరువు పెరుగుదల & క్యాలరీ సర్ప్లస్ న్యూట్రిషన్ ప్లాన్:\n\n");
                planText.append("• ఉదయం ఎనర్జీ బూస్టర్ (350 కేలరీలు):\n");
                planText.append("  8-10 నానబెట్టిన బాదం, 4 అక్రూట్స్, 2 ఖర్జూరాలు మరియు నెయ్యితో కూడిన వేడి పాలు.\n\n");
                planText.append("• హై-క్యాలరీ అల్పాహారం (650 కేలరీలు):\n");
                planText.append("  2 పనీర్ పరోటాలు పెరుగుతో లేదా 3 గుడ్ల ఆమ్లెట్ బ్రౌన్ బ్రెడ్‌తో, అరటిపండు, పీనట్ బటర్ మరియు చియా సీడ్స్ మిల్క్‌షేక్.\n\n");
                planText.append("• మిడ్-మార్నింగ్ స్నాక్ (350 కేలరీలు):\n");
                planText.append("  జీడిపప్పు, గుమ్మడి గింజలు, ఎండుద్రాక్ష మరియు మొలకల చాట్.\n\n");
                planText.append("• మధ్యాహ్న భోజనం (750 కేలరీలు):\n");
                planText.append("  నెయ్యితో అన్నం లేదా రోటీలు, చిక్కటి పప్పు, పనీర్ లేదా చికెన్/చేప, కూరగాయలు మరియు పెరుగు.\n\n");
                planText.append("• సాయంత్రం ప్రోటీన్ స్నాక్ (400 కేలరీలు):\n");
                planText.append("  పీనట్ బటర్ టోస్ట్, ఉడికించిన గుడ్లు లేదా చిలగడదుంప, కొబ్బరి నీళ్ళు.\n\n");
                planText.append("• రాత్రి భోజనం (600 కేలరీలు):\n");
                planText.append("  రోటీలు, పెసరపప్పు లేదా సోయాబీన్ కూర, పనీర్ మరియు కూరగాయలు.\n\n");
                planText.append("• పడుకునే ముందు (200 కేలరీలు):\n");
                planText.append("  పసుపు, కుంకుమపువ్వు మరియు బాదంపప్పు కలిపిన వేడి పాలు.");

                advice.append("వైద్య సలహా: శరీర రోజువారీ అవసరం కంటే 400-500 కేలరీలు ఎక్కువగా తీసుకోవాలి. కండరాల పెరుగుదల కొరకు శరీర బరువులో కిలోకు 1.6-2.0 గ్రాముల ప్రోటీన్ అవసరం. నెయ్యి, నట్స్, పీనట్ బటర్ వంటి ఆరోగ్యకరమైన కొవ్వులను తీసుకోండి. వారానికి 3-4 రోజులు వ్యాయామం చేయండి.");

            } else {
                planText.append("💪 CLINICAL NUTRITION FOR HEALTHY WEIGHT GAIN & CALORIE SURPLUS:\n\n");
                planText.append("• 🌅 EARLY MORNING DENSITY BOOSTER (approx. 350 kcal):\n");
                planText.append("  8-10 soaked almonds, 4 walnuts, 2 Medjool dates, and 1 glass warm whole milk with 1 tsp organic cow's ghee or ashwagandha.\n\n");
                planText.append("• 🍳 POWER BREAKFAST (approx. 650 kcal):\n");
                planText.append("  2 whole-wheat stuffed paneer or potato parathas with fresh homemade curd, OR 3 scrambled/boiled eggs with whole-grain avocado toast.\n");
                planText.append("  Plus a nutrient-dense weight gain smoothie: 1 whole banana, 1 cup whole milk, 2 tbsp natural peanut butter, 1 tbsp chia seeds, and 30g rolled oats.\n\n");
                planText.append("• 🥜 MID-MORNING BOOSTER (approx. 350 kcal):\n");
                planText.append("  Handful of roasted cashews, pumpkin seeds, raisins, and a bowl of ripe mango/banana slices or sprouted chickpea chaat tossed with roasted peanuts.\n\n");
                planText.append("• 🍛 CALORIE & NUTRIENT-DENSE LUNCH (approx. 750 kcal):\n");
                planText.append("  2 medium cups brown or white rice / 3 rotis brushed with ghee.\n");
                planText.append("  1.5 cups thick dal (lentils) or rajma/chickpea curry.\n");
                planText.append("  Grilled paneer (120g) or chicken breast / wild fish (rich in bioavailable protein for muscle synthesis).\n");
                planText.append("  Mixed sautéed seasonal vegetables and 1 cup full-fat probiotic curd.\n\n");
                planText.append("• 🥪 HIGH-PROTEIN EVENING SNACK (approx. 400 kcal):\n");
                planText.append("  Whole-grain toasted sandwich with peanut butter or paneer bhurji, or 2 boiled eggs with boiled sweet potato, served with tender coconut water.\n\n");
                planText.append("• 🍲 NOURISHING DINNER (approx. 600 kcal):\n");
                planText.append("  2-3 whole-grain rotis with ghee, hearty yellow moong dal stew, tofu/paneer/soya chunks curry or lean poultry, and steamed greens (spinach, beans).\n\n");
                planText.append("• 🥛 BEDTIME MUSCLE RECOVERY (approx. 200 kcal):\n");
                planText.append("  Warm golden turmeric milk with crushed pistachios, saffron, and 1 tsp raw honey for nocturnal muscle tissue repair.");

                advice.append("CRITICAL WEIGHT GAIN CLINICAL GUIDELINES:\n" +
                    "1. Calorie Surplus: Eat 400–500 kcal above your maintenance energy expenditure consistently.\n" +
                    "2. Protein Target: Consume 1.6 to 2.0 grams of protein per kilogram of body weight to foster lean muscle hypertrophy rather than excess visceral fat.\n" +
                    "3. Energy-Dense Healthy Fats: Incorporate healthy fats (peanut butter, ghee, extra virgin olive oil, nuts, seeds, avocados) to increase calories without causing premature fullness.\n" +
                    "4. Progressive Resistance Training: Pair this nutritional regimen with 3–4 days/week of compound strength training (squats, deadlifts, push-ups, rows) to stimulate muscle protein synthesis.");
            }

        // --------------------------------------------------------------------
        // 2. HIGH PROTEIN & MUSCLE BUILDING / FITNESS / GYM / BODYBUILDING
        // --------------------------------------------------------------------
        } else if (lower.contains("protein") || lower.contains("muscle") || lower.contains("gym") || lower.contains("bodybuilding")
            || lower.contains("hypertrophy") || lower.contains("workout") || lower.contains("fitness") || lower.contains("புரத") || lower.contains("प्रोटीन")) {

            mealType = "HIGH_PROTEIN_MUSCLE_BUILDING";
            targetCalories = 2500;

            planText.append("🏋️ HIGH PROTEIN & MUSCLE HYPERTROPHY NUTRITION PLAN (140g-160g Protein):\n\n");
            planText.append("• BREAKFAST (40g Protein): 4 scrambled egg whites + 2 whole eggs with spinach, 2 slices whole-wheat toast with mashed avocado, and 1 cup green tea.\n\n");
            planText.append("• MID-MORNING (25g Protein): 1 cup low-fat Greek yogurt with scoop of whey/plant protein isolate, chia seeds, and berries.\n\n");
            planText.append("• LUNCH (45g Protein): 180g grilled chicken breast, grilled paneer, or seasoned tofu, served with 1.5 cups quinoa or brown rice, steamed broccoli, and black beans.\n\n");
            planText.append("• PRE/POST WORKOUT (30g Protein): 1 scoop whey protein shake with 1 large banana and 1 tbsp almond butter.\n\n");
            planText.append("• DINNER (40g Protein): Baked salmon, white fish, or soya chunks curry with sautéed asparagus, mushrooms, and 1 sweet potato.\n\n");
            planText.append("• BEDTIME: 1 cup slow-digesting casein curd or warm cottage cheese.");
            advice.append("Maintain 1.6–2.2g of protein per kg of body weight distributed evenly across 4 to 5 feeding windows. Drink 3.5 liters of water daily to support renal clearance of protein metabolites.");

        // --------------------------------------------------------------------
        // 3. MENSTRUAL CARE / CRAMP RELIEF / PCOS / PCOD / HORMONAL BALANCE
        // --------------------------------------------------------------------
        } else if (lower.contains("period") || lower.contains("menstrual") || lower.contains("cramp") || lower.contains("pcos")
            || lower.contains("pcod") || lower.contains("dysmenorrhea") || lower.contains("hormon")
            || lower.contains("மாதவிடாய்") || lower.contains("పీరియడ్") || lower.contains("माहवारी") || lower.contains("முட்டு")) {

            mealType = "MENSTRUAL_HORMONAL_CARE";
            targetCalories = 1950;
            planText.append("🌸 CLINICAL NUTRITION FOR MENSTRUAL RELIEF, CRAMP REDUCTION & PCOS:\n\n");
            planText.append("• BREAKFAST (Anti-Inflammatory):\n");
            planText.append("  Warm rolled oats porridge topped with 1 tbsp roasted pumpkin seeds, ground flaxseeds, soaked walnuts, and half a sliced banana (rich in Vitamin B6 and magnesium to relax uterine contractions).\n");
            planText.append("  1 cup of warm ginger-cinnamon tea (inhibits prostaglandin synthesis, relieving dysmenorrhea).\n\n");
            planText.append("• MID-MORNING BOOSTER:\n");
            planText.append("  Fresh pomegranate cup or kiwi slices with 5 soaked almonds (natural iron + Vitamin C for maximum iron absorption).\n\n");
            planText.append("• LUNCH (Iron & Phyto-Nutrient Replenishment):\n");
            planText.append("  1.5 cups brown rice, quinoa, or whole-wheat rotis.\n");
            planText.append("  Steamed spinach & palak dal (lentils), seasoned lightly with cumin and turmeric.\n");
            planText.append("  Grilled tofu, paneer, or lean fish rich in Omega-3 fatty acids.\n");
            planText.append("  Fresh beetroot-carrot salad with lemon juice dressing.\n\n");
            planText.append("• EVENING SNACK (Cramp Relief):\n");
            planText.append("  Roasted makhana (foxnuts) seasoned with turmeric, or dark chocolate (minimum 70% cocoa - rich in endorphin-stimulating magnesium).\n");
            planText.append("  Warm chamomile herbal infusion.\n\n");
            planText.append("• DINNER (Light & Digestible):\n");
            planText.append("  Moong dal khichdi or warm vegetable broth with steamed zucchini and broccoli.\n");
            planText.append("  Warm golden turmeric milk (haldi doodh) with a pinch of black pepper 45 mins before bedtime.");

            advice.append("CRITICAL CLINICAL DIETARY ADVICE: Avoid excess refined sugars, sodas, fried snacks, and heavy caffeine. Excess caffeine constricts pelvic blood vessels and exacerbates uterine cramping. Ensure at least 2.5 to 3 liters of warm water daily to prevent menstrual fluid retention and bloating.");

        // --------------------------------------------------------------------
        // 4. DIABETES & GLYCEMIC REGULATION
        // --------------------------------------------------------------------
        } else if (lower.contains("diabet") || lower.contains("sugar") || lower.contains("glucose") || lower.contains("insulin") || lower.contains("hba1c")
            || lower.contains("मधुमेह") || lower.contains("சர்க்கரை") || lower.contains("షుగర్")) {

            mealType = "DIABETES_GLUCOSE_CARE";
            targetCalories = 1750;
            planText.append("🩺 GLYCEMIC REGULATION & DIABETES CARE NUTRITION PLAN:\n\n");
            planText.append("• MORNING: 1 glass of overnight soaked fenugreek (methi) seed water.\n");
            planText.append("• BREAKFAST: Vegetable oats upma or sprouted moong chilla with mint chutney and unsweetened green tea.\n");
            planText.append("• MID-MORNING: 1 whole apple or guava with roasted unsalted almonds (low glycemic index).\n");
            planText.append("• LUNCH: Multigrain rotis (barley/jowar) with methi/spinach dal, sautéed bitter gourd (karela) or French beans, and 1 cup homemade probiotic curd.\n");
            planText.append("• EVENING: Roasted chana (chickpeas) with cinnamon black tea.\n");
            planText.append("• DINNER: Clear vegetable or lentil soup with steamed tofu/chicken and stir-fried capsicum & mushrooms.");
            advice.append("Focus on complex low-GI carbs and dietary fiber (35g+ daily). Fiber decelerates glucose absorption in the intestinal mucosa, preventing postprandial glycemic spikes.");

        // --------------------------------------------------------------------
        // 5. HYPERTENSION & CARDIOVASCULAR DASH CARE
        // --------------------------------------------------------------------
        } else if (lower.contains("bp") || lower.contains("hypertension") || lower.contains("blood pressure")
            || lower.contains("cardiac") || lower.contains("heart") || lower.contains("dash") || lower.contains("ரத்த அழுத்தம்") || lower.contains("రక్తపోటు")) {

            mealType = "HYPERTENSION_DASH_CARE";
            targetCalories = 1800;
            planText.append("❤️ CARDIOVASCULAR & HYPERTENSION DASH NUTRITION PLAN:\n\n");
            planText.append("• BREAKFAST: Oatmeal cooked in skim milk or almond milk, topped with chia seeds, blueberries, and walnuts. Green tea.\n");
            planText.append("• MID-MORNING: 1 medium potassium-rich banana or tender coconut water.\n");
            planText.append("• LUNCH: Steamed brown rice or whole-wheat chapati with low-sodium yellow dal, steamed cauliflower/peas, and cucumber-tomato raita.\n");
            planText.append("• EVENING: Unsalted roasted pumpkin seeds and hibiscus tea.\n");
            planText.append("• DINNER: Baked herbs-seasoned fish or steamed paneer with sautéed leafy greens and a bowl of tomato-garlic soup.");
            advice.append("Strictly limit dietary sodium intake to under 1,500mg daily. Avoid processed cheese, pickles, papads, and canned soups. Potassium-rich foods naturally counterbalance sodium, relaxing blood vessel walls.");

        // --------------------------------------------------------------------
        // 6. GASTRITIS, ACIDITY & GUT-SOOTHING
        // --------------------------------------------------------------------
        } else if (lower.contains("acid") || lower.contains("gastric") || lower.contains("gastritis")
            || lower.contains("ulcer") || lower.contains("heartburn") || lower.contains("indigestion") || lower.contains("stomach pain")
            || lower.contains("gerd") || lower.contains("reflux") || lower.contains("அமிலத்தன்மை") || lower.contains("గ్యాస్ట్రిక్")) {

            mealType = "GASTRITIS_ACIDITY_SOOTHING";
            targetCalories = 1850;
            planText.append("🌿 GASTRITIS, ACIDITY & GUT-SOOTHING NUTRITION PLAN:\n\n");
            planText.append("• MORNING: Half cup of warm water with 1 tbsp soaked chia seeds or tender coconut water.\n");
            planText.append("• BREAKFAST: Soft rolled oats porridge with mashed ripe banana or steamed soft idlis with mild coconut-coriander chutney.\n");
            planText.append("• MID-MORNING: 1 glass of fresh watermelon juice or cold buttermilk (chaas) with a pinch of roasted cumin.\n");
            planText.append("• LUNCH: Soft white rice with yellow moong dal (split mung), boiled bottle gourd (lauki) or pumpkin, and fresh homemade curd.\n");
            planText.append("• EVENING: Boiled sweet potato or rice crackers with warm chamomile tea.\n");
            planText.append("• DINNER: Light moong dal vegetable soup with a soft whole-wheat roti and steamed carrots.");
            advice.append("Avoid raw citrus fruits, vinegar, excessive black/red pepper, garlic, and deep-fried items. Eat 5 to 6 small, spaced meals and remain upright for at least 2 hours following meals to prevent acid reflux.");

        // --------------------------------------------------------------------
        // 7. ANEMIA / IRON DEFICIENCY / LOW HEMOGLOBIN
        // --------------------------------------------------------------------
        } else if (lower.contains("iron") || lower.contains("anemia") || lower.contains("anaemia") || lower.contains("hemoglobin")
            || lower.contains("low hb") || lower.contains("ferritin") || lower.contains("இரும்புச்சத்து") || lower.contains("ரத்த சோகை") || lower.contains("एनीमिया") || lower.contains("రక్తహీనత")) {

            mealType = "IRON_RICH_ANEMIA_REVERSAL";
            targetCalories = 2050;
            planText.append("🩸 CLINICAL IRON-REPLENISHMENT & HEMOGLOBIN BOOST PLAN:\n\n");
            planText.append("• MORNING: 5 soaked black raisins, 2 dates, and warm water with lemon juice (Vitamin C enhances iron absorption).\n");
            planText.append("• BREAKFAST: Sprouted ragi (finger millet) porridge with almonds and jaggery, or spinach-egg omelet.\n");
            planText.append("• MID-MORNING: Fresh pomegranate cup with 1 amla (Indian gooseberry - rich in Vitamin C).\n");
            planText.append("• LUNCH: Brown rice or whole-wheat rotis with moringa (drumstick) leaf dal, sautéed beetroot with lemon squeeze, and grilled chicken or paneer.\n");
            planText.append("• EVENING: Roasted black chana with jaggery and roasted pumpkin seeds.\n");
            planText.append("• DINNER: Lentil spinach soup with sweet potato and whole-wheat roti.");
            advice.append("Pair iron sources (spinach, dates, beetroot, lentils) with Vitamin C (lemon, amla, citrus) to multiply iron absorption. STRICTLY AVOID drinking tea or coffee within 1 hour of meals, as polyphenols and tannins inhibit iron uptake by up to 60%.");

        // --------------------------------------------------------------------
        // 8. THYROID HEALTH & METABOLIC SUPPORT
        // --------------------------------------------------------------------
        } else if (lower.contains("thyroid") || lower.contains("hypothyroid") || lower.contains("tsh") || lower.contains("தைராய்டு") || lower.contains("थायराइड") || lower.contains("థైరాయిడ్")) {

            mealType = "THYROID_METABOLIC_BALANCE";
            targetCalories = 1850;
            planText.append("🦋 THYROID METABOLIC HARMONY & ENDOCRINE CARE PLAN:\n\n");
            planText.append("• MORNING: Warm water with 2 soaked Brazil nuts (rich in selenium, essential for T4 to T3 conversion).\n");
            planText.append("• BREAKFAST: Boiled eggs or besan chilla with sautéed mushrooms and roasted pumpkin seeds (rich in zinc).\n");
            planText.append("• MID-MORNING: 1 fresh apple with walnuts and green tea.\n");
            planText.append("• LUNCH: Quinoa or brown rice with yellow lentil dal, grilled fish or paneer, and cooked zucchini/carrots (use iodized salt).\n");
            planText.append("• EVENING: Roasted sunflower seeds and herbal spearmint tea.\n");
            planText.append("• DINNER: Steamed white fish or tofu with lightly cooked bell peppers and clear vegetable soup.");
            advice.append("Cruciferous vegetables (cabbage, cauliflower, broccoli) must be thoroughly cooked before eating, as cooking deactivates goitrogens that impede iodine uptake. Ensure adequate selenium, zinc, and tyrosine.");

        // --------------------------------------------------------------------
        // 9. HIGH CHOLESTEROL & TRIGLYCERIDES / LIPID CARE
        // --------------------------------------------------------------------
        } else if (lower.contains("cholesterol") || lower.contains("triglyceride") || lower.contains("lipid") || lower.contains("ldl")
            || lower.contains("கொலஸ்ட்ரால்") || lower.contains("कोलेस्ट्रॉल") || lower.contains("కొలెస్ట్రాల్")) {

            mealType = "CHOLESTEROL_LIPID_REDUCTION";
            targetCalories = 1800;
            planText.append("🫀 LIPID-LOWERING & ARTERIAL HEALTH NUTRITION PLAN:\n\n");
            planText.append("• MORNING: 1 glass warm water with 1 tbsp soaked chia seeds or crushed garlic cloves.\n");
            planText.append("• BREAKFAST: Steel-cut rolled oats with unsweetened almond milk, ground flaxseeds, and sliced blueberries.\n");
            planText.append("• MID-MORNING: 1 fresh apple or pear with 4 walnut halves (Omega-3 fatty acids).\n");
            planText.append("• LUNCH: Multigrain roti (oats/barley flour) with moong dal, steamed ladyfinger (okra), grilled tofu or baked fatty fish (salmon/mackerel), and cucumber salad.\n");
            planText.append("• EVENING: Roasted makhana with green tea.\n");
            planText.append("• DINNER: Clear vegetable broth with sautéed garlic greens and steamed paneer or lentils.");
            advice.append("Emphasize soluble beta-glucan fiber (oats, psyllium, legumes) which traps cholesterol in the digestive tract. Completely eliminate trans-fats, bakery goods, and palm oil.");

        // --------------------------------------------------------------------
        // 10. URIC ACID & GOUT RELIEF
        // --------------------------------------------------------------------
        } else if (lower.contains("uric acid") || lower.contains("gout") || lower.contains("hyperuricemia") || lower.contains("யூரிக் அமிலம்") || lower.contains("यूरिक एसिड")) {

            mealType = "LOW_PURINE_GOUT_RELIEF";
            targetCalories = 1900;
            planText.append("🦶 LOW-PURINE & URIC ACID CLEARANCE NUTRITION PLAN:\n\n");
            planText.append("• MORNING: Warm lemon water (alkalizes urine and promotes urate excretion).\n");
            planText.append("• BREAKFAST: Oatmeal with low-fat milk, tart cherries or strawberries, and chia seeds.\n");
            planText.append("• MID-MORNING: Fresh tart cherry juice or cucumber slices with mint.\n");
            planText.append("• LUNCH: Steamed white rice or wheat roti with low-fat curd, bottle gourd curry, and light moong dal.\n");
            planText.append("• EVENING: Tender coconut water and roasted almonds.\n");
            planText.append("• DINNER: Clear vegetable soup with boiled sweet potato and steamed paneer.");
            advice.append("Strictly avoid high-purine foods: red meat, organ meats (liver/kidney), shellfish, beer, and high-fructose corn syrup. Drink at least 3.5 liters of water daily to flush uric acid crystals through the kidneys.");

        // --------------------------------------------------------------------
        // 11. WEIGHT LOSS / CALORIE DEFICIT / FAT LOSS
        // --------------------------------------------------------------------
        } else if (lower.contains("weight loss") || lower.contains("fat loss") || lower.contains("slim") || lower.contains("reduce weight")
            || lower.contains("lose weight") || lower.contains("belly fat") || lower.contains("எடை குறைக்க") || lower.contains("वजन कम")) {

            mealType = "CALORIE_DEFICIT_FAT_LOSS";
            targetCalories = 1500;
            planText.append("⚖️ LEAN CALORIE DEFICIT & METABOLIC FAT LOSS PLAN:\n\n");
            planText.append("• BREAKFAST (Protein & Fiber): 2 boiled whole eggs or vegetable besan chilla with green tea (approx. 300 kcal).\n");
            planText.append("• MID-MORNING: 1 fresh apple with 10 roasted almonds (approx. 120 kcal).\n");
            planText.append("• LUNCH: Large green salad (cucumber, lettuce, tomato) followed by 1 chapati, 1 cup dal, and grilled chicken/tofu (approx. 450 kcal).\n");
            planText.append("• EVENING: Roasted makhana or sprout chaat with lemon juice (approx. 130 kcal).\n");
            planText.append("• DINNER: Clear vegetable broth with stir-fried mushroom, broccoli, and paneer (approx. 350 kcal).\n");
            planText.append("• HYDRATION: 3 to 3.5 liters of filtered water throughout the day.");
            advice.append("Maintain an energy deficit of 400-500 kcal daily. Prioritize lean protein (1.2g-1.6g per kg of body weight) to preserve muscle mass while burning adipose tissue.");

        // --------------------------------------------------------------------
        // 12. STANDARD MEAL TYPES (BREAKFAST / LUNCH / DINNER / SNACKS)
        // --------------------------------------------------------------------
        } else if (lower.contains("breakfast")) {
            mealType = "BREAKFAST";
            targetCalories = 450;
            planText.append("• Rolled Oats Porridge with chia seeds, sliced bananas, and a handful of almonds.\n");
            planText.append("• Two boiled or poached eggs (or steamed idlis with sambar for a plant-based alternative).\n");
            planText.append("• One cup of green tea or warm lemon water with honey.");
            advice.append("A high-protein breakfast stabilizes morning blood glucose and prevents mid-morning energy crashes.");

        } else if (lower.contains("lunch")) {
            mealType = "LUNCH";
            targetCalories = 650;
            planText.append("• Brown rice or quinoa (1 medium cup) or 2 whole-wheat rotis.\n");
            planText.append("• Grilled chicken breast / paneer / tofu with mixed sautéed spinach and broccoli.\n");
            planText.append("• Fresh garden salad (cucumber, tomatoes, carrots) dressed with olive oil and lemon juice.\n");
            planText.append("• 1 small bowl of low-fat probiotic curd / yogurt.");
            advice.append("Maintain the plate method: 50% fiber-rich vegetables, 25% lean protein, and 25% complex whole grains.");

        } else if (lower.contains("dinner")) {
            mealType = "DINNER";
            targetCalories = 500;
            planText.append("• Warm vegetable lentil soup (dal) or clear chicken broth.\n");
            planText.append("• 1-2 multigrain rotis with lightly seasoned stir-fried vegetables.\n");
            planText.append("• Steamed fish or baked paneer with herbs.\n");
            planText.append("• Light chamomile tea 30 minutes before sleep.");
            advice.append("Keep dinner light and finish eating at least 2 to 3 hours before going to sleep to aid gastrointestinal digestion.");

        } else if (lower.contains("snack")) {
            mealType = "SNACKS";
            targetCalories = 250;
            planText.append("• Handful of unsalted roasted almonds, walnuts, and pumpkin seeds.\n");
            planText.append("• Seasonal fresh fruit (apple, berries, or papaya) with a dollop of Greek yogurt.\n");
            planText.append("• Roasted makhana (foxnuts) seasoned with a pinch of turmeric and rock salt.\n");
            planText.append("• Tender coconut water or unsweetened buttermilk (chaas).");
            advice.append("Choose nutrient-dense, fiber-rich snacks rather than processed sugary foods to sustain satiety.");

        // --------------------------------------------------------------------
        // 13. DEFAULT BALANCED FULL DAY NUTRITION
        // --------------------------------------------------------------------
        } else {
            mealType = "FULL_DAY_BALANCED";
            targetCalories = (bmi < 18.5) ? 2500 : ((bmi >= 25.0) ? 1700 : 2000);

            planText.append("1. BREAKFAST: Oatmeal with nuts & fruit, or 2 boiled eggs with whole-grain toast (approx. 400 kcal).\n");
            planText.append("2. MID-MORNING: 1 fresh apple and a handful of roasted almonds (approx. 150 kcal).\n");
            planText.append("3. LUNCH: Whole-wheat rotis or brown rice with dal, grilled paneer/chicken, and fresh salad (approx. 650 kcal).\n");
            planText.append("4. EVENING SNACK: Sprouted moong salad or roasted makhana with green tea (approx. 150 kcal).\n");
            planText.append("5. DINNER: Light vegetable soup with sautéed vegetables and lean protein (approx. 450 kcal).\n");
            planText.append("6. HYDRATION: Minimum 2.5 to 3 liters of filtered water daily.");
            advice.append("Personalized for age ").append(age).append(" and BMI of ").append(bmi).append(" (").append((profile != null) ? profile.getBmiCategory() : "Normal").append("). Focus on whole, unprocessed foods and balanced macronutrients.");
        }

        FoodPlan plan = new FoodPlan(
            0,
            userId,
            query,
            mealType,
            planText.toString(),
            targetCalories,
            advice.toString(),
            DateTimeUtil.now()
        );

        int id = repository.saveFoodPlan(plan);
        plan.setPlanId(id);
        return plan;
    }

    public List<FoodPlan> getPlansByUserId(int userId) {
        return repository.getPlansByUserId(userId);
    }
}
