package com.medvoiceassistant.service;

import com.medvoiceassistant.model.Reminder;
import com.medvoiceassistant.repository.ReminderRepository;
import com.medvoiceassistant.util.DateTimeUtil;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class ReminderService {
    private final ReminderRepository repository = new ReminderRepository();
    private final ScheduledExecutorService scheduler = Executors.newSingleThreadScheduledExecutor(r -> {
        Thread t = new Thread(r, "MedicationReminderDaemon");
        t.setDaemon(true);
        return t;
    });

    private final List<ReminderAlert> pendingAlerts = Collections.synchronizedList(new ArrayList<>());

    public static class ReminderAlert {
        public int reminderId;
        public String medicineName;
        public String dosage;
        public String reminderTime;
        public String alertMessage;
        public String timestamp;

        public ReminderAlert(int reminderId, String medicineName, String dosage, String reminderTime, String alertMessage, String timestamp) {
            this.reminderId = reminderId;
            this.medicineName = medicineName;
            this.dosage = dosage;
            this.reminderTime = reminderTime;
            this.alertMessage = alertMessage;
            this.timestamp = timestamp;
        }
    }

    public ReminderService() {
        startScheduler();
    }

    private void startScheduler() {
        scheduler.scheduleAtFixedRate(() -> {
            try {
                checkReminders();
            } catch (Exception e) {
                System.err.println("Error in Reminder scheduler: " + e.getMessage());
            }
        }, 5, 25, TimeUnit.SECONDS);
    }

    private void checkReminders() {
        String currentTime = DateTimeUtil.currentTimeOnly(); // "HH:mm"
        List<Reminder> activeReminders = repository.getAllActiveReminders();
        String today = DateTimeUtil.now().substring(0, 10);

        for (Reminder r : activeReminders) {
            if (currentTime.equals(r.getReminderTime())) {
                // Check if already triggered today
                String last = r.getLastTriggered();
                if (last == null || !last.startsWith(today)) {
                    String msg = "Medication Reminder: It is time to take your " + r.getMedicineName() + " (" + r.getDosage() + "). Please take it with water as prescribed.";
                    ReminderAlert alert = new ReminderAlert(
                        r.getReminderId(),
                        r.getMedicineName(),
                        r.getDosage(),
                        r.getReminderTime(),
                        msg,
                        DateTimeUtil.now()
                    );
                    pendingAlerts.add(alert);
                    repository.updateLastTriggered(r.getReminderId(), DateTimeUtil.now());
                    System.out.println(">>> [MEDICATION ALERT TRIGGERED] " + msg);
                }
            }
        }
    }

    public List<ReminderAlert> pollAlerts() {
        List<ReminderAlert> copy;
        synchronized (pendingAlerts) {
            copy = new ArrayList<>(pendingAlerts);
            pendingAlerts.clear();
        }
        return copy;
    }

    public int createReminder(Reminder reminder) {
        return repository.saveReminder(reminder);
    }

    public List<Reminder> getRemindersByUserId(int userId) {
        return repository.getRemindersByUserId(userId);
    }

    public boolean toggleActive(int reminderId, boolean active) {
        return repository.toggleActive(reminderId, active);
    }

    public boolean deleteReminder(int reminderId) {
        return repository.deleteReminder(reminderId);
    }

    public void triggerTestAlert(int reminderId, String medicineName, String dosage) {
        String msg = "Test Voice Alert: It is time to take your " + medicineName + " (" + dosage + "). Stay healthy!";
        pendingAlerts.add(new ReminderAlert(reminderId, medicineName, dosage, DateTimeUtil.currentTimeOnly(), msg, DateTimeUtil.now()));
    }
}
