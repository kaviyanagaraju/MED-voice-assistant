package com.medvoiceassistant.service;

import com.medvoiceassistant.model.MedicalRecord;
import com.medvoiceassistant.repository.RecordRepository;
import com.medvoiceassistant.util.DateTimeUtil;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.Optional;

public class RecordService {
    private final RecordRepository repository = new RecordRepository();
    private static final String UPLOAD_DIR = "uploads";

    public RecordService() {
        File dir = new File(UPLOAD_DIR);
        if (!dir.exists()) {
            dir.mkdirs();
        }
    }

    public MedicalRecord saveFileRecord(int userId, String type, String originalFileName, byte[] content, String description) throws IOException {
        String safeName = System.currentTimeMillis() + "_" + originalFileName.replaceAll("[^a-zA-Z0-9._-]", "_");
        File targetFile = new File(UPLOAD_DIR, safeName);
        try (FileOutputStream fos = new FileOutputStream(targetFile)) {
            fos.write(content);
        }

        MedicalRecord record = new MedicalRecord(
            0,
            userId,
            type,
            originalFileName,
            targetFile.getPath(),
            content.length,
            DateTimeUtil.now(),
            description
        );

        int id = repository.saveRecord(record);
        record.setRecordId(id);
        return record;
    }

    public List<MedicalRecord> getRecordsByUserId(int userId) {
        return repository.getRecordsByUserId(userId);
    }

    public Optional<MedicalRecord> getRecordById(int recordId) {
        return repository.getRecordById(recordId);
    }

    public boolean deleteRecord(int recordId, int userId) {
        Optional<MedicalRecord> recordOpt = repository.getRecordById(recordId);
        if (recordOpt.isPresent() && recordOpt.get().getUserId() == userId) {
            File f = new File(recordOpt.get().getFilePath());
            if (f.exists()) {
                f.delete();
            }
            return repository.deleteRecord(recordId, userId);
        }
        return false;
    }
}
