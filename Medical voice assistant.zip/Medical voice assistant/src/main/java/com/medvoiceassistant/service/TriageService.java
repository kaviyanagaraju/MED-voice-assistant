package com.medvoiceassistant.service;

import com.medvoiceassistant.model.Symptom;
import com.medvoiceassistant.model.SymptomSession;
import com.medvoiceassistant.model.TriageResult;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class TriageService {
    private final SpeechService speechService = new SpeechService();
    private final LanguageService languageService = new LanguageService();
    private final ClinicalGuidanceProvider guidanceProvider = new ClinicalGuidanceProvider();

    public static class EvaluationOutcome {
        public SymptomSession session;
        public TriageResult triageResult;

        public EvaluationOutcome(SymptomSession session, TriageResult triageResult) {
            this.session = session;
            this.triageResult = triageResult;
        }
    }

    public EvaluationOutcome evaluateSymptomText(int userId, String rawText, String userLanguage) {
        String language = (userLanguage != null && !userLanguage.isEmpty() && !"auto".equalsIgnoreCase(userLanguage))
                ? userLanguage
                : languageService.detectLanguage(rawText);

        SymptomSession session = new SymptomSession();
        session.setUserId(userId);
        session.setInputText(rawText);
        session.setLanguage(language);

        // 1. Parse symptoms
        List<Symptom> symptoms = extractSymptoms(rawText, language);
        session.setSymptoms(symptoms);

        // 2. Perform clinical triage evaluation
        TriageResult result = runClinicalTriageRules(symptoms, rawText, language);
        session.setTriageResult(result);

        return new EvaluationOutcome(session, result);
    }

    public List<Symptom> extractSymptoms(String text) {
        return extractSymptoms(text, "en");
    }

    public List<Symptom> extractSymptoms(String text, String language) {
        List<Symptom> list = new ArrayList<>();
        if (text == null || text.trim().isEmpty()) {
            return list;
        }

        String lower = text.toLowerCase();
        int durationDays = extractDurationInDays(lower);
        String severity = extractOverallSeverity(lower);

        // Medical Symptom Knowledge Base (Global Multilingual: EN, TA, HI, TE, KN, ML, BN, MR, UR, AR, RU, JA, KO, ZH, TH, ES, PT, FR, DE, IT)
        Map<String, String[]> dictionary = new LinkedHashMap<>();
        dictionary.put("Chest Pain", new String[]{
            "chest pain", "chest pressure", "pressure in chest", "tightness in chest", "chest ache", "heart pain", "cardiac pain",
            "nenju vali", "marbu vali", "idhayathil vali", "நெஞ்சு வலி", "நெஞ்சுவலி", "நெஞ்சில் வலி", "மார்பு வலி", "நெஞ்சு",
            "seene me dard", "chhati me dard", "dil me dard", "छाती में दर्द", "सीने में दर्द", "सीने में", "छाती में",
            "gunde noppi", "chathi noppi", "gundelo noppi", "ఛాతీ నొప్పి", "గుండె నొప్పి",
            "ede noovu", "ede novu", "hridaya novu", "edeyalli novu", "ಎದೆ ನೋವು", "ಹೃದಯ ನೋವು",
            "nenchu vedhana", "nenjil vedhana", "nenju vedhana", "നെഞ്ചുവേദന", "നെഞ്ചിൽ വേദന",
            "buke betha", "buke chap", "বুকে ব্যথা", "বুকে চাপ", "বুকে তীব্র ব্যথা",
            "chhatit dukhne", "chhatit kal", "छातीत दुखणे", "छातीत कळ", "छातीत खूप दुखत",
            "seene mein dard", "dil mein dard", "سینے میں درد", "سینے میں شدید درد", "سینہ میں درد", "دل میں درد", "سینے",
            "alam fi sadr", "wajaa fi sadr", "ألم في الصدر", "ألم الصدر", "وجع في الصدر", "ألم شديد في الصدر",
            "bol v grudi", "bol v serdtse", "боль в груди", "давление в груди", "боль в сердце", "сильная боль в груди",
            "mune no itami", "kyotsu", "胸の痛み", "胸痛", "心臓の痛み", "胸が痛い",
            "gaseum tongjeung", "hyungtong", "가슴 통증", "흉통", "심장 통증",
            "xiongtong", "xiongmen", "胸痛", "胸闷", "心痛", "胸口疼",
            "naen na-ok", "jep na-ok", "แน่นหน้าอก", "เจ็บหน้าอก", "ปวดหน้าอก",
            "dor no peito", "pressão no peito", "aperto no peito", "dor cardíaca", "dor torácica",
            "dolor de pecho", "presión en el pecho", "opresión en el pecho", "dolor cardíaco",
            "douleur thoracique", "douleur à la poitrine", "douleur au coeur",
            "brustschmerzen", "herzschmerz", "schmerzen in der brust", "brustenge",
            "dolore al petto", "pressione al petto", "oppressione toracica", "dolore toracico", "dolore al cuore"
        });

        dictionary.put("Shortness of Breath", new String[]{
            "shortness of breath", "difficulty breathing", "cannot breathe", "can't breathe", "cant breathe",
            "trouble breathing", "unable to breathe", "breathless", "hard to breathe", "gasping", "heavy breathing", "suffocating",
            "moochu thinaral", "moochu vida mudiyavillai", "மூச்சு திணறல்", "மூச்சுத் திணறல்", "மூச்சுத்திணறல்", "மூச்சு விட", "மூச்சு",
            "saans lene me dikkat", "saans phoolna", "dum ghutna", "saans", "सांस लेने में तकलीफ", "सांस लेने में दिक्कत", "सांस फूलना",
            "swasa teesukovadam kastam", "swasa adakapovadam", "aayasam", "swasa", "శ్వాస తీసుకోవడం కష్టం", "శ్వాస ఆడకపోవడం", "శ్వాస తీసుకోవడంలో ఇబ్బంది",
            "usiraata tondare", "usiraadalu kashta", "usiru kattuvudu", "ಉಸಿರಾಟದ ತೊಂದರೆ", "ಉಸಿರಾಡಲು ಕಷ್ಟ", "ಉಸಿರಾಟದ ತೊಂದರೆ",
            "shwasam muttal", "shwasam edukal budhimutt", "shwasam", "ശ്വാസതടസ്സം", "ശ്വാസം മുട്ടൽ",
            "shwashkosto", "shwash nite koshto", "শ্বাসকষ্ট", "শ্বাস নিতে কষ্ট",
            "shwas ghyayla tras", "dam lagne", "श्वास घेण्यास त्रास", "दम लागणे",
            "saans lene me takleef", "dam ghutna", "سانس لینے میں تکلیف", "سانس لینے میں دشواری", "سانس پھولنا", "دم گھٹنا", "سانس",
            "diq tanaffus", "souba fi tanaffus", "ضيق في التنفس", "صعوبة في التنفس", "ضيق التنفس",
            "odyshka", "zatrudnennoe dykhanie", "одышка", "затрудненное дыхание", "не могу дышать",
            "ikigurushii", "kokyu konnan", "息苦しい", "呼吸困難", "息ができない",
            "hoheup gonran", "sumswigi himdeul", "호흡 곤란", "숨쉬기 힘들", "숨쉬기 힘들어요",
            "huxi kunnan", "chuan bu shang qi", "呼吸困难", "喘不上气", "气短",
            "hai jai mai ok", "nueai hop", "หายใจลำบาก", "หายใจไม่ออก", "เหนื่อยหอบ",
            "falta de ar", "dificuldade para respirar", "não consigo respirar", "dispneia",
            "falta de aire", "dificultad para respirar", "no puedo respirar", "ahogo",
            "essoufflement", "difficulté à respirer", "ne peux pas respirer",
            "atemnot", "schweres atmen", "keine luft bekommen", "kurzatmig",
            "difficoltà a respirare", "mancanza di respiro", "non riesco a respirare", "fiato corto", "affanno"
        });

        dictionary.put("Radiating Arm Pain", new String[]{
            "arm pain", "radiating pain", "left arm", "pain down arm", "shoulder pain", "jaw pain",
            "kai vali", "idathu kai vali", "இடது கை வலி", "haath me dard", "बाएं हाथ में दर्द",
            "cheyi noppi", "yedama cheyi noppi", "ఎడమ చేయి నొప్పి",
            "kai novu", "yedagaim novu", "ಎಡಗೈ ನೋवु",
            "kai vedhana", "idathukal vedhana", "ഇടതു കൈ വേദന",
            "bame haate betha", "বামে হাতে ব্যথা", "dava haat dukhne", "डावा हात दुखणे",
            "baayein haath me dard", "بائیں ہاتھ میں درد",
            "alam fi dhira", "ألم في الذراع الأيسر", "bol v ruke", "боль в левой руке",
            "hidariude no itami", "左腕の痛み", "oenjjok pal tongjeung", "왼쪽 팔 통증",
            "zuobi tong", "左臂痛", "puat khaen sai", "ปวดแขนซ้าย",
            "dor no braço", "dor no braço esquerdo", "braço esquerdo",
            "dolor en el brazo", "brazo izquierdo",
            "douleur au bras", "bras gauche",
            "armschmerzen", "linker arm",
            "dolore al braccio", "braccio sinistro"
        });

        dictionary.put("Stroke Warning Signs", new String[]{
            "slurred speech", "facial drooping", "face drooping", "numbness in arm", "one side weakness", "paralysis", "sudden confusion",
            "pakkavatham", "mugam kozhaithal", "பக்கவாதம்", "lakwa", "लकवा",
            "pakshavatham", "lakva", "పక్షవాతం",
            "pakshaghata", "ಪಕ್ಷಘಾತ",
            "pakshagatham", "പക്ഷാഘാതം",
            "paralysis", "প্যারালাইসিস", "lakwa", "अर्धांगवायू", "فالج", "لقوہ",
            "sakta dimaghiya", "جلطة دماغية", "shlaganfall", "инсульт", "паралич лица",
            "nosotchu", "脳卒中", "mahi", "뇌졸중", "마비", "zhongfeng", "中风", "อัมพฤกษ์",
            "boca torta", "paralisia", "derrame", "avc",
            "parálisis", "paralisis facial",
            "paralysie faciale", "avc",
            "lähmung", "schlaganfall",
            "ictus", "paralisi facciale"
        });

        dictionary.put("High Fever", new String[]{
            "high fever", "burning up", "severe fever", "102", "103", "104", "shivering with fever",
            "athiga kaichal", "kaichal", "காய்ச்சல்", "tez bukhar", "bukhar", "तेज़ बुखार", "बुखार",
            "tivramaina jwaram", "ekkuva jwaram", "jwaram", "తీవ్రమైన జ్వరం", "జ్వరం",
            "tivra jvara", "jvara", "jwara", "ತೀವ್ರ ಜ್ವರ", "ಜ್ವರ",
            "kadutta pani", "pani", "കടുത്ത പനി", "പനി",
            "tibro jhor", "তীব্র জ্বর", "tivra taap", "तीव्र ताप", "tez bukhar", "تیز بخار",
            "humma shadida", "حمى شديدة", "vysokaya temperatura", "высокая температура", "жар",
            "kounetsu", "高熱", "goyeol", "고열", "gaoshao", "高烧", "khai sung", "ไข้สูง",
            "febre alta", "febre intensa", "febre forte",
            "fiebre alta", "fiebre fuerte",
            "fièvre élevée", "forte fièvre",
            "hohes fieber", "starkes fieber",
            "febbre alta", "febbre forte"
        });

        dictionary.put("Mild Fever", new String[]{
            "mild fever", "slight fever", "low grade fever", "warm body",
            "lesana kaichal", "mild kaichal", "லேசான காய்ச்சல்", "halka bukhar", "हल्का बुखार",
            "chinna jwaram", "swalpa jwaram", "చిన్న జ్వరం",
            "swalpa jvara", "ಸ್ವಲ್ಪ ಜ್ವರ",
            "cheriya pani", "ചെറിയ പনি",
            "halka jhor", "হালকা জ্বর", "halka taap", "हलका ताप", "halka bukhar", "ہلکا بخار",
            "humma khafifa", "حمى خفيفة", "nebolshoy zhar", "небольшая температура",
            "binetsu", "微熱", "miyeol", "미열", "di re", "低烧", "khai tam", "ไข้ต่ำ",
            "febre baixa", "febre leve",
            "fiebre leve", "fiebre baja",
            "fièvre légère",
            "leichtes fieber",
            "febbre lieve", "febbricola"
        });

        dictionary.put("Severe Headache", new String[]{
            "thunderclap headache", "worst headache", "severe headache", "migraine", "stiff neck",
            "thalai vali", "kodiya thalai vali", "தலைவலி", "sir dard", "tez sar dard", "सिर दर्द",
            "tala noppi", "tivramaina tala noppi", "తలనొప్పి", "తీవ్రమైన తలనొప్పి",
            "tale novu", "tale noovu", "tivra tale novu", "ತಲೆನೋವು", "ತೀವ್ರ ತಲೆನೋವು",
            "thala vedhana", "thalavedhana", "katinamaya thala vedhana", "തലവേദന", "കഠിനമായ തലവേദന",
            "matha betha", "মাথাব্যথা", "dokedukhi", "डोकेदुखी", "sar dard", "شدید سر درد",
            "sudaa shadid", "صداع حاد", "صداع", "silnaya golovnaya bol", "сильная головная боль", "мигрень",
            "zutsu", "頭痛", "hidoi zutsu", "dutoong", "두통", "simhan dutoong", "toutong", "头痛", "剧烈头痛",
            "puat hua", "ปวดหัว", "ปวดศีรษะ",
            "dor de cabeça severa", "dor de cabeça forte", "enxaqueca", "dor de cabeça",
            "fuerte dolor de cabeza", "dolor de cabeza", "migraña",
            "maux de tête intenses", "migraine sévère", "mal de tête",
            "starke kopfschmerzen", "migräne", "kopfschmerzen",
            "forte mal di testa", "cefalea acuta", "emicrania", "mal di testa"
        });

        dictionary.put("Cough", new String[]{
            "cough", "coughing", "dry cough", "productive cough", "phlegm",
            "irumal", "vattu irumal", "இருமல்", "khansi", "sukhi khansi", "balgam", "खांसी",
            "daggu", "podi daggu", "దగ్గు", "పొడి దగ్గు", "కఫం",
            "kemmu", "ona kemmu", "ಕೆಮ್ಮು", "ಒಣ ಕೆಮ್ಮು", "ಕಫ",
            "chuma", "varanda chuma", "ചുമ", "വരണ്ട ചുമ", "കഫം",
            "kashi", "কাশি", "khokla", "खोकला", "khansi", "کھانسی",
            "sual", "سعال", "كحة", "kashel", "кашель", "сухой кашель",
            "seki", "咳", "せき", "gichim", "기침", "kesou", "咳嗽", "ai", "ไอ",
            "tosse", "tosse seca", "catarro",
            "tos", "tos seca", "flema",
            "toux", "toux sèche", "glaires",
            "husten", "trockener husten", "schleim",
            "tosse", "tosse secca", "catarro"
        });

        dictionary.put("Abdominal Pain", new String[]{
            "stomach pain", "abdominal pain", "belly ache", "stomach cramps",
            "vayitru vali", "vayiru vali", "வயிறு வலி", "pet dard", "pet me dard", "पेट दर्द",
            "kadupu noppi", "kadupulo noppi", "కడుపు నొప్పి",
            "hotte novu", "hotte noovu", "ಹೊಟ್ಟೆ ನೋವು",
            "vayar vedhana", "vayaril vedhana", "വയറുവേദന",
            "pet betha", "পেট ব্যথা", "potdukhi", "पोटदुखी", "pet me dard", "پیٹ میں درد",
            "alam fi batn", "ألم في البطن", "مغص", "bol v zhivote", "боль в животе",
            "fukutsu", "腹痛", "お腹が痛い", "boktong", "복통", "배가 아파", "futong", "腹痛", "肚子疼", "puat thong", "ปวดท้อง",
            "dor de barriga", "dor abdominal", "dor de estômago", "cólica",
            "dolor de estómago", "dolor abdominal", "dolor de barriga",
            "mal de ventre", "douleur abdominale", "maux d'estomac",
            "bauchschmerzen", "magenschmerzen", "unterleibsschmerzen",
            "mal di pancia", "dolore addominale", "mal di stomaco", "crampi allo stomaco"
        });

        dictionary.put("Vomiting / Diarrhea", new String[]{
            "vomiting", "throwing up", "diarrhea", "loose stools", "nausea",
            "vanthi", "bedhi", "வாந்தி", "பேதி", "ulti", "dast", "उल्टी", "दस्त",
            "vanthulu", "vanti", "virechanalu", "వాంతులు", "విరేచనాలు",
            "vaanti", "vanti", "bhedi", "ವಾಂತಿ", "ಭೇದಿ",
            "chardhi", "chardi", "vayarilakkam", "ഛർദ്ദി", "വയറിളക്കം",
            "bomi", "বমি", "ultya", "उलट्या", "julab", "जुलाब", "qay", "قے", "الٹی", "دست",
            "qay", "قيء", "إسهال", "rvota", "рвота", "понос", "диарея",
            "outo", "嘔吐", "下痢", "guto", "구토", "seolsa", "설사", "outu", "呕吐", "fuxie", "腹泻", "a-jian", "อาเจียน", "ท้องเสีย",
            "vômito", "vomitando", "diarreia", "náusea",
            "vómito", "diarrea", "náuseas",
            "vomissements", "diarrhée", "nausée",
            "erbrechen", "übelkeit", "durchfall",
            "vomito", "nausea", "diarrea"
        });

        dictionary.put("Blood in Stool or Vomit", new String[]{
            "blood in vomit", "vomiting blood", "black stool", "blood in stool", "hematemesis",
            "vanthiyil ratham", "malathil ratham", "வாந்தியில் ரத்தம்", "ulti me khoon", "उल्टी में खून",
            "vanthulo raktham", "raktham tho vanthulu", "వాంతిలో రక్తం",
            "vaantiyalli raktha", "ವಾಂತಿಯಲ್ಲಿ ರಕ್ತ",
            "chardhiyodu koodi raktham", "ഛർദ്ദിയിൽ രക്തം",
            "bomi te rokt", "বমিতে রক্ত", "raktachi ulti", "रक्ताची उलटी", "khoon ki ulti", "خون کی الٹی",
            "dam fi qay", "دم في القيء", "krov v rvote", "кровь в рвоте", "krov v kale", "кровь в кале",
            "toketsu", "吐血", "tophyeol", "토혈", "ou xue", "呕血", "bian xue", "便血", "lueat ok thi a-jian", "เลือดออกในอาเจียน",
            "sangue no vômito", "sangue nas fezes"
        });

        dictionary.put("Knee & Lower Limb Injury", new String[]{
            "knee injury", "knee pain", "injured knee", "knee swollen", "leg injury", "shin pain", "thigh pain", "hit knee", "knee", "leg",
            "முட்டையில்", "முட்டி", "முழங்கால்", "முழங்காலில்", "கால் முட்டி", "கால்", "காலில்", "மூட்டு", "கணுக்கால்",
            "घुटना", "घुटने में चोट", "घुटने में दर्द", "पैर", "टांग", "टखना",
            "మోకాలు", "మోకాలి నొప్పి", "కాలు",
            "ಮೊಣಕಾಲು", "ಮೊಣಕಾಲಿನ ಗಾಯ", "ಕಾಲು",
            "മുട്ട്", "മുട്ടിന് പരിക്ക്", "കാൽ",
            "হাঁটু", "ঘুটনা", "گھٹنا", "پاؤں", "ركبة", "ساق", "колено", "нога",
            "膝", "ひざ", "무릎", "다리", "膝盖", "腿", "หัวเข่า", "ขา",
            "joelho", "perna", "rodilla", "pierna", "genou", "jambe", "knie", "bein", "ginocchio", "gamba"
        });

        dictionary.put("Menstrual Cramps / Dysmenorrhea", new String[]{
            "menstrual cramps", "menstrual cramp", "period pain", "period cramps", "menstrual pain", "dysmenorrhea", "cramps in lower abdomen", "period cramp", "cramping", "cramps",
            "மாதவிடாய் வலி", "மாதவிடாய் பிடிப்பு", "வயிறு வலி மாதவிடாய்", "மாதவிடாய்",
            "माहवारी का दर्द", "पीरियड्स में दर्द", "मासिक धर्म दर्द", "मासिक दर्द", "पीरियड में दर्द",
            "పీరియడ్స్ నొప్పి", "రుతుక్రమ నొప్పి", "పీరియడ్ నొప్పి", "నెలసరి నొప్పి",
            "ಮುಟ್ಟಿನ ನೋವು", "ತಿಂಗಳ ನೋವು",
            "ആർത്തവ വേദന", "ആർത്തവ സംബന്ധമായ വേദന",
            "মাসিকের ব্যথা", "পিরিয়ডের ব্যথা",
            "मासिक पाळीचा त्रास", "मासिक पाळी वेदना",
            "حیض کا درد", "پیریڈ کا درد",
            "ألم الدورة الشهرية", "تقلصات الدورة",
            "менструальные боли", "боли при месячных",
            "生理痛", "월경통", "생리통", "痛经", "月经痛",
            "ปวดประจำเดือน", "ปวดท้องประจำเดือน",
            "cólicas menstruais", "cólica menstrual", "dor menstrual",
            "cólicos menstruales", "dolor menstrual",
            "douleurs de règles", "crampes menstruelles",
            "regelschmerzen", "menstruationsbeschwerden",
            "dolori mestruali", "crampi mestruali"
        });

        dictionary.put("Irregular Menstrual Cycle", new String[]{
            "irregular periods", "irregular period", "missed period", "delayed period", "heavy menstrual bleeding", "irregular cycles", "menorrhagia", "pcos", "pcod", "hormonal imbalance",
            "ஒழுங்கற்ற மாதவிடாய்", "தாமதமான மாதவிடாய்",
            "अनियमित पीरियड्स", "अनियमित माहवारी",
            "సక్రమంగా లేని పీరియడ్స్", "పీరియడ్స్ ఆలస్యం", "క్రమరహిత పీరియడ్స్",
            "ಅನಿಯಮಿತ ಮುಟ್ಟು", "ಮುಟ್ಟು ತಡವಾಗುವುದು",
            "ക്രമരഹിതമായ ആർത്തവം",
            "অনিয়মিত মাসিক",
            "অনियमित पाळी",
            "بے قاعدہ حیض",
            "عدم انتظام الدورة الشهرية",
            "нерегулярные месячные",
            "生理不順", "월경 불순", "생리 불순", "月经不调",
            "ประจำเดือนมาไม่ปกติ",
            "menstruação irregular", "ciclo irregular",
            "periodo irregular", "menstruación irregular",
            "règles irrégulières", "cycle irrégulier",
            "unregelmäßige periode", "zyklusstörungen",
            "ciclo mestruale irregolare", "mestruazioni irregolari"
        });

        dictionary.put("Acute Pain & Internal Discomfort", new String[]{
            "acute pain", "severe pain", "internal pain", "hurting inside", "throbbing pain", "deep pain", "pain",
            "பெயிண்ட்", "பெயின்", "உள் வலி", "அடிபட்ட வலி", "குடைச்சல்", "உளைச்சல்", "நோவு", "வலி",
            "दर्द", "तकलीफ", "आंतरिक दर्द", "तीव्र दर्द", "पेन",
            "నొప్పి", "లోపల నొప్పి", "బాధ",
            "ನೋವು", "ಒಳ ನೋವು",
            "വേദന", "അകത്ത് വേദന",
            "ব্যথা", "तक्रार", "درد", "ألم شديد", "боль", "сильная боль",
            "激痛", "痛み", "통증", "심한 통증", "疼痛", "剧痛", "ปวดมาก",
            "dor intensa", "dor interna", "dolor agudo", "dolor interno", "forte douleur", "starke schmerzen", "forte dolore"
        });

        for (Map.Entry<String, String[]> entry : dictionary.entrySet()) {
            String symptomName = entry.getKey();
            for (String synonym : entry.getValue()) {
                if (lower.contains(synonym)) {
                    boolean redFlag = isRedFlagSymptom(symptomName, lower);
                    String bodyPart = resolveBodyPart(symptomName);
                    String localizedName = localizeSymptomName(symptomName, language);
                    list.add(new Symptom(localizedName, severity, durationDays, bodyPart, redFlag));
                    break;
                }
            }
        }

        // If no specific recognized keyword, but text has medical distress words
        if (list.isEmpty()) {
            if (lower.contains("pain") || lower.contains("hurt") || lower.contains("sick") || lower.contains("vali") || lower.contains("dard")
                || lower.contains("noppi") || lower.contains("noovu") || lower.contains("vedhana") || lower.contains("dor ") || lower.contains("dolore")
                || lower.contains("schmerz") || lower.contains("douleur") || lower.contains("dolor") || lower.contains("నొప్పి") || lower.contains("ನೋವು") || lower.contains("വേദന")
                || lower.contains("боль") || lower.contains("痛") || lower.contains("통증") || lower.contains("ปวด") || lower.contains("ألم") || lower.contains("درد")
                || lower.contains("ব্যথা") || lower.contains("दुखणे")
                || lower.contains("பெயிண்ட்") || lower.contains("பெயின்") || lower.contains("அடிபட்டு") || lower.contains("விழுந்து")
                || lower.contains("பிராக்சர்") || lower.contains("காயம்") || lower.contains("முட்டி")) {
                String genName = "ta".equalsIgnoreCase(language) ? "பொதுவான அசௌகரியம் (General Discomfort)" : "Unspecified Discomfort";
                list.add(new Symptom(genName, severity, durationDays, "General", false));
            }
        }

        return list;
    }

    private String localizeSymptomName(String name, String lang) {
        return guidanceProvider.localizeSymptom(name, lang);
    }

    private boolean containsWord(String text, String word) {
        if (text == null || word == null || word.isEmpty()) return false;
        Pattern p = Pattern.compile("(?:^|[^a-zA-Z0-9])" + Pattern.quote(word) + "(?:$|[^a-zA-Z0-9])", Pattern.CASE_INSENSITIVE);
        return p.matcher(text).find();
    }

    private TriageResult runClinicalTriageRules(List<Symptom> symptoms, String rawText, String language) {
        String lower = rawText.toLowerCase();
        String lang = (language != null) ? language.toLowerCase() : "en";

        boolean hasChestPain = hasSymptom(symptoms, "Chest Pain") || hasSymptom(symptoms, "நெஞ்சு வலி")
            || lower.contains("chest pain") || containsWord(lower, "chest")
            || containsWord(lower, "peito") || containsWord(lower, "petto") || containsWord(lower, "brust")
            || containsWord(lower, "gunde") || containsWord(lower, "ede") || containsWord(lower, "nenchu") || containsWord(lower, "nenju") || containsWord(lower, "seene")
            || lower.contains("நெஞ்சு") || lower.contains("மார்பு")
            || lower.contains("सीने") || lower.contains("छाती")
            || lower.contains("ఛాతీ") || lower.contains("గుండె") || lower.contains("ಎದೆ") || lower.contains("നെഞ്ചു")
            || lower.contains("سینے") || lower.contains("سینہ") || lower.contains("دل")
            || lower.contains("груди") || lower.contains("сердц") || lower.contains("胸") || lower.contains("가슴") || lower.contains("หน้าอก")
            || lower.contains("صدر") || lower.contains("বুকে") || lower.contains("छातीत");
        boolean hasBreathingDifficulty = hasSymptom(symptoms, "Shortness of Breath") || hasSymptom(symptoms, "மூச்சுத் திணறல்")
            || lower.contains("shortness of breath") || containsWord(lower, "breathe") || containsWord(lower, "breath")
            || containsWord(lower, "respirar") || containsWord(lower, "respiro") || containsWord(lower, "atmen")
            || containsWord(lower, "swasa") || containsWord(lower, "usiru") || containsWord(lower, "shwasam") || containsWord(lower, "saans") || containsWord(lower, "moochu")
            || lower.contains("மூச்சு") || lower.contains("திணறல்")
            || lower.contains("सांस") || lower.contains("سانس")
            || lower.contains("శ్వాస") || lower.contains("ಉಸಿರ") || lower.contains("ശ്വാസ")
            || lower.contains("одышка") || lower.contains("дышать") || lower.contains("息") || lower.contains("호흡")
            || lower.contains("หายใจ") || lower.contains("تنفس") || lower.contains("শ্বাস") || lower.contains("श्वास");

        boolean hasRadiatingArm = hasSymptom(symptoms, "Radiating Arm Pain") || hasSymptom(symptoms, "கை வலி") || lower.contains("left arm")
            || lower.contains("radiating to arm") || containsWord(lower, "braço") || containsWord(lower, "braccio") || lower.contains("linker arm")
            || containsWord(lower, "yedama") || containsWord(lower, "edagai") || containsWord(lower, "idathu") || containsWord(lower, "baayein")
            || lower.contains("ரூகே") || lower.contains("左腕") || lower.contains("팔") || lower.contains("แขน") || lower.contains("الذراع");

        boolean hasStrokeSigns = hasSymptom(symptoms, "Stroke Warning Signs") || hasSymptom(symptoms, "பக்கவாத அறிகுறிகள்")
            || containsWord(lower, "slurred") || containsWord(lower, "droop") || containsWord(lower, "stroke")
            || containsWord(lower, "avc") || containsWord(lower, "ictus") || containsWord(lower, "lakwa") || containsWord(lower, "pakshavatham") || containsWord(lower, "pakshaghata")
            || lower.contains("инсульт") || lower.contains("脳卒中") || lower.contains("뇌졸중") || lower.contains("中风") || lower.contains("فالج") || lower.contains("جلطة");

        boolean hasHighFever = hasSymptom(symptoms, "High Fever") || hasSymptom(symptoms, "அதிக காய்ச்சல்");
        boolean hasMildFever = hasSymptom(symptoms, "Mild Fever") || hasSymptom(symptoms, "லேசான காய்ச்சல்");
        boolean hasCough = hasSymptom(symptoms, "Cough") || hasSymptom(symptoms, "இருமல்") || lower.contains("cough") || lower.contains("tosse") || lower.contains("husten")
            || containsWord(lower, "daggu") || containsWord(lower, "kemmu") || containsWord(lower, "chuma") || containsWord(lower, "khansi")
            || lower.contains("இருமல்") || lower.contains("खांसी") || lower.contains("کھانسی")
            || lower.contains("кашель") || lower.contains("咳") || lower.contains("기침") || lower.contains("ไอ") || lower.contains("سعال") || lower.contains("কাশি");

        boolean hasSevereHeadache = hasSymptom(symptoms, "Severe Headache") || hasSymptom(symptoms, "கடுமையான தலைவலி") || lower.contains("headache")
            || lower.contains("enxaqueca") || lower.contains("emicrania") || lower.contains("kopfschmerz")
            || containsWord(lower, "tala noppi") || containsWord(lower, "tale novu") || containsWord(lower, "thala vedhana") || containsWord(lower, "sir dard")
            || lower.contains("தலைவலி") || lower.contains("सिर दर्द") || lower.contains("سر दर्द")
            || lower.contains("головная боль") || lower.contains("頭痛") || lower.contains("두통") || lower.contains("ปวดหัว") || lower.contains("صداع") || lower.contains("মাথাব্যথা");

        boolean hasAbdominalPain = hasSymptom(symptoms, "Abdominal Pain") || hasSymptom(symptoms, "வயிறு வலி")
            || containsWord(lower, "kadupu") || containsWord(lower, "hotte") || containsWord(lower, "vayar")
            || containsWord(lower, "pancia") || containsWord(lower, "barriga") || containsWord(lower, "bauch")
            || lower.contains("வயிறு") || lower.contains("पेट") || lower.contains("پیٹ")
            || lower.contains("животе") || lower.contains("腹") || lower.contains("배") || lower.contains("ท้อง") || lower.contains("بطن") || lower.contains("পেট");

        boolean hasBloodVomitOrStool = hasSymptom(symptoms, "Blood in Stool") || hasSymptom(symptoms, "Blood in Stool or Vomit") || hasSymptom(symptoms, "இரத்தப்போக்கு");
        boolean hasCut = hasSymptom(symptoms, "Cut or Bleeding") || hasSymptom(symptoms, "வெட்டுக் காயம்");
        boolean hasBurn = hasSymptom(symptoms, "Burn") || hasSymptom(symptoms, "தீக்காயம்");
        boolean hasSprain = hasSymptom(symptoms, "Sprain / Joint Pain") || hasSymptom(symptoms, "மூட்டு உளுக்கு");
        boolean hasFainting = hasSymptom(symptoms, "Dizziness / Fainting") || hasSymptom(symptoms, "மயக்கம்");
        boolean hasAllergy = hasSymptom(symptoms, "Allergic Reaction") || hasSymptom(symptoms, "ஒவ்வாமை");

        // Specific Orthopedic Trauma, Fall & Fracture Detection
        boolean hasFracture = hasSymptom(symptoms, "Bone Fracture") || hasSymptom(symptoms, "Bone Fracture / Suspected Fracture") || hasSymptom(symptoms, "எலும்பு முறிவு")
            || containsWord(lower, "fracture") || lower.contains("பிராக்சர்") || lower.contains("ஃபிராக்சர்")
            || lower.contains("போரன்") || lower.contains("போன்") || lower.contains("முறிவு") || lower.contains("broken bone")
            || lower.contains("हड्डी") || containsWord(lower, "fratura") || containsWord(lower, "fractura") || containsWord(lower, "fraktur");

        boolean hasFallOrTrauma = hasSymptom(symptoms, "Fall") || hasSymptom(symptoms, "Fall / Physical Trauma") || hasSymptom(symptoms, "விழுந்த") || hasSymptom(symptoms, "காயம்")
            || containsWord(lower, "fell") || containsWord(lower, "fall") || lower.contains("stairs") || lower.contains("விழுந்து")
            || lower.contains("அடிபட்டு") || lower.contains("படியிலிருந்து") || lower.contains("கீழே") || lower.contains("गिर");

        boolean hasKneeOrLimb = hasSymptom(symptoms, "Knee") || hasSymptom(symptoms, "Knee & Lower Limb Injury") || hasSymptom(symptoms, "முட்டி") || hasSymptom(symptoms, "கால்")
            || containsWord(lower, "knee") || containsWord(lower, "leg") || lower.contains("முட்டி") || lower.contains("முட்டையில்")
            || lower.contains("முழங்கால்") || lower.contains("கால்") || lower.contains("घुटना") || containsWord(lower, "joelho") || containsWord(lower, "rodilla");

        boolean hasPain = hasSymptom(symptoms, "Pain") || hasSymptom(symptoms, "Acute Pain & Internal Discomfort") || hasSymptom(symptoms, "வலி")
            || containsWord(lower, "pain") || lower.contains("வலி") || lower.contains("பெயிண்ட்") || lower.contains("பெயின்")
            || containsWord(lower, "dard") || containsWord(lower, "noppi") || containsWord(lower, "novu") || containsWord(lower, "vedhana") || containsWord(lower, "dor") || containsWord(lower, "dolor");

        boolean hasMenstrualSymptom = hasSymptom(symptoms, "Menstrual Cramps / Dysmenorrhea") || hasSymptom(symptoms, "Irregular Menstrual Cycle")
            || lower.contains("period") || lower.contains("menstrual") || lower.contains("cramp") || lower.contains("dysmenorrhea")
            || lower.contains("pcos") || lower.contains("pcod") || lower.contains("மாதவிடாய்") || lower.contains("माहवारी") || lower.contains("मासिक")
            || lower.contains("పీరియడ్") || lower.contains("ముట్టు") || lower.contains("ആർത്തവ") || lower.contains("মাসিক");

        // ----------------------------------------------------
        // RULE 1: Cardiac / Respiratory Emergency
        // ----------------------------------------------------
        if (!hasMenstrualSymptom && (((hasChestPain && (hasBreathingDifficulty || hasRadiatingArm || lower.contains("sweat") || lower.contains("left arm") || lower.contains("severe") || lower.contains("tivramaina") || lower.contains("tivra") || lower.contains("kadutta") || lower.contains("forte") || lower.contains("intensa") || lower.contains("شدید") || lower.contains("сильн") || lower.contains("கடுமை") || lower.contains("तीव्र") || lower.contains("তীব্র")))
            || (hasChestPain && (lower.contains("chest pain") || lower.contains("dor no peito") || lower.contains("dolore al petto") || lower.contains("brustschmerzen") || lower.contains("gunde noppi") || lower.contains("ede noovu") || lower.contains("nenchu vedhana") || lower.contains("nenju vali") || lower.contains("seene me dard") || lower.contains("நெஞ்சு வலி") || lower.contains("நெஞ்சுவலி") || lower.contains("சீனே") || lower.contains("सीने में दर्द") || lower.contains("గుండె నొప్పి") || lower.contains("ಎದೆ ನೋವು") || lower.contains("നെഞ്ചുവേദന") || lower.contains("سینے میں दर्द") || lower.contains("боль в груди") || lower.contains("胸の痛み") || lower.contains("가슴 통증") || lower.contains("เจ็บหน้าอก") || lower.contains("ألم في الصدر") || lower.contains("বুকে ব্যথা") || lower.contains("छातीत दुखणे")))))) {
            String urgency = "EMERGENCY";
            String department = guidanceProvider.getDepartment("CARDIAC_EMERGENCY_PROTOCOL_01", lang);
            String rec = guidanceProvider.getRecommendation("CARDIAC_EMERGENCY_PROTOCOL_01", lang);
            String reason = guidanceProvider.getReason("CARDIAC_EMERGENCY_PROTOCOL_01", lang);
            String ruleMatched = "CARDIAC_EMERGENCY_PROTOCOL_01";
            double confidence = 0.98;
            String speech = speechService.generateSpokenResponse(urgency, department, rec, language);
            return new TriageResult(urgency, rec, department, reason, ruleMatched, confidence, speech);
        }

        // ----------------------------------------------------
        // RULE 2: Acute Stroke / Neurological Emergency (FAST)
        // ----------------------------------------------------
        if (hasStrokeSigns || (hasSevereHeadache && (lower.contains("stiff neck") || lower.contains("worst headache") || lower.contains("thunderclap")))) {
            String urgency = "EMERGENCY";
            String department = guidanceProvider.getDepartment("NEURO_FAST_EMERGENCY_02", lang);
            String rec = guidanceProvider.getRecommendation("NEURO_FAST_EMERGENCY_02", lang);
            String reason = guidanceProvider.getReason("NEURO_FAST_EMERGENCY_02", lang);
            String ruleMatched = "NEURO_FAST_EMERGENCY_02";
            double confidence = 0.96;
            String speech = speechService.generateSpokenResponse(urgency, department, rec, language);
            return new TriageResult(urgency, rec, department, reason, ruleMatched, confidence, speech);
        }

        // ----------------------------------------------------
        // RULE 3: Severe Gastrointestinal Bleeding / Acute Abdomen
        // ----------------------------------------------------
        if (hasBloodVomitOrStool || (hasAbdominalPain && (lower.contains("rigid") || lower.contains("unbearable") || lower.contains("excruciating") || lower.contains("fainted")))) {
            String urgency = "EMERGENCY";
            String department = guidanceProvider.getDepartment("GI_BLEED_ACUTE_ABDOMEN_03", lang);
            String rec = guidanceProvider.getRecommendation("GI_BLEED_ACUTE_ABDOMEN_03", lang);
            String reason = guidanceProvider.getReason("GI_BLEED_ACUTE_ABDOMEN_03", lang);
            String ruleMatched = "GI_BLEED_ACUTE_ABDOMEN_03";
            double confidence = 0.95;
            String speech = speechService.generateSpokenResponse(urgency, department, rec, language);
            return new TriageResult(urgency, rec, department, reason, ruleMatched, confidence, speech);
        }

        // ----------------------------------------------------
        // RULE 4: Severe Anaphylaxis / Airway Compromise
        // ----------------------------------------------------
        if (hasAllergy && (hasBreathingDifficulty || lower.contains("throat") || lower.contains("lip") || lower.contains("tongue"))) {
            String urgency = "EMERGENCY";
            String department = guidanceProvider.getDepartment("ANAPHYLAXIS_EMERGENCY_04", lang);
            String rec = guidanceProvider.getRecommendation("ANAPHYLAXIS_EMERGENCY_04", lang);
            String reason = guidanceProvider.getReason("ANAPHYLAXIS_EMERGENCY_04", lang);
            String ruleMatched = "ANAPHYLAXIS_EMERGENCY_04";
            double confidence = 0.97;
            String speech = speechService.generateSpokenResponse(urgency, department, rec, language);
            return new TriageResult(urgency, rec, department, reason, ruleMatched, confidence, speech);
        }

        // ----------------------------------------------------
        // RULE 5: Orthopedic Bone Fracture / Blunt Trauma / Fall Injury (Targeted for Fall & Limb Injury)
        // ----------------------------------------------------
        if (hasFracture || (hasFallOrTrauma && (hasKneeOrLimb || hasPain || hasSprain || lower.contains("ముట్టి") || lower.contains("ముట్టையில்") || lower.contains("பிராக்சர்") || lower.contains("போரன்") || lower.contains("போன்")))) {
            String urgency = (lower.contains("compound") || lower.contains("open bone") || lower.contains("unconscious") || lower.contains("heavy bleeding")) ? "EMERGENCY" : "MODERATE";
            String department = guidanceProvider.getDepartment("ORTHOPEDIC_FRACTURE_TRAUMA_07", lang);
            String rec = guidanceProvider.getRecommendation("ORTHOPEDIC_FRACTURE_TRAUMA_07", lang);
            String reason = guidanceProvider.getReason("ORTHOPEDIC_FRACTURE_TRAUMA_07", lang);
            String ruleMatched = "ORTHOPEDIC_FRACTURE_TRAUMA_07";
            double confidence = 0.95;
            String speech = speechService.generateSpokenResponse(urgency, department, rec, language);
            return new TriageResult(urgency, rec, department, reason, ruleMatched, confidence, speech);
        }

        // ----------------------------------------------------
        // RULE 6: Moderate Priority - Respiratory / Persistent Infection
        // ----------------------------------------------------
        if ((hasHighFever && hasCough) || (hasBreathingDifficulty && !hasChestPain) || (hasCough && lower.contains("wheezing"))) {
            String urgency = "MODERATE";
            String department = guidanceProvider.getDepartment("RESPIRATORY_INFECTION_MODERATE_05", lang);
            String rec = guidanceProvider.getRecommendation("RESPIRATORY_INFECTION_MODERATE_05", lang);
            String reason = guidanceProvider.getReason("RESPIRATORY_INFECTION_MODERATE_05", lang);
            String ruleMatched = "RESPIRATORY_INFECTION_MODERATE_05";
            double confidence = 0.88;
            String speech = speechService.generateSpokenResponse(urgency, department, rec, language);
            return new TriageResult(urgency, rec, department, reason, ruleMatched, confidence, speech);
        }

        // ----------------------------------------------------
        // RULE 7: Moderate Priority - Persistent Abdominal Distress / Dehydration
        // ----------------------------------------------------
        if (hasAbdominalPain || (hasSymptom(symptoms, "Vomiting / Diarrhea") && (lower.contains("days") || lower.contains("severe") || lower.contains("dehydrated")))) {
            String urgency = "MODERATE";
            String department = guidanceProvider.getDepartment("GI_DISTRESS_MODERATE_06", lang);
            String rec = guidanceProvider.getRecommendation("GI_DISTRESS_MODERATE_06", lang);
            String reason = guidanceProvider.getReason("GI_DISTRESS_MODERATE_06", lang);
            String ruleMatched = "GI_DISTRESS_MODERATE_06";
            double confidence = 0.85;
            String speech = speechService.generateSpokenResponse(urgency, department, rec, language);
            return new TriageResult(urgency, rec, department, reason, ruleMatched, confidence, speech);
        }

        // ----------------------------------------------------
        // RULE 8: Moderate Priority - Musculoskeletal Injury / Sprain with Inability to Bear Weight
        // ----------------------------------------------------
        if (hasSprain && (lower.contains("can't walk") || lower.contains("cannot walk") || lower.contains("severe") || lower.contains("swollen") || lower.contains("நடக்க") || lower.contains("వీக்கம்"))) {
            String urgency = "MODERATE";
            String department = guidanceProvider.getDepartment("ORTHO_SPRAIN_MODERATE_07", lang);
            String rec = guidanceProvider.getRecommendation("ORTHO_SPRAIN_MODERATE_07", lang);
            String reason = guidanceProvider.getReason("ORTHO_SPRAIN_MODERATE_07", lang);
            String ruleMatched = "ORTHO_SPRAIN_MODERATE_07";
            double confidence = 0.89;
            String speech = speechService.generateSpokenResponse(urgency, department, rec, language);
            return new TriageResult(urgency, rec, department, reason, ruleMatched, confidence, speech);
        }

        // ----------------------------------------------------
        // RULE 8B: Gynecology & Women's Health - Menstrual Irregularities & Dysmenorrhea
        // ----------------------------------------------------
        if (hasMenstrualSymptom) {
            boolean isAcuteGynEmergency = lower.contains("fainted") || lower.contains("unbearable sharp")
                || lower.contains("severe hemorrhage") || lower.contains("soaking pad") || lower.contains("fainting");
            String urgency = isAcuteGynEmergency ? "EMERGENCY" : "MODERATE";
            String department = guidanceProvider.getDepartment("GYNECOLOGY_MENSTRUAL_HEALTH_12", lang);
            String rec = guidanceProvider.getRecommendation("GYNECOLOGY_MENSTRUAL_HEALTH_12", lang);
            String reason = guidanceProvider.getReason("GYNECOLOGY_MENSTRUAL_HEALTH_12", lang);
            String ruleMatched = "GYNECOLOGY_MENSTRUAL_HEALTH_12";
            double confidence = 0.94;
            String speech = speechService.generateSpokenResponse(urgency, department, rec, language);
            return new TriageResult(urgency, rec, department, reason, ruleMatched, confidence, speech);
        }

        // ----------------------------------------------------
        // RULE 9: Self-Care - Mild Upper Respiratory / Common Cold
        // ----------------------------------------------------
        if ((hasMildFever || hasCough) && !hasBreathingDifficulty && !hasChestPain && !lower.contains("severe")) {
            String urgency = "SELF_CARE";
            String department = guidanceProvider.getDepartment("VIRAL_UPPER_RESPIRATORY_SELFCARE_08", lang);
            String rec = guidanceProvider.getRecommendation("VIRAL_UPPER_RESPIRATORY_SELFCARE_08", lang);
            String reason = guidanceProvider.getReason("VIRAL_UPPER_RESPIRATORY_SELFCARE_08", lang);
            String ruleMatched = "VIRAL_UPPER_RESPIRATORY_SELFCARE_08";
            double confidence = 0.91;
            String speech = speechService.generateSpokenResponse(urgency, department, rec, language);
            return new TriageResult(urgency, rec, department, reason, ruleMatched, confidence, speech);
        }

        // ----------------------------------------------------
        // RULE 10: Self-Care - Minor Cut / Superficial Burn
        // ----------------------------------------------------
        if ((hasCut || hasBurn) && !lower.contains("deep") && !lower.contains("spurting") && !lower.contains("severe")) {
            String urgency = "SELF_CARE";
            String department = guidanceProvider.getDepartment("MINOR_WOUND_SELFCARE_09", lang);
            String rec = guidanceProvider.getRecommendation("MINOR_WOUND_SELFCARE_09", lang);
            String reason = guidanceProvider.getReason("MINOR_WOUND_SELFCARE_09", lang);
            String ruleMatched = "MINOR_WOUND_SELFCARE_09";
            double confidence = 0.93;
            String speech = speechService.generateSpokenResponse(urgency, department, rec, language);
            return new TriageResult(urgency, rec, department, reason, ruleMatched, confidence, speech);
        }

        // ----------------------------------------------------
        // RULE 11: Moderate Priority - Syncope / Fainting / Dizziness
        // ----------------------------------------------------
        if (hasFainting) {
            String urgency = (hasChestPain || hasBreathingDifficulty || lower.contains("head injury") || lower.contains("convulsion")) ? "EMERGENCY" : "MODERATE";
            String department = guidanceProvider.getDepartment("SYNCOPE_DIZZINESS_PROTOCOL_10", lang);
            String rec = guidanceProvider.getRecommendation("SYNCOPE_DIZZINESS_PROTOCOL_10", lang);
            String reason = guidanceProvider.getReason("SYNCOPE_DIZZINESS_PROTOCOL_10", lang);
            String ruleMatched = "SYNCOPE_DIZZINESS_PROTOCOL_10";
            double confidence = 0.87;
            String speech = speechService.generateSpokenResponse(urgency, department, rec, language);
            return new TriageResult(urgency, rec, department, reason, ruleMatched, confidence, speech);
        }

        // ----------------------------------------------------
        // RULE 12: Uncertain / Follow-Up Required
        // ----------------------------------------------------
        String urgency = "UNCERTAIN";
        String department = guidanceProvider.getDepartment("CLINICAL_FOLLOWUP_REQUIRED_11", lang);
        String rec = guidanceProvider.getRecommendation("CLINICAL_FOLLOWUP_REQUIRED_11", lang);
        String reason = guidanceProvider.getReason("CLINICAL_FOLLOWUP_REQUIRED_11", lang);
        String ruleMatched = "CLINICAL_FOLLOWUP_REQUIRED_11";
        double confidence = 0.60;
        String speech = speechService.generateSpokenResponse(urgency, department, rec, language);
        return new TriageResult(urgency, rec, department, reason, ruleMatched, confidence, speech);
    }

    private boolean hasSymptom(List<Symptom> list, String name) {
        for (Symptom s : list) {
            if (s.getName().equalsIgnoreCase(name) || s.getName().toLowerCase().contains(name.toLowerCase())) {
                return true;
            }
        }
        return false;
    }

    private boolean isRedFlagSymptom(String name, String fullText) {
        if ("Bone Fracture / Suspected Fracture".equals(name) || "Chest Pain".equals(name) || "Shortness of Breath".equals(name) ||
            "Stroke Warning Signs".equals(name) || "Blood in Stool or Vomit".equals(name)) {
            return true;
        }
        return fullText.contains("severe") || fullText.contains("unbearable") || fullText.contains("emergency")
            || fullText.contains("tivramaina") || fullText.contains("tivra") || fullText.contains("kadutta")
            || fullText.contains("intensa") || fullText.contains("forte") || fullText.contains("grave") || fullText.contains("schwer")
            || fullText.contains("తీవ్ర") || fullText.contains("ತೀವ್ರ") || fullText.contains("കടുത്ത")
            || fullText.contains("கடுமை") || fullText.contains("गंभीर")
            || fullText.contains("сильн") || fullText.contains("остр") || fullText.contains("激") || fullText.contains("ひどい")
            || fullText.contains("심한") || fullText.contains("รุนแรง") || fullText.contains("شديد") || fullText.contains("شدید")
            || fullText.contains("剧烈") || fullText.contains("তীব্র") || fullText.contains("तीव्र");
    }

    private String resolveBodyPart(String symptomName) {
        switch (symptomName) {
            case "Chest Pain":
            case "Shortness of Breath":
                return "Chest & Respiratory";
            case "Severe Headache":
            case "Stroke Warning Signs":
                return "Head & Neurological";
            case "Abdominal Pain":
            case "Vomiting / Diarrhea":
            case "Blood in Stool or Vomit":
                return "Abdomen & Digestive";
            case "Sprain / Joint Pain":
            case "Bone Fracture / Suspected Fracture":
            case "Fall / Physical Trauma":
            case "Knee & Lower Limb Injury":
                return "Musculoskeletal & Skeletal";
            case "Acute Pain & Internal Discomfort":
                return "Musculoskeletal / General";
            case "Cut or Bleeding":
            case "Burn":
                return "Skin & External";
            case "Menstrual Cramps / Dysmenorrhea":
            case "Irregular Menstrual Cycle":
                return "Reproductive & Pelvic";
            default:
                return "General Body";
        }
    }

    private int extractDurationInDays(String text) {
        Pattern pDays = Pattern.compile("(\\d+)\\s*(day|days|d|dias|giorni|tage|jours|roju|rojulu|dina|divasa|divasagalu|divasam|дней|дня|день|日|일|天|วัน|أيام|يوم|دن)");
        Matcher mDays = pDays.matcher(text);
        if (mDays.find()) {
            try { return Integer.parseInt(mDays.group(1)); } catch (Exception ignored) {}
        }

        Pattern pWeeks = Pattern.compile("(\\d+)\\s*(week|weeks|wk|semanas|settimane|wochen|semaines|vaaram|недели|недель|週間|주|周|สัปดาห์|أسابيع|ہفتے)");
        Matcher mWeeks = pWeeks.matcher(text);
        if (mWeeks.find()) {
            try { return Integer.parseInt(mWeeks.group(1)) * 7; } catch (Exception ignored) {}
        }

        if (text.contains("since yesterday") || text.contains("yesterday") || text.contains("ninna") || text.contains("ninne") || text.contains("ontem") || text.contains("ieri") || text.contains("ayer") || text.contains("hier") || text.contains("вчера") || text.contains("昨日") || text.contains("어제") || text.contains("昨天") || text.contains("أمس") || text.contains("کل")) return 1;
        if (text.contains("today") || text.contains("hours") || text.contains("just started") || text.contains("ee roju") || text.contains("ivathu") || text.contains("innum") || text.contains("hoje") || text.contains("oggi") || text.contains("hoy") || text.contains("сегодня") || text.contains("今日") || text.contains("오늘") || text.contains("今天") || text.contains("اليوم") || text.contains("آج")) return 0;

        return 1; // default 1 day
    }

    private String extractOverallSeverity(String text) {
        if (text.contains("severe") || text.contains("extreme") || text.contains("unbearable") || text.contains("worst") || text.contains("excruciating")
            || text.contains("tivramaina") || text.contains("tivra") || text.contains("kadutta") || text.contains("intensa") || text.contains("forte")
            || text.contains("grave") || text.contains("schwer") || text.contains("తీవ్ర") || text.contains("ತೀವ್ರ") || text.contains("കടുത്ത")
            || text.contains("கடுமை") || text.contains("गंभीर")
            || text.contains("сильн") || text.contains("остр") || text.contains("激") || text.contains("ひどい")
            || text.contains("심한") || text.contains("รุนแรง") || text.contains("شديد") || text.contains("شدید")
            || text.contains("剧烈") || text.contains("তীব্র") || text.contains("तीव्र")) {
            return "SEVERE";
        }
        if (text.contains("moderate") || text.contains("quite") || text.contains("persistent") || text.contains("bothering")
            || text.contains("madhyastha") || text.contains("moderado") || text.contains("moderato") || text.contains("modéré") || text.contains("mäßig")
            || text.contains("умеренн") || text.contains("中等") || text.contains("보통") || text.contains("ปานกลาง") || text.contains("متوسط") || text.contains("درمیانہ")) {
            return "MODERATE";
        }
        return "MILD";
    }
}
