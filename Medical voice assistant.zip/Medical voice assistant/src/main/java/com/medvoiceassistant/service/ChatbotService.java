package com.medvoiceassistant.service;

import com.medvoiceassistant.model.ChatMessage;
import com.medvoiceassistant.model.ChatSession;
import com.medvoiceassistant.model.UserProfile;
import com.medvoiceassistant.repository.ChatRepository;
import com.medvoiceassistant.util.DateTimeUtil;

import java.util.Optional;

public class ChatbotService {
    private final ChatRepository repository = new ChatRepository();
    private final FoodPlanService foodPlanService = new FoodPlanService();
    private final FirstAidService firstAidService = new FirstAidService();

    public static class ChatResponse {
        public String reply;
        public String intent;
        public boolean isEmergency;
        public Object extraData;

        public ChatResponse(String reply, String intent, boolean isEmergency, Object extraData) {
            this.reply = reply;
            this.intent = intent;
            this.isEmergency = isEmergency;
            this.extraData = extraData;
        }
    }

    public int getOrCreateSession(int userId, String language) {
        Optional<ChatSession> latest = repository.getLatestSessionForUser(userId);
        if (latest.isPresent()) {
            return latest.get().getChatId();
        }
        return repository.createSession(userId, language, DateTimeUtil.now());
    }

    public ChatResponse processUserMessage(int userId, int chatId, String message, String language, UserProfile profile) {
        String now = DateTimeUtil.now();
        String lower = (message != null) ? message.toLowerCase().trim() : "";
        String lang = (language != null && !language.isEmpty()) ? language.toLowerCase() : "en";
        if (lang.contains("-")) {
            lang = lang.substring(0, 2);
        }

        // 1. Detect Intent
        String intent = detectIntent(lower);
        boolean isEmergency = "EMERGENCY".equals(intent);

        // 2. Generate Reply
        String reply;
        Object extra = null;

        if (isEmergency) {
            if ("ta".equals(lang)) {
                reply = "🚨 அவசர எச்சரிக்கை: உங்கள் செய்தி உயிருக்கு ஆபத்தான கடுமையான அவசரநிலையைக் குறிக்கிறது. தயவுசெய்து உங்கள் திரையில் உள்ள சிகப்பு 'EMERGENCY SOS' பொத்தானை உடனே அழுத்தவும் அல்லது அவசர ஊர்திக்கு (108 / 112) உடனே அழைக்கவும்! தாமதிக்க வேண்டாம்.";
            } else if ("hi".equals(lang)) {
                reply = "🚨 आपातकालीन चेतावनी: आपका संदेश एक गंभीर, संभावित जीवन-धमकी वाली आपात स्थिति का संकेत देता है। कृपया तुरंत अपनी स्क्रीन पर लाल 'EMERGENCY SOS' बटन दबाएं या तुरंत 108 / 112 पर कॉल करें!";
            } else if ("te".equals(lang)) {
                reply = "🚨 అత్యవసర హెచ్చరిక: మీ సందేశం తీవ్రమైన, ప్రాణాపాయ అత్యవసర పరిస్థితిని సూచిస్తుంది. దయచేసి వెంటనే మీ స్క్రీన్‌పై ఉన్న ఎరుపు 'EMERGENCY SOS' బటన్‌ను నొక్కండి లేదా 108 / 112 కి వెంటనే కాల్ చేయండి!";
            } else {
                reply = "🚨 EMERGENCY ALERT: Your message indicates an acute, potentially life-threatening medical situation. Please activate the RED SOS BUTTON on your screen immediately or call Emergency Services (108 / 911 / 112) without delay! Do not wait for chat responses.";
            }

        } else if (lower.contains("period") || lower.contains("menstrual") || lower.contains("cramp") || lower.contains("dysmenorrhea")
            || lower.contains("pcos") || lower.contains("pcod") || lower.contains("மாதவிடாய்") || lower.contains("పీరియడ్") || lower.contains("माहवारी")) {
            intent = "WOMENS_HEALTH";
            reply = generateWomensHealthGuidance(lang);

        } else if (lower.contains("prescri") || lower.contains("adjust") || (lower.contains("medicat") && (lower.contains("review") || lower.contains("change") || lower.contains("stop")))) {
            intent = "MEDICATION_REVIEW";
            reply = generateMedicationReviewGuidance(lang);

        } else if ("FOOD_PLAN".equals(intent)) {
            var plan = foodPlanService.generatePlan(userId, message, profile, lang);
            extra = plan;
            reply = "🥗 **" + plan.getMealType().replace('_', ' ') + " Nutrition Plan** (Target: " + plan.getCaloriesTarget() + " kcal/day)\n\n" +
                plan.getPlanText() + "\n\n" +
                "💡 **Clinical Nutrition Note:**\n" + plan.getDietaryAdvice() + "\n\n" +
                "*(Tip: You can also view this full plan with audio narration in our 'Diet & Food Plans' tab.)*";

        } else if ("FIRST_AID".equals(intent)) {
            String scenario = resolveFirstAidScenario(lower);
            var guide = firstAidService.getGuideByScenario(scenario);
            if (guide.isPresent()) {
                extra = guide.get();
                reply = "📋 **" + guide.get().getTitle() + " Steps:**\n\n" + guide.get().getSteps() + "\n\n⚠️ **Red Flags:**\n" + guide.get().getRedFlags() +
                    "\n\n*(Tip: Switch to the 'First-Aid Guides' tab to view illustrated instructions or hear them spoken.)*";
            } else {
                reply = "For immediate first aid, please check our dedicated First Aid Guide tab for step-by-step guidance on cuts, burns, sprains, nosebleeds, and choking.";
            }

        } else if ("TRIAGE".equals(intent)) {
            reply = generateSymptomGuidance(lower, lang);

        } else if ("MEDICATION".equals(intent)) {
            reply = "💊 You can manage your active prescriptions and set automated spoken reminders in the 'Medications & Reminders' tab. Would you like to review your scheduled doses or set a new audio reminder?";

        } else {
            // General health Q&A
            reply = generateGeneralHealthAnswer(lower, profile, lang);
        }

        // 3. Save User message & Bot reply
        repository.saveMessage(new ChatMessage(0, chatId, "USER", message, intent, now));
        repository.saveMessage(new ChatMessage(0, chatId, "ASSISTANT", reply, intent, now));

        return new ChatResponse(reply, intent, isEmergency, extra);
    }

    private String detectIntent(String text) {
        // 1. Emergency
        if (text.contains("chest pain") || text.contains("can't breathe") || text.contains("cannot breathe") ||
            text.contains("stroke") || text.contains("unconscious") || text.contains("dying") || text.contains("emergency") ||
            text.contains("call 108") || text.contains("call 911") || text.contains("heart attack") || text.contains("choking")) {
            return "EMERGENCY";
        }

        // 2. Food & Nutrition (including underweight, weight gain, weight loss, bulking)
        if (text.contains("food") || text.contains("diet") || text.contains("breakfast") || text.contains("lunch") ||
            text.contains("dinner") || text.contains("meal") || text.contains("eat") || text.contains("nutrition") ||
            text.contains("calories") || text.contains("calorie") || text.contains("protein") || text.contains("underweight") ||
            text.contains("gain weight") || text.contains("weight gain") || text.contains("lose weight") || text.contains("weight loss") ||
            text.contains("fat loss") || text.contains("bulking") || text.contains("snack") || text.contains("recipe") ||
            text.contains("carb") || text.contains("fiber") || text.contains("iron rich") || text.contains("வजन") ||
            text.contains("எடை") || text.contains("బరువు")) {
            return "FOOD_PLAN";
        }

        // 3. First Aid
        if (text.contains("cut") || text.contains("burn") || text.contains("sprain") || text.contains("nosebleed") ||
            text.contains("first aid") || text.contains("ice pack") || text.contains("bandage") || text.contains("wound") ||
            text.contains("bleeding") || text.contains("bite") || text.contains("sting") || text.contains("fainting")) {
            return "FIRST_AID";
        }

        // 4. Symptoms / Triage
        if (text.contains("symptom") || text.contains("pain") || text.contains("cough") || text.contains("fever") ||
            text.contains("headache") || text.contains("triage") || text.contains("diagnose") || text.contains("knee") ||
            text.contains("leg") || text.contains("stomach") || text.contains("vomit") || text.contains("diarrhea") ||
            text.contains("loose motion") || text.contains("nausea") || text.contains("dizzy") || text.contains("vertigo") ||
            text.contains("rash") || text.contains("itch") || text.contains("throat") || text.contains("back") ||
            text.contains("joint") || text.contains("swelling") || text.contains("hurt") || text.contains("ache") ||
            text.contains("sick") || text.contains("cold") || text.contains("flu") || text.contains("infection")) {
            return "TRIAGE";
        }

        // 5. Medication
        if (text.contains("medicine") || text.contains("medication") || text.contains("tablet") || text.contains("pill") ||
            text.contains("dosage") || text.contains("reminder") || text.contains("prescription")) {
            return "MEDICATION";
        }

        return "GENERAL";
    }

    private String resolveFirstAidScenario(String text) {
        if (text.contains("burn") || text.contains("fire") || text.contains("hot water")) return "MINOR_BURN";
        if (text.contains("nose") || text.contains("nosebleed")) return "NOSEBLEED";
        if (text.contains("sprain") || text.contains("twisted") || text.contains("ankle")) return "SPRAIN";
        if (text.contains("chok") || text.contains("throat blocked")) return "CHOKING";
        if (text.contains("faint") || text.contains("dizzy") || text.contains("passed out")) return "FAINTING";
        if (text.contains("bee") || text.contains("sting") || text.contains("bite")) return "INSECT_BITE";
        return "MINOR_CUT";
    }

    private String generateWomensHealthGuidance(String lang) {
        if ("ta".equals(lang)) {
            return "🌸 **ஒழுங்கற்ற மாதவிடாய் மற்றும் கடுமையான வயிற்று வலி (Dysmenorrhea) மருத்துவ வழிகாட்டுதல்:**\n\n" +
                "1. **மருத்துவர் மேற்பார்வை:** ஹார்மோன் மாத்திரைகள் அல்லது வலி நிவாரணிகளை நீங்களாக மாற்றவோ நிறுத்தவோ கூடாது. அது ஹார்மோன் சமநிலையின்மையை ஏற்படுத்தும். மருத்துவரிடம் ஆலோசனை பெறவும்.\n" +
                "2. **வீட்டுப் பராமரிப்பு:** அடிவயிற்றில் வெந்நீர் ஒத்தடம் கொடுக்கவும் (20 நிமிடங்கள்). இஞ்சி-இலவங்கப்பட்டை டீ பருகவும் (கருப்பை சுருக்கத்தை தளர்த்தும்). பூசணி விதை, பாதாம், கீரை போன்ற மெக்னீசியம் மற்றும் இரும்புச்சத்து உணவுகளை சேர்க்கவும்.\n" +
                "3. **⚠️ உடனடி எச்சரிக்கை அறிகுறிகள்:** ஒரு மணி நேரத்திற்கு ஒரு பேடிற்கு மேல் நனையும் அளவுக்கு அதிக ரத்தப்போக்கு, மயக்கம் அல்லது தாங்க முடியாத ஒரு பக்க இடுப்பு வலி ஏற்பட்டால் உடனே அவசர மருத்துவ சிகிச்சை பெறவும்.";
        }
        return "🌸 **Clinical Guidance for Menstrual Health, Cramps & PCOS:**\n\n" +
            "1. **Prescription Review & Medication Adjustments:**\n" +
            "• **Physician Consultation Required:** Any adjustment to hormonal medications, progesterone, tranexamic acid, or NSAIDs **must only be done under the direct supervision of a licensed Gynecologist**. Self-altering dosages can trigger endocrine imbalances.\n" +
            "• **Investigating Root Causes:** Irregular cycles paired with severe dysmenorrhea often stem from PCOS (Polycystic Ovary Syndrome), thyroid abnormalities, or endometriosis. Pelvic ultrasound and hormonal panels (LH, FSH, TSH) are strongly advised.\n\n" +
            "2. **Safe Symptom Relief & Home Care:**\n" +
            "• **Heat Therapy:** Place a warm heating pad across your lower abdomen for 20 minutes to relax myometrial uterine contractions.\n" +
            "• **Anti-Inflammatory Nutrition:** Sip warm ginger-cinnamon tea (inhibits inflammatory prostaglandins). Consume magnesium-rich pumpkin seeds, almonds, and dark leafy greens.\n\n" +
            "3. **⚠️ Immediate Red Flag Symptoms:**\n" +
            "• Heavy hemorrhaging (soaking more than one pad per hour for 2+ consecutive hours).\n" +
            "• Sudden, excruciating sharp one-sided pelvic pain, extreme dizziness, or fainting.\n\n" +
            "💡 *Tip: You can also use our 'Voice Symptom Triage' module for automated clinical department routing and voice assessment.*";
    }

    private String generateMedicationReviewGuidance(String lang) {
        if ("ta".equals(lang)) {
            return "💊 **மருந்து மறுஆய்வு மற்றும் பாதுகாப்பு ஆலோசனை:**\n\n" +
                "• **மருத்துவர் அனுமதி இன்றி மருந்தின் அளவை மாற்றவோ, நிறுத்தவோ கூடாது.** அது ஆபத்தான பக்கவிளைவுகளை அல்லது நோயின் தீவிரத்தை அதிகரிக்கலாம்.\n" +
                "• நீங்கள் அனுபவிக்கும் பக்கவிளைவுகள் அல்லது மாற்றங்களை குறித்து வைத்து மருத்துவரிடம் ஆலோசிக்கவும்.\n" +
                "• உங்கள் தினசரி மருந்து நேரங்களை கண்காணிக்க எங்கள் 'Medications & Reminders' பகுதியில் நினைவூட்டல் அமைக்கலாம்.";
        }
        return "💊 **Prescription Review & Medication Safety Advisory:**\n\n" +
            "• **Doctor Supervision Mandatory:** Prescription medications (antibiotics, hormonal regulators, cardiovascular drugs, antihypertensives) **must never be increased, reduced, or stopped without consulting your prescribing physician**.\n" +
            "• **Safety Risks:** Independent dosage changes can cause dangerous rebound symptoms, drug resistance, or toxic accumulation.\n" +
            "• **Recommended Action:** Note down any side effects or current symptom changes and discuss them directly with your doctor. You can track your daily schedules and activate automated spoken reminders in our 'Medications & Reminders' tab.";
    }

    private String generateSymptomGuidance(String text, String lang) {
        // Knee & Joint Pain
        if (text.contains("knee") || text.contains("leg") || text.contains("joint") || text.contains("முட்டி") || text.contains("கால்") || text.contains("घुटना") || text.contains("మోకాలు")) {
            return "🦵 **Clinical Guidance for Knee & Joint Pain / Injury:**\n\n" +
                "• **R.I.C.E. Protocol:**\n" +
                "  1. **Rest:** Avoid putting full body weight on the affected joint.\n" +
                "  2. **Ice:** Apply an ice pack wrapped in a clean cloth for 15-20 minutes every 3-4 hours to reduce acute inflammation.\n" +
                "  3. **Compression:** Use a supportive elastic crepe bandage (not too tight) to minimize joint effusion.\n" +
                "  4. **Elevation:** Prop your leg up on pillows above heart level while resting.\n" +
                "• **⚠️ Urgent Red Flags:** Inability to bear any weight, visible joint deformity, a loud 'pop' sound accompanied by immediate severe swelling, or numbness/coldness in the foot. If present, consult an Orthopedic specialist promptly.\n\n" +
                "💡 *Tip: For automated clinical triage scoring and audio narration, use the 'Voice Symptom Triage' tab.*";
        }

        // Vomiting / Nausea / Diarrhea / Loose Motion / Food Poisoning
        if (text.contains("vomit") || text.contains("nausea") || text.contains("diarrhea") || text.contains("loose motion") || text.contains("food poisoning")
            || text.contains("வாந்தி") || text.contains("வயிற்றுப்போக்கு") || text.contains("उल्टी") || text.contains("दस्त") || text.contains("విరేచనాలు")) {
            return "💧 **Clinical Guidance for Vomiting, Diarrhea & Gastrointestinal Distress:**\n\n" +
                "• **Immediate Rehydration (Crucial):** Sip Oral Rehydration Salts (ORS) solution, tender coconut water, or diluted rice water in small, frequent sips (1-2 tablespoons every 10 minutes). Do not gulp large amounts at once.\n" +
                "• **Dietary Recovery (BRAT Diet):** Once vomiting has subsided for 4-6 hours, introduce gentle foods: Bananas, White Rice, Applesauce, and plain Toast. Avoid dairy, greasy foods, caffeine, and fruit juices.\n" +
                "• **⚠️ Emergency Red Flags:** Inability to retain any liquids for over 12 hours, extreme dizziness when standing up, blood in vomit or stools, or high fever (>102°F). Seek emergency medical evaluation immediately.";
        }

        // Sore Throat / Tonsils / Difficulty Swallowing
        if (text.contains("sore throat") || text.contains("throat") || text.contains("tonsil") || text.contains("swallow") || text.contains("தொண்டை") || text.contains("गले में दर्द") || text.contains("గొంతు నొప్పి")) {
            return "🧣 **Clinical Guidance for Sore Throat & Pharyngeal Irritation:**\n\n" +
                "• **Saltwater Gargles:** Gargle with warm water mixed with 1/2 tsp salt for 30 seconds, 3 to 4 times daily. This draws out inflammatory fluid and cleanses pathogens.\n" +
                "• **Warm Soothing Hydration:** Drink warm water with raw honey and ginger, or chamomile tea. Honey naturally coats and soothes inflamed mucosal linings.\n" +
                "• **⚠️ Red Flags:** Severe difficulty swallowing your own saliva, trouble opening your mouth (trismus), raspy 'hot potato' voice, or shortness of breath. These may signal a peritonsillar abscess or epiglottitis requiring urgent care.";
        }

        // Back Pain / Sciatica / Lumbar Strain
        if (text.contains("back") || text.contains("spine") || text.contains("lumbar") || text.contains("sciatica") || text.contains("இடுப்பு") || text.contains("முதுகு") || text.contains("पीठ दर्द") || text.contains("నడుము నొప్పి")) {
            return "🦴 **Clinical Guidance for Back Pain & Lumbar Strain:**\n\n" +
                "• **Active Rest:** Avoid prolonged bed rest, which can stiffen spinal musculature. Engage in gentle walking on flat surfaces.\n" +
                "• **Thermal Therapy:** Apply an ice pack for the first 48 hours to blunt acute muscle spasms; switch to warm compresses thereafter to promote blood flow.\n" +
                "• **Ergonomics:** Support your lumbar curve with a rolled towel when sitting; sleep on your side with a pillow between your knees.\n" +
                "• **⚠️ Emergency Red Flags:** Numbness in the groin/saddle area, loss of bowel or bladder control (Cauda Equina Syndrome), progressive weakness in your foot ('foot drop'), or fever with back pain. Seek ER care immediately if these occur.";
        }

        // Dizziness / Vertigo / Lightheadedness
        if (text.contains("dizzy") || text.contains("vertigo") || text.contains("lightheaded") || text.contains("faint") || text.contains("மயக்கம்") || text.contains("चक्कर") || text.contains("తలతిరగడం")) {
            return "🌀 **Clinical Guidance for Dizziness & Vertigo:**\n\n" +
                "• **Immediate Safety:** Sit or lie down immediately on a flat surface to eliminate fall risk. Keep your eyes focused on a stationary object.\n" +
                "• **Hydration & Blood Sugar:** Drink a glass of water with electrolytes and eat a small piece of fruit or biscuit in case mild hypoglycemia or dehydration is the culprit.\n" +
                "• **⚠️ Emergency Red Flags:** Sudden dizziness paired with slurred speech, facial drooping, one-sided arm weakness, double vision, or crushing chest pain (Stroke/Cardiac warning). Activate SOS or call 108 immediately.";
        }

        // Skin Rash / Hives / Itching / Allergy
        if (text.contains("rash") || text.contains("itch") || text.contains("hives") || text.contains("allergy") || text.contains("அரிப்பு") || text.contains("தடிப்பு") || text.contains("खुजली") || text.contains("దురద")) {
            return "🌿 **Clinical Guidance for Skin Rash & Allergic Itching:**\n\n" +
                "• **Cool Compress:** Apply a clean, cool damp cloth to the irritated area for 10-15 minutes to constrict superficial blood vessels and soothe histamine itch.\n" +
                "• **Gentle Skin Barrier:** Apply calamine lotion or pure aloe vera gel. Wear loose, breathable cotton clothing and avoid hot showers or perfumed soaps.\n" +
                "• **⚠️ Immediate Anaphylaxis Warning:** If the rash is accompanied by swelling of the lips, tongue, or throat, wheezing, or difficulty breathing, this is ANAPHYLAXIS. Activate Emergency SOS immediately!";
        }

        // Headache / Migraine
        if (text.contains("headache") || text.contains("migraine") || text.contains("தலைவலி") || text.contains("सिर दर्द") || text.contains("తలనొప్పి")) {
            return "🧠 **Clinical Guidance for Headache / Migraine:**\n\n" +
                "• **Immediate Self-Care:** Rest in a quiet, dark, well-ventilated room. Apply a cool compress to your forehead or temples and drink 500ml of water (dehydration is a primary trigger).\n" +
                "• **Relief:** Gentle neck stretches and over-the-counter paracetamol (if non-allergic and not contraindicated) can relieve tension headaches.\n" +
                "• **⚠️ Emergency Red Flags:** Sudden 'thunderclap' explosive headache, stiff neck with high fever, confusion, slurred speech, or vision loss. If present, seek immediate emergency care.\n\n" +
                "💡 *Tip: For a formal urgency triage score and spoken diagnosis, open the 'Voice Symptom Triage' tab!*";
        }

        // Fever / Temperature
        if (text.contains("fever") || text.contains("temperature") || text.contains("காய்ச்சல்") || text.contains("बुखार") || text.contains("జ్వరం")) {
            return "🌡️ **Clinical Guidance for Fever:**\n\n" +
                "• **Monitoring & Hydration:** Drink plenty of fluids (water, ORS, coconut water, clear broth) to prevent dehydration. Rest in lightweight cotton clothing in a well-ventilated room.\n" +
                "• **Cooling:** Lukewarm sponge baths along the forehead and neck help dissipate heat gently. Do not use icy cold water.\n" +
                "• **⚠️ Red Flags:** Body temperature exceeding 103°F (39.5°C), persistent fever lasting > 3 days, difficulty breathing, rash, stiff neck, or seizures.\n\n" +
                "💡 *Tip: Describe your symptoms in the 'Voice Symptom Triage' tab to get department routing!*";
        }

        // Cough / Cold
        if (text.contains("cough") || text.contains("cold") || text.contains("இருமல்") || text.contains("खांसी") || text.contains("దగ్గు")) {
            return "🫁 **Clinical Guidance for Cough & Respiratory Irritation:**\n\n" +
                "• **Soothe Airways:** Drink warm water with honey and ginger. Perform steam inhalation for 10 minutes twice daily and gargle with warm salt water for throat irritation.\n" +
                "• **Rest:** Elevate your head slightly while sleeping to reduce post-nasal drip.\n" +
                "• **⚠️ Red Flags:** Coughing up blood, wheezing, persistent chest tightness, shortness of breath, or fever lasting over 48 hours.\n\n" +
                "💡 *Tip: Click 'Voice Symptom Triage' to check if clinical department routing is advised.*";
        }

        // Abdominal / Stomach Discomfort
        if (text.contains("stomach") || text.contains("abdominal") || text.contains("belly") || text.contains("வயிறு") || text.contains("पेट") || text.contains("కడుపు")) {
            return "🩺 **Clinical Guidance for Abdominal Discomfort:**\n\n" +
                "• **Gut Rest:** Sip warm water, chamomile, or ginger tea. Eat bland, light foods like rice gruel, toast, or bananas. Avoid spicy, oily, dairy, or fried foods.\n" +
                "• **Support:** A warm heating pad on the abdomen can relieve muscular cramps.\n" +
                "• **⚠️ Red Flags:** Rigid/hard abdominal wall, blood in vomit or stools, persistent vomiting preventing hydration, or sharp acute pain localized to the lower right abdomen (appendicitis risk).\n\n" +
                "💡 *Tip: For full automated urgency classification, click the 'Voice Symptom Triage' tab!*";
        }

        return "🩺 **Clinical Symptom Assessment Advisory:**\n\n" +
            "• **Immediate Self-Care:** Ensure adequate rest in a comfortable position, hydrate with electrolyte-rich fluids, and avoid strenuous physical exertion.\n" +
            "• **Voice Symptom Triage:** For a full diagnostic evaluation with clinical urgency classification (Emergency, Moderate, or Self-Care) and hospital department routing, switch to our **Voice Symptom Triage** tab or use the microphone.\n" +
            "• **When to Seek Immediate Care:** Any sudden severe chest pressure, difficulty breathing, high fever with stiff neck, or sudden weakness requires emergency attention.";
    }

    private String generateGeneralHealthAnswer(String text, UserProfile profile, String lang) {
        if (text.contains("hello") || text.contains("hi") || text.contains("hey") || text.contains("வணக்கம்") || text.contains("नमस्ते") || text.contains("నమస్కారం")) {
            String name = (profile != null && profile.getName() != null) ? profile.getName() : "there";
            if ("ta".equals(lang)) {
                return "வணக்கம் " + name + "! நான் உங்கள் AI மருத்துவ குரல் உதவியாளர். உங்கள் அறிகுறிகளை விவரிக்கலாம், முதலுதவி வழிமுறைகள் கேட்கலாம், உணவு திட்டங்கள் பெறலாம், அல்லது மருந்து நினைவூட்டல்களை அமைக்கலாம். நான் உங்களுக்கு எப்படி உதவ முடியும்?";
            } else if ("hi".equals(lang)) {
                return "नमस्ते " + name + "! मैं आपकी AI मेडिकल वॉयस असिस्टेंट हूँ। आप अपने लक्षणों का वर्णन कर सकते हैं, प्राथमिक उपचार मार्गदर्शन मांग सकते हैं, स्वस्थ आहार योजना का अनुरोध कर सकते हैं या दवा अनुस्मारक सेट कर सकते हैं। आज मैं आपकी क्या सहायता कर सकती हूँ?";
            } else if ("te".equals(lang)) {
                return "నమస్కారం " + name + "! నేను మీ AI మెడికల్ వాయిస్ అసిస్టెంట్‌ని. మీరు మీ లక్షణాలను వివరించవచ్చు, ప్రథమ చికిత్స మార్గదర్శకత్వాన్ని అడగవచ్చు, ఆరోగ్యకరమైన ఆహార ప్రణాళికను పొందవచ్చు లేదా మందుల రిమైండర్‌లను సెట్ చేయవచ్చు. నేను మీకు ఎలా సహాయపడగలను?";
            }
            return "Hello " + name + "! I am your AI Medical Voice Assistant. You can describe your symptoms verbally, ask for first-aid guidance, request healthy food plans (for weight gain, fat loss, or condition care), or manage medication schedules. How can I assist you today?";
        }

        // Underweight / Weight Gain Q&A
        if (text.contains("underweight") || text.contains("gain weight") || text.contains("weight gain") || text.contains("bulking") || text.contains("increase weight")) {
            return "💪 **Clinical Guidelines for Healthy Weight Gain & Overcoming Underweight:**\n\n" +
                "• **Consistent Calorie Surplus:** Consume 400–500 kcal above your daily maintenance requirements with nutrient-dense, calorie-rich whole foods.\n" +
                "• **High-Quality Protein:** Target 1.6–2.0 grams of protein per kilogram of body weight (eggs, paneer, Greek yogurt, chicken breast, fish, lentils, tofu) to stimulate lean muscle hypertrophy.\n" +
                "• **Healthy Calorie Density:** Add healthy fats like natural peanut butter, organic cow's ghee, soaked nuts (almonds, walnuts, cashews), seeds (pumpkin, chia), and avocados into your meals.\n" +
                "• **Strength Training:** Exercise with progressive compound resistance training 3–4 days/week to direct excess calories into muscle rather than fat.\n\n" +
                "💡 *Tip: Head to our 'Diet & Food Plans' tab or type 'Generate food advice' to get an instant, personalized 6-meal daily plan!*";
        }

        // Weight Loss / Fat Loss
        if (text.contains("lose weight") || text.contains("weight loss") || text.contains("fat loss") || text.contains("slim")) {
            return "⚖️ **Clinical Guidelines for Healthy Weight Loss & Fat Reduction:**\n\n" +
                "• **Calorie Deficit:** Maintain a sustainable 400–500 kcal deficit per day to lose roughly 0.5 kg of body fat per week safely.\n" +
                "• **High Protein & Fiber:** Consume 1.4–1.6g protein/kg and 35g+ dietary fiber daily to stay full and preserve lean metabolic tissue.\n" +
                "• **Hydration & Sleep:** Drink 3 liters of water daily and sleep 7-8 hours; sleep deprivation elevates cortisol and ghrelin, driving cravings.\n\n" +
                "💡 *Tip: Generate a personalized low-calorie nutrition plan in the 'Diet & Food Plans' tab!*";
        }

        if (text.contains("water") || text.contains("hydration")) {
            return "💧 **Hydration Guidelines:** Adults should aim for 2.5 to 3.5 liters (about 8-10 glasses) of clean water daily. Proper hydration supports cardiovascular volume, renal filtration, cognitive focus, and digestive motility.";
        }

        if (text.contains("blood pressure") || text.contains("bp") || text.contains("hypertension")) {
            return "❤️ **Blood Pressure Health:** Optimal adult blood pressure is below 120/80 mmHg. Hypertension (≥130/80 mmHg) increases cardiac workload. Limit dietary sodium to under 1,500mg daily, eat potassium-rich foods (bananas, coconut water, spinach), and maintain regular aerobic exercise.";
        }

        if (text.contains("cholesterol") || text.contains("triglyceride")) {
            return "🫀 **Lipid & Cholesterol Management:** Keep LDL cholesterol low and HDL protective. Incorporate soluble fiber (oats, barley, apples), Omega-3 fatty acids (flaxseed, walnuts, fish), and eliminate artificial trans fats and hydrogenated oils.";
        }

        if (text.contains("sleep") || text.contains("insomnia")) {
            return "🌙 **Restorative Sleep Hygiene:** Aim for 7-9 hours of nightly sleep. Maintain a consistent sleep schedule, eliminate blue screens 60 minutes before bed, keep the bedroom cool (65-68°F / 18-20°C), and avoid heavy meals or caffeine within 4 hours of bedtime.";
        }

        if (text.contains("bmi") || text.contains("body mass index")) {
            if (profile != null && profile.getBmi() > 0) {
                return "📊 Your registered BMI is **" + profile.getBmi() + "** (" + profile.getBmiCategory() + "). Normal healthy BMI range is 18.5 to 24.9. Balanced nutrition and 150 minutes of weekly activity will keep your metrics in peak health.";
            }
            return "📊 Body Mass Index (BMI) evaluates weight relative to height: Underweight (<18.5), Normal (18.5–24.9), Overweight (25–29.9), and Obese (≥30). You can check your personalized BMI status in the top bar.";
        }

        if (text.contains("anxiety") || text.contains("stress") || text.contains("panic")) {
            return "🧘 **Stress & Anxiety Relief:**\n\n" +
                "• **4-7-8 Breathing Technique:** Inhale quietly through your nose for 4 seconds, hold your breath for 7 seconds, and exhale completely through your mouth for 8 seconds. Repeat 4 times to activate your parasympathetic nervous system.\n" +
                "• **Grounding Exercise (5-4-3-2-1):** Acknowledge 5 things you see, 4 you can touch, 3 you hear, 2 you smell, and 1 you taste.\n" +
                "• If you experience severe panic accompanied by chest pressure or shortness of breath, please rule out cardiac issues or seek professional care.";
        }

        return "I am here to assist with symptom triage, clinical food plans, first-aid emergencies, medication reminders, and general health inquiries. For personalized clinical assessments, feel free to use the microphone or describe your symptoms in detail!";
    }
}
