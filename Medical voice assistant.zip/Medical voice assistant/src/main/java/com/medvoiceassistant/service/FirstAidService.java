package com.medvoiceassistant.service;

import com.medvoiceassistant.model.FirstAidGuide;
import com.medvoiceassistant.repository.FirstAidRepository;

import java.util.List;
import java.util.Optional;

public class FirstAidService {
    private final FirstAidRepository repository = new FirstAidRepository();

    public List<FirstAidGuide> getAllGuides() {
        return repository.getAllGuides();
    }

    public Optional<FirstAidGuide> getGuideByScenario(String scenario) {
        return repository.getByScenario(scenario);
    }
}
