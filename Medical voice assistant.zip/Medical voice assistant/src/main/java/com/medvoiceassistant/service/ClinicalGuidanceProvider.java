package com.medvoiceassistant.service;

import java.util.HashMap;
import java.util.Map;

/**
 * Provides comprehensive clinical department routing, actionable guidance,
 * triage reasoning, and extracted symptom names localized across all 20 supported languages.
 */
public class ClinicalGuidanceProvider {

    public String getDepartment(String ruleId, String language) {
        String lang = normalizeLang(language);
        switch (ruleId) {
            case "CARDIAC_EMERGENCY_PROTOCOL_01":
                switch (lang) {
                    case "te": return "కార్డియాలజీ మరియు అత్యవసర వైద్య విభాగం (Cardiology & Emergency)";
                    case "kn": return "ಕಾರ್ಡಿಯಾಲಜಿ ಮತ್ತು ತುರ್ತು ವೈದ್ಯಕೀಯ ವಿಭಾಗ (Cardiology & Emergency)";
                    case "hi": return "हृदय रोग एवं आपातकालीन चिकित्सा विभाग (Cardiology & Emergency)";
                    case "ta": return "இதயவியல் மற்றும் அவசர சிகிச்சை பிரிவு (Cardiology & Emergency)";
                    case "ml": return "കാർഡിയോളജി & എമർജൻസി മെഡിസിൻ (Cardiology & Emergency)";
                    case "bn": return "কার্ডিওলজি ও জরুরি চিকিৎসা বিভাগ (Cardiology & Emergency)";
                    case "mr": return "हृदयरोग आणि आपत्कालीन विभाग (Cardiology & Emergency)";
                    case "ur": return "امراض قلب اور ایمرجنسی میڈیسن (Cardiology & Emergency)";
                    case "ar": return "قسم أمراض القلب وطب الطوارئ (Cardiology & Emergency)";
                    case "ru": return "Кардиология и неотложная медицинская помощь (Cardiology & Emergency)";
                    case "ja": return "循環器内科・救急救命科 (Cardiology & Emergency)";
                    case "ko": return "순환기내과 및 응급의학과 (Cardiology & Emergency)";
                    case "zh": return "心血管内科与急诊医学科 (Cardiology & Emergency)";
                    case "th": return "แผนกโรคหัวใจและเวชศาสตร์ฉุกเฉิน (Cardiology & Emergency)";
                    case "es": return "Cardiología y Medicina de Emergencia (Cardiology & Emergency)";
                    case "pt": return "Cardiologia e Medicina de Emergência (Cardiology & Emergency)";
                    case "fr": return "Cardiologie et Médecine d'Urgence (Cardiology & Emergency)";
                    case "de": return "Kardiologie und Notfallmedizin (Cardiology & Emergency)";
                    case "it": return "Cardiologia e Medicina d'Urgenza (Cardiology & Emergency)";
                    default: return "Cardiology & Emergency Medicine";
                }

            case "NEURO_FAST_EMERGENCY_02":
                switch (lang) {
                    case "te": return "న్యూరాలజీ మరియు అత్యవసర విభాగం (Neurology & Emergency)";
                    case "kn": return "ನ್ಯೂರಾಲಜಿ ಮತ್ತು ತುರ್ತು ವಿಭಾಗ (Neurology & Emergency)";
                    case "hi": return "न्यूरोलॉजी एवं आपातकालीन चिकित्सा (Neurology & Emergency)";
                    case "ta": return "நரம்பியல் மற்றும் அவசர சிகிச்சை (Neurology & Emergency)";
                    case "ml": return "ന്യൂറോളജി & അത്യാഹിത വിഭാഗം (Neurology & Emergency)";
                    case "bn": return "নিউরোলজি ও জরুরি বিভাগ (Neurology & Emergency)";
                    case "mr": return "न्यूरोलॉजी आणि आपत्कालीन विभाग (Neurology & Emergency)";
                    case "ur": return "نیورولوجی اور ایمرجنسی میڈیسن (Neurology & Emergency)";
                    case "ar": return "قسم طب الأعصاب والطوارئ (Neurology & Emergency)";
                    case "ru": return "Неврология и неотложная помощь (Neurology & Emergency)";
                    case "ja": return "脳神経外科・救急科 (Neurology & Emergency)";
                    case "ko": return "신경과 및 응급의학과 (Neurology & Emergency)";
                    case "zh": return "神经内科与急诊医学科 (Neurology & Emergency)";
                    case "th": return "แผนกประสาทวิทยาและฉุกเฉิน (Neurology & Emergency)";
                    case "es": return "Neurología y Medicina de Emergencia (Neurology & Emergency)";
                    case "pt": return "Neurologia e Medicina de Emergência (Neurology & Emergency)";
                    case "fr": return "Neurologie et Médecine d'Urgence (Neurology & Emergency)";
                    case "de": return "Neurologie und Notfallmedizin (Neurology & Emergency)";
                    case "it": return "Neurologia e Medicina d'Urgenza (Neurology & Emergency)";
                    default: return "Neurology & Emergency Medicine";
                }

            case "GI_BLEED_ACUTE_ABDOMEN_03":
                switch (lang) {
                    case "te": return "గ్యాస్ట్రోఎంటరాలజీ మరియు అత్యవసర విభాగం (Gastroenterology & Emergency)";
                    case "kn": return "ಗ್ಯಾಸ್ಟ್ರೋಎಂಟರಾಲಜಿ ಮತ್ತು ತುರ್ತು ವಿಭಾಗ (Gastroenterology & Emergency)";
                    case "hi": return "गैस्ट्रोएंटरोलॉजी एवं आपातकालीन चिकित्सा (Gastroenterology & Emergency)";
                    case "ta": return "இரைப்பைக் குடலியல் மற்றும் அவசர சிகிச்சை (Gastroenterology & Emergency)";
                    case "ml": return "ഗ്യാസ്ട്രോഎൻട്രോളജി & അത്യാഹിത വിഭാഗം (Gastroenterology & Emergency)";
                    case "bn": return "গ্যাস্ট্রোএন্টারোলজি ও জরুরি বিভাগ (Gastroenterology & Emergency)";
                    case "mr": return "गॅस्ट्रोएन्टेरोलॉजी आणि आपत्कालीन विभाग (Gastroenterology & Emergency)";
                    case "ur": return "گیسٹرو اینٹرولوجی اور ایمرجنسی (Gastroenterology & Emergency)";
                    case "ar": return "أمراض الجهاز الهضمي وطب الطوارئ (Gastroenterology & Emergency)";
                    case "ru": return "Гастроэнтерология и неотложная помощь (Gastroenterology & Emergency)";
                    case "ja": return "消化器内科・救急科 (Gastroenterology & Emergency)";
                    case "ko": return "소화기내과 및 응급의학과 (Gastroenterology & Emergency)";
                    case "zh": return "消化内科与急诊医学科 (Gastroenterology & Emergency)";
                    case "th": return "แผนกระบบทางเดินอาหารและฉุกเฉิน (Gastroenterology & Emergency)";
                    case "es": return "Gastroenterología y Medicina de Emergencia (Gastroenterology & Emergency)";
                    case "pt": return "Gastroenterologia e Medicina de Emergência (Gastroenterology & Emergency)";
                    case "fr": return "Gastro-entérologie et Médecine d'Urgence (Gastroenterology & Emergency)";
                    case "de": return "Gastroenterologie und Notfallmedizin (Gastroenterology & Emergency)";
                    case "it": return "Gastroenterologia e Medicina d'Urgenza (Gastroenterology & Emergency)";
                    default: return "Gastroenterology & Emergency Medicine";
                }

            case "ANAPHYLAXIS_EMERGENCY_04":
                switch (lang) {
                    case "te": return "అత్యవసర విభాగం మరియు అలర్జీ కేర్ (Emergency Medicine / Allergy)";
                    case "kn": return "ತುರ್ತು ವಿಭಾಗ ಮತ್ತು ಅಲರ್ಜಿ ಚಿಕಿತ್ಸೆ (Emergency Medicine / Allergy)";
                    case "hi": return "आपातकालीन चिकित्सा एवं एलर्जी विभाग (Emergency Medicine / Allergy)";
                    case "ta": return "அவசர சிகிச்சை மற்றும் ஒவ்வாமை பிரிவு (Emergency Medicine / Allergy)";
                    case "ml": return "അത്യാഹിത വിഭാഗം & അലർജി കെയർ (Emergency Medicine / Allergy)";
                    case "bn": return "জরুরি ও অ্যালার্জি বিভাগ (Emergency Medicine / Allergy)";
                    case "mr": return "आपत्कालीन आणि ऍलर्जी विभाग (Emergency Medicine / Allergy)";
                    case "ur": return "ایمرجنسی میڈیسن اور الرجولوجی (Emergency Medicine / Allergy)";
                    case "ar": return "طب الطوارئ وأمراض الحساسية (Emergency Medicine / Allergy)";
                    case "ru": return "Неотложная помощь и аллергология (Emergency Medicine / Allergy)";
                    case "ja": return "救急救命科・アレルギー科 (Emergency Medicine / Allergy)";
                    case "ko": return "응급의학과 및 알레르기내과 (Emergency Medicine / Allergy)";
                    case "zh": return "急诊医学与变态反应变应科 (Emergency Medicine / Allergy)";
                    case "th": return "เวชศาสตร์ฉุกเฉินและโรคภูมิแพ้ (Emergency Medicine / Allergy)";
                    case "es": return "Medicina de Emergencia / Alergología (Emergency Medicine / Allergy)";
                    case "pt": return "Medicina de Emergência / Alergologia (Emergency Medicine / Allergy)";
                    case "fr": return "Médecine d'Urgence et Allergologie (Emergency Medicine / Allergy)";
                    case "de": return "Notfallmedizin und Allergologie (Emergency Medicine / Allergy)";
                    case "it": return "Medicina d'Urgenza e Allergologia (Emergency Medicine / Allergy)";
                    default: return "Emergency Medicine / Allergy";
                }

            case "ORTHOPEDIC_FRACTURE_TRAUMA_07":
                switch (lang) {
                    case "te": return "ఆర్థోపెడిక్స్ మరియు ట్రామా కేర్ విభాగం (Orthopedics & Trauma Care)";
                    case "kn": return "ಆರ್ಥೋಪೆಡಿಕ್ಸ್ ಮತ್ತು ಟ್ರಾಮಾ ಕೇರ್ ವಿಭಾಗ (Orthopedics & Trauma Care)";
                    case "hi": return "अस्थि रोग एवं ट्रॉमा केयर विभाग (Orthopedics & Trauma Care)";
                    case "ta": return "எலும்பியல் மற்றும் அதிர்ச்சி சிகிச்சை பிரிவு (Orthopedics & Trauma Care)";
                    case "ml": return "ഓർത്തോപീഡിക്സ് & ട്രോമ കെയർ വിഭാഗം (Orthopedics & Trauma Care)";
                    case "bn": return "অর্থোপেডিকস ও ট্রমা কেয়ার বিভাগ (Orthopedics & Trauma Care)";
                    case "mr": return "अस्थिव्यंग आणि ट्रॉमा केअर विभाग (Orthopedics & Trauma Care)";
                    case "ur": return "آرتھوپیڈکس اور ٹراما کیئر ڈیپارٹمنٹ (Orthopedics & Trauma Care)";
                    case "ar": return "قسم جراحة العظام ورعاية الإصابات (Orthopedics & Trauma Care)";
                    case "ru": return "Отделение ортопедии и травматологии (Orthopedics & Trauma Care)";
                    case "ja": return "整形外科・外傷救急科 (Orthopedics & Trauma Care)";
                    case "ko": return "정형외과 및 외상 치료과 (Orthopedics & Trauma Care)";
                    case "zh": return "骨科与创伤护理中心 (Orthopedics & Trauma Care)";
                    case "th": return "แผนกศัลยกรรมกระดูกและอุบัติเหตุ (Orthopedics & Trauma Care)";
                    case "es": return "Departamento de Ortopedia y Traumatología (Orthopedics & Trauma Care)";
                    case "pt": return "Ortopedia e Atendimento ao Trauma (Orthopedics & Trauma Care)";
                    case "fr": return "Service d'Orthopédie et Traumatologie (Orthopedics & Trauma Care)";
                    case "de": return "Orthopädie und Unfallchirurgie (Orthopedics & Trauma Care)";
                    case "it": return "Reparto di Ortopedia e Traumatologia (Orthopedics & Trauma Care)";
                    default: return "Orthopedics & Trauma Care";
                }

            case "RESPIRATORY_INFECTION_MODERATE_05":
                switch (lang) {
                    case "te": return "పల్మోనాలజీ మరియు జనరల్ మెడిసిన్ (Pulmonology & General Medicine)";
                    case "kn": return "ಪಲ್ಮನಾಲಜಿ ಮತ್ತು ಜನರಲ್ ಮೆಡಿಸಿನ್ (Pulmonology & General Medicine)";
                    case "hi": return "श्वसन रोग एवं सामान्य चिकित्सा (Pulmonology & General Medicine)";
                    case "ta": return "நுரையீரலியல் மற்றும் பொது மருத்துவம் (Pulmonology & General Medicine)";
                    case "ml": return "പൾമണോളജി & ജനറൽ മെഡിസിൻ (Pulmonology & General Medicine)";
                    case "bn": return "পালমোনোলজি ও সাধারণ চিকিৎসা (Pulmonology & General Medicine)";
                    case "mr": return "श्वसनरोग आणि सामान्य वैद्यकीय विभाग (Pulmonology & General Medicine)";
                    case "ur": return "پلمونولوجی اور جنرل میڈیسن (Pulmonology & General Medicine)";
                    case "ar": return "أمراض الرئة والطب العام (Pulmonology & General Medicine)";
                    case "ru": return "Пульмонология и общая терапия (Pulmonology & General Medicine)";
                    case "ja": return "呼吸器内科・総合診療科 (Pulmonology & General Medicine)";
                    case "ko": return "호흡기내과 및 일반의학과 (Pulmonology & General Medicine)";
                    case "zh": return "呼吸内科与全科医学 (Pulmonology & General Medicine)";
                    case "th": return "แผนกโรคปอดและอายุรกรรมทั่วไป (Pulmonology & General Medicine)";
                    case "es": return "Neumología y Medicina General (Pulmonology & General Medicine)";
                    case "pt": return "Pneumologia e Medicina Geral (Pulmonology & General Medicine)";
                    case "fr": return "Pneumologie et Médecine Générale (Pulmonology & General Medicine)";
                    case "de": return "Pneumologie und Allgemeinmedizin (Pulmonology & General Medicine)";
                    case "it": return "Pneumologia e Medicina Generale (Pulmonology & General Medicine)";
                    default: return "Pulmonology & General Medicine";
                }

            case "GI_DISTRESS_MODERATE_06":
                switch (lang) {
                    case "te": return "గ్యాస్ట్రోఎంటరాలజీ విభాగం (Gastroenterology)";
                    case "kn": return "ಗ್ಯಾಸ್ಟ್ರೋಎಂಟರಾಲಜಿ ವಿಭಾಗ (Gastroenterology)";
                    case "hi": return "गैस्ट्रोएंटरोलॉजी विभाग (Gastroenterology)";
                    case "ta": return "இரைப்பைக் குடலியல் பிரிவு (Gastroenterology)";
                    case "ml": return "ഗ്യാസ്ട്രോഎൻട്രോളജി വിഭാഗം (Gastroenterology)";
                    case "bn": return "গ্যাস্ট্রোএন্টারোলজি বিভাগ (Gastroenterology)";
                    case "mr": return "गॅस्ट्रोएन्टेरोलॉजी विभाग (Gastroenterology)";
                    case "ur": return "گیسٹرو اینٹرولوجی ڈویژن (Gastroenterology)";
                    case "ar": return "قسم أمراض الجهاز الهضمي (Gastroenterology)";
                    case "ru": return "Отделение гастроэнтерологии (Gastroenterology)";
                    case "ja": return "消化器内科 (Gastroenterology)";
                    case "ko": return "소화기내과 (Gastroenterology)";
                    case "zh": return "消化内科专科 (Gastroenterology)";
                    case "th": return "แผนกระบบทางเดินอาหาร (Gastroenterology)";
                    case "es": return "Servicio de Gastroenterología (Gastroenterology)";
                    case "pt": return "Serviço de Gastroenterologia (Gastroenterology)";
                    case "fr": return "Service de Gastro-entérologie (Gastroenterology)";
                    case "de": return "Fachbereich Gastroenterologie (Gastroenterology)";
                    case "it": return "Reparto di Gastroenterologia (Gastroenterology)";
                    default: return "Gastroenterology / Internal Medicine";
                }

            case "ORTHO_SPRAIN_MODERATE_07":
                switch (lang) {
                    case "te": return "ఆర్థోపెడిక్స్ విభాగం (Orthopedics)";
                    case "kn": return "ಆರ್ಥೋಪೆಡಿಕ್ಸ್ ವಿಭಾಗ (Orthopedics)";
                    case "hi": return "अस्थि रोग विभाग (Orthopedics)";
                    case "ta": return "எலும்பியல் பிரிவு (Orthopedics)";
                    case "ml": return "ഓർത്തോപീഡിക്സ് വിഭാഗം (Orthopedics)";
                    case "bn": return "অর্থোপেডিক বিভাগ (Orthopedics)";
                    case "mr": return "अस्थिव्यंग विभाग (Orthopedics)";
                    case "ur": return "شعبہ آرتھوپیڈکس (Orthopedics)";
                    case "ar": return "قسم جراحة العظام (Orthopedics)";
                    case "ru": return "Ортопедическое отделение (Orthopedics)";
                    case "ja": return "整形外科 (Orthopedics)";
                    case "ko": return "정형외과 (Orthopedics)";
                    case "zh": return "骨科专科 (Orthopedics)";
                    case "th": return "แผนกศัลยกรรมกระดูก (Orthopedics)";
                    case "es": return "Servicio de Ortopedia (Orthopedics)";
                    case "pt": return "Serviço de Ortopedia (Orthopedics)";
                    case "fr": return "Service d'Orthopédie (Orthopedics)";
                    case "de": return "Fachbereich Orthopädie (Orthopedics)";
                    case "it": return "Reparto di Ortopedia (Orthopedics)";
                    default: return "Orthopedics";
                }

            case "VIRAL_UPPER_RESPIRATORY_SELFCARE_08":
                switch (lang) {
                    case "te": return "జనరల్ మెడిసిన్ & హోమ్ కేర్ (General Medicine)";
                    case "kn": return "ಜನರಲ್ ಮೆಡಿಸಿನ್ ಮತ್ತು ಮನೆ ಆರೈಕೆ (General Medicine)";
                    case "hi": return "सामान्य चिकित्सा एवं घरेलू देखभाल (General Medicine)";
                    case "ta": return "பொது மருத்துவம் மற்றும் வீட்டுப் பராமரிப்பு (General Medicine)";
                    case "ml": return "ജനറൽ മെഡിസിൻ & ഹോം കെയർ (General Medicine)";
                    case "bn": return "সাধারণ চিকিৎসা ও পারিবারিক যত্ন (General Medicine)";
                    case "mr": return "सामान्य वैद्यकीय आणि घरगुती काळजी (General Medicine)";
                    case "ur": return "جنرل میڈیسن اور گھریلو نگہداشت (General Medicine)";
                    case "ar": return "الطب العام والرعاية المنزلية (General Medicine)";
                    case "ru": return "Общая терапия и домашний уход (General Medicine)";
                    case "ja": return "総合診療科・在宅セルフケア (General Medicine)";
                    case "ko": return "일반의학과 및 재택 자가 치료 (General Medicine)";
                    case "zh": return "全科医学与居家调理 (General Medicine)";
                    case "th": return "อายุรกรรมทั่วไปและการดูแลตนเองที่บ้าน (General Medicine)";
                    case "es": return "Medicina General / Atención Primaria (General Medicine)";
                    case "pt": return "Medicina Geral / Cuidados Domiciliares (General Medicine)";
                    case "fr": return "Médecine Générale et Soins à Domicile (General Medicine)";
                    case "de": return "Allgemeinmedizin und häusliche Pflege (General Medicine)";
                    case "it": return "Medicina Generale e Cure Domiciliari (General Medicine)";
                    default: return "General Medicine / Primary Care";
                }

            case "MINOR_WOUND_SELFCARE_09":
                switch (lang) {
                    case "te": return "డెర్మటాలజీ & ప్రథమ చికిత్స (Dermatology / First Aid)";
                    case "kn": return "ಡರ್ಮಟಾಲಜಿ ಮತ್ತು ಪ್ರಥಮ ಚಿಕಿತ್ಸೆ (Dermatology / First Aid)";
                    case "hi": return "त्वचा रोग एवं प्राथमिक चिकित्सा (Dermatology / First Aid)";
                    case "ta": return "தோல் மருத்துவம் மற்றும் முதலுதவி (Dermatology / First Aid)";
                    case "ml": return "ഡെർമറ്റോളജി & പ്രഥമശുശ്രൂഷ (Dermatology / First Aid)";
                    case "bn": return "চর্মরোগ ও প্রাথমিক চিকিৎসা (Dermatology / First Aid)";
                    case "mr": return "त्वचारोग आणि प्रथमोपचार (Dermatology / First Aid)";
                    case "ur": return "جلد کی نگہداشت اور ابتدائی طبی امداد (Dermatology / First Aid)";
                    case "ar": return "الأمراض الجلدية والإسعافات الأولية (Dermatology / First Aid)";
                    case "ru": return "Дерматология и первая помощь (Dermatology / First Aid)";
                    case "ja": return "皮膚科・応急手当 (Dermatology / First Aid)";
                    case "ko": return "피부과 및 응급처치 (Dermatology / First Aid)";
                    case "zh": return "皮肤科与急救护理 (Dermatology / First Aid)";
                    case "th": return "แผนกผิวหนังและการปฐมพยาบาล (Dermatology / First Aid)";
                    case "es": return "Dermatología y Primeros Auxilios (Dermatology / First Aid)";
                    case "pt": return "Dermatologia e Primeiros Socorros (Dermatology / First Aid)";
                    case "fr": return "Dermatologie et Premiers Secours (Dermatology / First Aid)";
                    case "de": return "Dermatologie und Erste Hilfe (Dermatology / First Aid)";
                    case "it": return "Dermatologia e Primo Soccorso (Dermatology / First Aid)";
                    default: return "Dermatology / First Aid";
                }

            case "SYNCOPE_DIZZINESS_PROTOCOL_10":
                switch (lang) {
                    case "te": return "న్యూరాలజీ మరియు కార్డియాలజీ (Neurology & Cardiology)";
                    case "kn": return "ನ್ಯೂರಾಲಜಿ ಮತ್ತು ಕಾರ್ಡಿಯಾಲಜಿ (Neurology & Cardiology)";
                    case "hi": return "न्यूरोलॉजी एवं कार्डियोलॉजी (Neurology & Cardiology)";
                    case "ta": return "நரம்பியல் மற்றும் இதயவியல் (Neurology & Cardiology)";
                    case "ml": return "ന്യൂറോളജി & കാർഡിയോളജി (Neurology & Cardiology)";
                    case "bn": return "নিউরোলজি ও কার্ডিওলজি (Neurology & Cardiology)";
                    case "mr": return "न्यूरोलॉजी आणि कार्डिओलॉजी (Neurology & Cardiology)";
                    case "ur": return "نیورولوجی اور کارڈیالوجی (Neurology & Cardiology)";
                    case "ar": return "طب الأعصاب وأمراض القلب (Neurology & Cardiology)";
                    case "ru": return "Неврология и кардиология (Neurology & Cardiology)";
                    case "ja": return "神経内科・循環器内科 (Neurology & Cardiology)";
                    case "ko": return "신경과 및 순환기내과 (Neurology & Cardiology)";
                    case "zh": return "神经内科与心内科 (Neurology & Cardiology)";
                    case "th": return "แผนกประสาทวิทยาและโรคหัวใจ (Neurology & Cardiology)";
                    case "es": return "Neurología y Cardiología (Neurology & Cardiology)";
                    case "pt": return "Neurologia e Cardiologia (Neurology & Cardiology)";
                    case "fr": return "Neurologie et Cardiologie (Neurology & Cardiology)";
                    case "de": return "Neurologie und Kardiologie (Neurology & Cardiology)";
                    case "it": return "Neurologia e Cardiologia (Neurology & Cardiology)";
                    default: return "Neurology & Cardiology";
                }

            case "GYNECOLOGY_MENSTRUAL_HEALTH_12":
                switch (lang) {
                    case "te": return "గైనకాలజీ మరియు స్త్రీ ఆరోగ్య విభాగం (Gynecology & Women's Health)";
                    case "kn": return "ಸ್ತ್ರೀರೋಗ ಮತ್ತು ಮಹಿಳಾ ಆರೋಗ್ಯ ವಿಭಾಗ (Gynecology & Women's Health)";
                    case "hi": return "स्त्री रोग एवं महिला स्वास्थ्य विभाग (Gynecology & Women's Health)";
                    case "ta": return "மகளிர் நலம் மற்றும் பெண்ணோயியல் பிரிவு (Gynecology & Women's Health)";
                    case "ml": return "ഗൈനക്കോളജി & സ്ത്രീകളുടെ ആരോഗ്യ വിഭാഗം (Gynecology & Women's Health)";
                    case "bn": return "স্ত্রীরোগ ও মহিলা স্বাস্থ্য বিভাগ (Gynecology & Women's Health)";
                    case "mr": return "स्त्रीरोग आणि महिला आरोग्य विभाग (Gynecology & Women's Health)";
                    case "ur": return "امراض نسواں اور خواتین کی صحت (Gynecology & Women's Health)";
                    case "ar": return "قسم أمراض النساء وتوليد وصحة المرأة (Gynecology & Women's Health)";
                    case "ru": return "Гинекология и женское здоровье (Gynecology & Women's Health)";
                    case "ja": return "産婦人科・女性外来 (Gynecology & Women's Health)";
                    case "ko": return "산부인과 및 여성 건강 센터 (Gynecology & Women's Health)";
                    case "zh": return "妇科与女性健康专科 (Gynecology & Women's Health)";
                    case "th": return "แผนกสูตินรีเวชและสุขภาพสตรี (Gynecology & Women's Health)";
                    case "es": return "Ginecología y Salud de la Mujer (Gynecology & Women's Health)";
                    case "pt": return "Ginecologia e Saúde da Mulher (Gynecology & Women's Health)";
                    case "fr": return "Gynécologie et Santé des Femmes (Gynecology & Women's Health)";
                    case "de": return "Gynäkologie und Frauengesundheit (Gynecology & Women's Health)";
                    case "it": return "Ginecologia e Salute della Donna (Gynecology & Women's Health)";
                    default: return "Gynecology & Women's Health";
                }

            case "CLINICAL_FOLLOWUP_REQUIRED_11":
            default:
                switch (lang) {
                    case "te": return "జనరల్ మెడిసిన్ (General Medicine)";
                    case "kn": return "ಜನರಲ್ ಮೆಡಿಸಿನ್ (General Medicine)";
                    case "hi": return "सामान्य चिकित्सा विभाग (General Medicine)";
                    case "ta": return "பொது மருத்துவம் (General Medicine)";
                    case "ml": return "ജനറൽ മെഡിസിൻ (General Medicine)";
                    case "bn": return "সাধারণ চিকিৎসা (General Medicine)";
                    case "mr": return "सामान्य वैद्यकीय विभाग (General Medicine)";
                    case "ur": return "جنرل میڈیسن (General Medicine)";
                    case "ar": return "قسم الطب العام (General Medicine)";
                    case "ru": return "Отделение общей терапии (General Medicine)";
                    case "ja": return "総合内科 (General Medicine)";
                    case "ko": return "일반내과 (General Medicine)";
                    case "zh": return "全科医疗部 (General Medicine)";
                    case "th": return "แผนกอายุรกรรมทั่วไป (General Medicine)";
                    case "es": return "Medicina General (General Medicine)";
                    case "pt": return "Medicina Geral (General Medicine)";
                    case "fr": return "Médecine Générale (General Medicine)";
                    case "de": return "Allgemeinmedizin (General Medicine)";
                    case "it": return "Medicina Generale (General Medicine)";
                    default: return "General Medicine";
                }
        }
    }

    public String getRecommendation(String ruleId, String language) {
        String lang = normalizeLang(language);
        switch (ruleId) {
            case "CARDIAC_EMERGENCY_PROTOCOL_01":
                switch (lang) {
                    case "te": return "వెంటనే 108 అత్యవసర నంబర్‌కు కాల్ చేయండి! ప్రశాంతంగా కూర్చుని తల కాస్త ఎత్తుగా ఉండేలా విశ్రాంతి తీసుకోండి. ఆసుపత్రికి స్వయంగా డ్రైవింగ్ చేయవద్దు. అత్యవసర సిబ్బంది సలహా ఇస్తే ఒక ఆస్పిరిన్ నమలండి.";
                    case "kn": return "ತಕ್ಷಣವೇ 108 ತುರ್ತು ಸಂಖ್ಯೆಗೆ ಕರೆ ಮಾಡಿ! ಶಾಂತವಾಗಿ ಕುಳಿತು ತಲೆಯನ್ನು ಸ್ವಲ್ಪ ಮೇಲಕ್ಕೆತ್ತಿ ವಿಶ್ರಾಂತಿ ಪಡೆಯಿರಿ. ನೀವೇ ಆಸ್ಪತ್ರೆಗೆ ವಾಹನ ಚಲಾಯಿಸಬೇಡಿ.";
                    case "hi": return "तुरंत 108 आपातकालीन सेवा को कॉल करें! शांति से बैठें और सिर को थोड़ा ऊपर उठाकर आराम करें। स्वयं गाड़ी चलाकर अस्पताल न जाएं।";
                    case "ta": return "உடனடியாக 108 அவசர சிகிச்சை எண்ணை அழைக்கவும்! அமைதியாக அமர்ந்து தலையை சற்று உயர்த்தி ஓய்வெடுக்கவும். சுயமாக வாகனம் ஓட்ட வேண்டாம்.";
                    case "ml": return "ഉടൻ തന്നെ 108 അടിയന്തര നമ്പറിൽ വിളിക്കുക! തല അല്പം ഉയർത്തി ശാന്തമായി വിശ്രമിക്കുക. സ്വയം വാഹനം ഓടിക്കരുത്.";
                    case "bn": return "অবিলম্বে ১০৮ জরুরি নম্বরে কল করুন! শান্তভাবে বসুন এবং মাথা কিছুটা উঁচু করে বিশ্রাম নিন। নিজে গাড়ি চালাবেন না।";
                    case "mr": return "त्वरित १०८ आपत्कालीन सेवेला कॉल करा! शांत बसा आणि डोके थोडे वर करून विश्रांती घ्या. स्वतः वाहन चालवू नका.";
                    case "ur": return "فوری طور پر 108 ایمرجنسی نمبر پر کال کریں! پرسکون ہو کر بیٹھیں اور سر اونچا رکھ کر آرام کریں۔ خود گاڑی چلا کر نہ جائیں۔";
                    case "ar": return "اتصل بالإسعاف (108 / 911) على الفور! اجلس بهدوء مع رفع الرأس قليلاً ولا تقُد السيارة بنفسك.";
                    case "ru": return "Немедленно вызовите скорую помощь (112 или 103)! Сядьте в удобное положение с приподнятым изголовьем. Не садитесь за руль самостоятельно.";
                    case "ja": return "直ちに救急車（119番）を要請してください！上半身を少し起こして安静にし、ご自身で運転しないでください。";
                    case "ko": return "즉시 119 응급구조대에 전화하세요! 머리를 살짝 올린 편안한 자세로 안정을 취하고, 직접 운전하지 마세요.";
                    case "zh": return "请立即拨打急救电话（120或911）！静坐休息并将头部略微抬高，切勿自行驾车前往医院。";
                    case "th": return "โทร 1669 ทันที! นั่งพักอย่างสงบโดยยกศีรษะสูงขึ้นเล็กน้อย อย่าขับรถไปด้วยตนเอง";
                    case "es": return "Llame inmediatamente al 108 o servicios de emergencia. Siéntese tranquilamente con la cabeza elevada. No conduzca usted mismo.";
                    case "pt": return "Ligue imediatamente para o 192 ou emergência. Sente-se tranquilamente com a cabeça elevada. Não dirija até o hospital.";
                    case "fr": return "Appelez le 15 ou le 112 immédiatement ! Restez assis au calme avec la tête surélevée. Ne conduisez pas vous-même.";
                    case "de": return "Rufen Sie sofort die Notrufnummer 112 an! Setzen Sie sich ruhig mit leicht erhöhtem Oberkörper hin. Fahren Sie nicht selbst.";
                    case "it": return "Chiami immediatamente il 118 o il 112! Si sieda tranquillamente con la testa sollevata. Non si metta alla guida.";
                    default: return "Call 108 / 911 immediately. Sit or rest quietly with head slightly elevated. Do not drive yourself to the hospital. Chew one adult aspirin (300mg) if not allergic and advised by emergency dispatchers.";
                }

            case "NEURO_FAST_EMERGENCY_02":
                switch (lang) {
                    case "te": return "వెంటనే 108 / 112 అత్యవసర నంబర్‌కు కాల్ చేయండి! లక్షణాలు మొదలైన ఖచ్చితమైన సమయాన్ని గుర్తించండి. రోగికి ఆహారం, నీరు లేదా ఆస్పిరిన్ ఇవ్వవద్దు. రోగిని సురక్షితమైన స్థితిలో ఉంచండి.";
                    case "kn": return "ತಕ್ಷಣವೇ 108 / 112 ತುರ್ತು ಸಂಖ್ಯೆಗೆ ಕರೆ ಮಾಡಿ! ಲಕ್ಷಣಗಳು ಪ್ರಾರಂಭವಾದ ನಿಖರ ಸಮಯವನ್ನು ದಾಖಲಿಸಿ. ರೋಗಿಗೆ ಆಹಾರ, ನೀರು ಅಥವಾ ಆಸ್ಪಿರಿನ್ ನೀಡಬೇಡಿ.";
                    case "hi": return "तुरंत आपातकालीन सेवाओं (108 / 112) पर कॉल करें! लक्षण शुरू होने का सही समय नोट करें। मरीज को कोई भोजन, पानी या एस्पिरिन न दें।";
                    case "ta": return "உடனடியாக 108 / 112 அவசர எண்ணை அழைக்கவும்! அறிகுறிகள் தொடங்கிய சரியான நேரத்தை குறித்துக் கொள்ளவும். நோயாளிக்கு உணவு அல்லது தண்ணீர் கொடுக்க வேண்டாம்.";
                    case "ml": return "ഉടൻ തന്നെ 108 / 112 നമ്പറിൽ വിളിക്കുക! ലക്ഷണങ്ങൾ തുടങ്ങിയ സമയം കുറിച്ചുവെക്കുക. രോഗിക്ക് ഭക്ഷണവും വെള്ളവും നൽകരുത്.";
                    case "bn": return "অবিলম্বে জরুরি নম্বর (১০৮ / ১১২) এ কল করুন! লক্ষণ শুরুর সঠিক সময় লিখে রাখুন। রোগীকে খাবার বা পানি দেবেন না।";
                    case "mr": return "ताबडतोब १०८ / ११२ वर संपर्क साधा! लक्षणे सुरू होण्याची अचूक वेळ नोंदवा. रुग्णाला पाणी किंवा अन्न देऊ नका.";
                    case "ur": return "فوری طور پر 108 یا 112 پر کال کریں! علامات شروع ہونے کا صحیح وقت نوٹ کریں۔ مریض کو کچھ کھانے پینے کو نہ دیں۔";
                    case "ar": return "اتصل بالطوارئ فوراً! سجّل وقت بدء الأعراض بدقة ولا تقدم للمريض أي طعام أو شراب.";
                    case "ru": return "Срочно вызовите скорую помощь (112)! Зафиксируйте точное время появления симптомов. Не давайте есть, пить или лекарства.";
                    case "ja": return "至急119番通報してください！発症時刻を正確に記録し、飲食や服薬はさせないでください。";
                    case "ko": return "즉시 119로 신고하세요! 증상 시작 시간을 정확히 기록하고 물이나 음식을 주지 마세요.";
                    case "zh": return "请立即拨打120急救电话！准确记录发病时间，切勿进食、喝水或擅自服药。";
                    case "th": return "โทรเรียกรถพยาบาลทันที! บันทึกเวลาที่เริ่มมีอาการอย่างแม่นยำ ห้ามให้อาหารหรือน้ำ";
                    case "es": return "¡Llame a emergencias (108 / 112) de inmediato! Anote la hora exacta en que iniciaron los síntomas y no dé alimentos ni agua.";
                    case "pt": return "Ligue para a emergência imediatamente! Anote a hora exata do início dos sintomas e não ofereça água ou comida.";
                    case "fr": return "Contactez les urgences immédiatement ! Notez l'heure précise des premiers symptômes et ne donnez rien à boire ni à manger.";
                    case "de": return "Rufen Sie sofort den Notruf! Notieren Sie den genauen Beginn der Symptome und geben Sie keine Nahrung oder Getränke.";
                    case "it": return "Chiami subito i soccorsi! Prenda nota dell'orario esatto di inizio dei sintomi e non somministri cibi o liquidi.";
                    default: return "Call Emergency Services (108 / 911 / 112) immediately! Note the exact time symptoms began. Do not give any food, water, or aspirin. Keep the patient in a safe recovery position.";
                }

            case "GI_BLEED_ACUTE_ABDOMEN_03":
                switch (lang) {
                    case "te": return "వెంటనే సమీపంలోని అత్యవసర విభాగానికి వెళ్ళండి. నోటి ద్వారా ఆహారం లేదా నీరు ఏదీ తీసుకోవద్దు. అత్యవసర వైద్య బృందం వచ్చే వరకు ప్రశాంతంగా పడుకోండి.";
                    case "kn": return "ತಕ್ಷಣವೇ ಹತ್ತಿರದ ತುರ್ತು ವಿಭಾಗಕ್ಕೆ ತೆರಳಿ. ಬಾಯಿಯ ಮೂಲಕ ಯಾವುದೇ ಆಹಾರ ಅಥವಾ ನೀರನ್ನು ಸೇವಿಸಬೇಡಿ.";
                    case "hi": return "तुरंत नजदीकी आपातकालीन कक्ष में जाएं। मुंह से कोई भोजन या पानी न लें।";
                    case "ta": return "உடனடியாக அருகிலுள்ள அவசர சிகிச்சை பிரிவுக்கு செல்லவும். வாய் வழியாக உணவு அல்லது தண்ணீர் எதையும் உட்கொள்ள வேண்டாம்.";
                    case "ml": return "ഉടൻ തന്നെ അടുത്തുള്ള അത്യാഹിത വിഭാഗത്തിൽ എത്തുക. വായിലൂടെ യാതൊരു ആഹാരമോ വെള്ളമോ കഴിക്കരുത്.";
                    case "bn": return "অবিলম্বে নিকটতম জরুরি বিভাগে যান। মুখ দিয়ে কোনো খাবার বা পানি গ্রহণ করবেন না।";
                    case "mr": return "लगेच जवळच्या आपत्कालीन विभागात जा. तोंडाने काहीही खाऊ किंवा पिऊ नका.";
                    case "ur": return "فوراً قریبی ایمرجنسی وارڈ میں جائیں۔ منہ کے ذریعے کوئی خوراک یا پانی نہ لیں۔";
                    case "ar": return "توجه فوراً إلى قسم الطوارئ. لا تتناول أي طعام أو شراب عبر الفم.";
                    case "ru": return "Немедленно обратитесь в приемное отделение больницы. Не принимайте пищу и воду.";
                    case "ja": return "直ちに最寄りの救急外来を受診してください。口からの飲食は一切控えてください。";
                    case "ko": return "즉시 응급실로 이동하세요. 입으로 음식이나 물을 일체 섭취하지 마세요.";
                    case "zh": return "请立即前往最近的医院急诊科。禁止经口进食任何食物或饮水。";
                    case "th": return "ตรงไปที่ห้องฉุกเฉินทันที งดรับประทานอาหารและน้ำทางปากทุกชนิด";
                    case "es": return "Acuda de inmediato a urgencias. No ingiera alimentos ni líquidos por vía oral.";
                    case "pt": return "Vá imediatamente ao pronto-socorro. Não consuma alimentos ou líquidos pela boca.";
                    case "fr": return "Rendez-vous immédiatement aux urgences. Ne mangez et ne buvez absolument rien.";
                    case "de": return "Begeben Sie sich unverzüglich in eine Notaufnahme. Nehmen Sie nichts über den Mund zu sich.";
                    case "it": return "Si rechi tempestivamente al pronto soccorso. Non assuma alcun cibo o liquido per via orale.";
                    default: return "Proceed directly to the Emergency Room. Do not consume anything by mouth. Await emergency triage evaluation.";
                }

            case "ANAPHYLAXIS_EMERGENCY_04":
                switch (lang) {
                    case "te": return "వెంటనే 108 కు కాల్ చేయండి! మీ వద్ద ఎపిపెన్ అందుబాటులో ఉంటే వెంటనే తొడ వెలుపలి భాగంలో ఇంజెక్షన్ చేయండి. కాళ్లను పైకి లేపి పడుకోండి.";
                    case "kn": return "ತಕ್ಷಣವೇ 108 ತುರ್ತು ಸಂಖ್ಯೆಗೆ ಕರೆ ಮಾಡಿ! ನಿಮ್ಮ ಬಳಿ ಎಪಿಪೆನ್ ಇದ್ದರೆ ತಕ್ಷಣವೇ ತೊಡೆಗೆ ಚುಚ್ಚಿಕೊಳ್ಳಿ. ಕಾಲುಗಳನ್ನು ಮೇಲಕ್ಕೆತ್ತಿ ಮಲಗಿರಿ.";
                    case "hi": return "तुरंत 108 पर कॉल करें! यदि आपके पास एपिपेन है, तो इसे तुरंत जांघ पर लगाएं। पैरों को ऊपर उठाकर सीधे लेट जाएं।";
                    case "ta": return "உடனடியாக 108 ஐ அழைக்கவும்! எபிபென் இருந்தால் உடனடியாக தொடையில் செலுத்தவும். கால்களை உயர்த்தி நேராக படுக்கவும்.";
                    case "ml": return "ഉടൻ തന്നെ 108 ൽ വിളിക്കുക! എപിപെൻ ഉണ്ടെങ്കിൽ ഉടൻ തന്നെ തുടയിൽ കുത്തിവെയ്ക്കുക.";
                    case "bn": return "অবিলম্বে ১০৮ এ কল করুন! এপিপেন থাকলে তৎক্ষণাৎ উরুতে প্রয়োগ করুন এবং পা উঁচু করে শুয়ে থাকুন।";
                    case "mr": return "त्वरित १०८ वर कॉल करा! एपिपेन असल्यास लगेच मांडीवर टोचा आणि पाय वर करून झोपा.";
                    case "ur": return "فوراً 108 پر کال کریں! اگر ایپی پین موجود ہے تو فوراً ران میں لگائیں اور پاؤں اونچے رکھ کر لیٹیں۔";
                    case "ar": return "اتصل بالإسعاف فوراً! إذا كان لديك قلم إبينفرين، احقنه فوراً في الفخذ واستلقِ مع رفع الساقين.";
                    case "ru": return "Срочно вызовите скорую помощь (112)! При наличии шприц-ручки с адреналином сделайте инъекцию в бедро.";
                    case "ja": return "直ちに119番通報してください！エピペンをお持ちの場合は直ちに太ももに注射し、足を高くして横になってください。";
                    case "ko": return "즉시 119에 연락하세요! 에피네프린 자가주사기가 있다면 허벅지에 즉시 투여하고 다리를 올려 눕히세요.";
                    case "zh": return "立即拨打急救电话！如备有肾上腺素自动注射笔（EpiPen），请立即注射在大腿外侧，平躺并抬高双腿。";
                    case "th": return "โทร 1669 ทันที! หากมีปากกาฉีดเอพิเนฟรินให้ฉีดที่ต้นขาทันที นอนราบและยกขาสูง";
                    case "es": return "Llame al 108 inmediatamente. Si dispone de un autoinyector de epinefrina (EpiPen), aplíquelo en el muslo de inmediato.";
                    case "pt": return "Ligue para a emergência imediatamente. Se possuir autoinjetor de epinefrina (EpiPen), aplique-o na coxa de imediato.";
                    case "fr": return "Appelez le 15 immédiatement. Utilisez votre auto-injecteur d'adrénaline dans la cuisse et allongez-vous jambes surélevées.";
                    case "de": return "Wählen Sie sofort den Notruf! Verabreichen Sie bei Vorhandensein den Adrenalin-Autoinjektor in den Oberschenkel.";
                    case "it": return "Chiami subito il 118! Se possiede un autoiniettore di adrenalina, lo somministri immediatamente nella coscia.";
                    default: return "Call 108 / 911 immediately. If you carry an Epinephrine auto-injector (EpiPen), administer it into the outer thigh immediately. Lay flat with legs elevated.";
                }

            case "ORTHOPEDIC_FRACTURE_TRAUMA_07":
                switch (lang) {
                    case "te": return "అనుమానిత ఎముక పగులు నిర్ధారణ కోసం వెంటనే ఆర్థోపెడిక్స్ అత్యవసర విభాగాన్ని సంప్రదించి ఎక్స్-రే తీయించుకోండి. గాయపడిన కాలుపై బరువు మోపవద్దు, నడవవద్దు; కాలును కదల్చకుండా ఉంచండి. వాపు తగ్గడానికి గుడ్డలో చుట్టిన ఐస్ ప్యాక్‌తో కాపడం పెట్టండి మరియు కాలును ఎత్తుగా ఉంచండి.";
                    case "kn": return "ಸಂಭಾವ್ಯ ಮೂಳೆ ಮುರಿತದ ತಪಾಸಣೆಗಾಗಿ ತಕ್ಷಣ ಆರ್ಥೋಪೆಡಿಕ್ಸ್ ತುರ್ತು ವಿಭಾಗವನ್ನು ಸಂಪರ್ಕಿಸಿ ಎಕ್ಸ್-ರೇ ಮಾಡಿಸಿ. ಗಾಯಗೊಂಡ ಕಾಲಿನ ಮೇಲೆ ಭಾರ ಹಾಕಬೇಡಿ, ನಡೆಯಬೇಡಿ; ಕಾಲನ್ನು ಅಲುಗಾಡಿಸದೆ ಇರಿಸಿ. ಊತ ಕಡಿಮೆ ಮಾಡಲು ಬಟ್ಟೆಯಲ್ಲಿ ಸುತ್ತಿದ ಐಸ್ ಪ್ಯಾಕ್‌ನಿಂದ ಶಾಖ ಕೊಡಿ ಮತ್ತು ಕಾಲನ್ನು ಮೇಲಕ್ಕೆತ್ತಿಡಿ.";
                    case "hi": return "संदिग्ध हड्डी टूटने (फ्रैक्चर) की जांच के लिए तुरंत नजदीकी अस्थि रोग क्लिनिक जाकर एक्स-रे करवाएं। चोट लगे पैर पर बिल्कुल वजन न डालें और न चलें; पैर को स्थिर रखें। सूजन कम करने के लिए कपड़े में लपेटकर बर्फ की सिकाई करें और पैर को ऊपर उठाकर रखें।";
                    case "ta": return "உடனடியாக அருகிலுள்ள எலும்பியல் அவசரப் பிரிவை அணுகவும். எக்ஸ்-ரே பரிசோதனை செய்து எலும்பு முறிவு உள்ளதா என்பதை உறுதிப்படுத்தவும். அடிபட்ட காலில் எடை வைக்கவோ நடக்கவோ வேண்டாம்; காலை அசைக்காமல் வைக்கவும். வீக்கம் குறைய துணியில் சுற்றிய பனிக்கட்டி ஒத்தடம் கொடுக்கவும்.";
                    case "ml": return "അസ്ഥി ഒടിവ് ഉണ്ടോ എന്ന് പരിശോധിക്കാൻ ഉടൻ തന്നെ ഓർത്തോപീഡിക്സ് അത്യാഹിത വിഭാഗത്തിൽ എക്സ്-റേ എടുക്കുക. പരിക്കേറ്റ കാലിൽ ഭാരം നൽകരുത്, നടക്കരുത്; കാൽ അനക്കാതെ വെയ്ക്കുക. നീർവീക്കം കുറയ്ക്കാൻ തുണിയിൽ പൊതിഞ്ഞ ഐസ് പായ്ക്ക് ഉപയോഗിക്കുക.";
                    case "bn": return "হাড় ভাঙার সন্দেহে অবিলম্বে অর্থোপেডিক্স ক্লিনিকে গিয়ে একটি এক্স-রে করান। আঘাতপ্রাপ্ত পায়ে কোনো ওজন দেবেন না, হাঁটবেন না; পা স্থির রাখুন। ফোলা কমাতে কাপড়ে মোড়ানো বরফের সেঁক দিন এবং পা উঁচু রাখুন।";
                    case "mr": return "हाड मोडल्याच्या तपासणीसाठी त्वरित अस्थिरोग तज्ञांकडे जाऊन एक्स-रे करून घ्या. दुखापत झालेल्या पायावर वजन टाकू नका, चालू नका; पाय हलवू नका. सूज कमी करण्यासाठी कपड्यात गुंडाळलेला बर्फ लावा आणि पाय वर ठेवा.";
                    case "ur": return "ہڈی ٹوٹنے کے شبہے کے پیش نظر فوری طور پر آرتھوپیڈکس کلینک سے رجوع کریں اور ایکسرے کروائیں۔ زخمی ٹانگ پر وزن نہ ڈالیں اور نہ چلیں؛ ٹانگ کو حرکت نہ دیں۔ سوجن کم کرنے کے لیے برف لگائیں۔";
                    case "ar": return "يرجى زيارة عيادة جراحة العظام أو الطوارئ فوراً لإجراء فحص بالأشعة السينية للتأكد من عدم وجود كسر في العظام. ثبت الطرف المصاب ولا تضع وزناً عليه أو تمشِ عليه. ضع كمادات ثلج ملفوفة بقطعة قماش لتخفيف التورم.";
                    case "ru": return "Срочно обратитесь в ортопедическое отделение или травмпункт для рентгена при подозрении на перелом кости. Зафиксируйте травмированную конечность — не наступайте на ногу и не ходите. Приложите холодный компресс со льдом для уменьшения отека.";
                    case "ja": return "骨折の疑いがあるため、直ちに整形外科を受診してレントゲン検査を受けてください。負傷した足に体重をかけたり歩いたりせず、患部を固定してください。腫れを抑えるために布で包んだ氷で冷やし、足を高く保ってください。";
                    case "ko": return "골절 의심 부위 확인을 위해 즉시 정형외과를 방문하여 엑스레이 검사를 받으세요. 다친 다리에 체중을 싣거나 걷지 말고 다리를 움직이지 않도록 고정하세요. 부기를 가라앉히기 위해 천에 싼 얼음찜질을 하고 다리를 높게 유지하세요.";
                    case "zh": return "疑似骨折，请立即前往骨科急诊进行X光检查。受损肢体请严格制动并固定，切勿负重或走动。使用毛巾包裹冰袋冷敷以消肿，并垫高伤肢。";
                    case "th": return "ควรไปพบแพทย์แผนกกระดูกและข้อทันทีเพื่อตรวจเอกซเรย์ประเมินกระดูกหัก อย่าลงน้ำหนักหรือเดินบนขาข้างที่บาดเจ็บ ให้อยู่นิ่งๆ ประคบเย็นด้วยน้ำแข็งห่อผ้าเพื่อลดอาการบวมและยกขาสูง";
                    case "es": return "Acuda a una clínica de ortopedia o urgencias de inmediato para una radiografía y evaluar la sospecha de fractura ósea. Inmovilice estrictamente la extremidad lesionada: no camine ni apoye peso sobre ella. Aplique una compresa de hielo envuelta en tela para reducir la inflamación y eleve la pierna.";
                    case "pt": return "Procure uma clínica de ortopedia ou pronto-socorro imediatamente para um raio-X a fim de avaliar a suspeita de fratura óssea. Imobilize rigorosamente o membro lesionado: não ande nem apoie peso sobre ele. Aplique compressa fria de gelo envolvida em pano para reduzir o inchaço e mantenha a perna elevada.";
                    case "fr": return "Consultez immédiatement un service d'orthopédie ou les urgences pour réaliser une radiographie afin d'évaluer la suspicion de fracture osseuse. Immobilisez strictement le membre blessé : ne marchez pas et ne posez pas le pied par terre. Appliquez une poche de glace enveloppée dans un tissu pour réduire le gonflement et surélevez la jambe.";
                    case "de": return "Suchen Sie unverzüglich eine orthopädische Notaufnahme auf, um durch ein Röntgenbild eine Knochenfraktur abzuklären. Ruhigstellen Sie das verletzte Bein strikt: Nicht belasten oder auftreten. Legen Sie eine in ein Tuch gewickelte Eispackung auf, um Schwellungen zu lindern, und lagern Sie das Bein hoch.";
                    case "it": return "Si rechi immediatamente presso un ambulatorio ortopedico o al pronto soccorso per una radiografia al fine di escludere fratture ossee. Immobilizzi rigorosamente l'arto infortunato: non cammini e non carichi peso. Applichi una borsa del ghiaccio avvolta in un panno per ridurre il gonfiore e mantenga la gamba sollevata.";
                    default: return "Visit an Orthopedics clinic or urgent care immediately for an X-Ray imaging scan to evaluate the suspected bone fracture. Strictly immobilize the injured limb—do not walk or bear weight on it. Apply a cold ice compress wrapped in cloth to reduce internal swelling and elevate the leg.";
                }

            case "RESPIRATORY_INFECTION_MODERATE_05":
                switch (lang) {
                    case "te": return "24 గంటల్లోగా వైద్యుడిని సంప్రదించండి. శరీర ఉష్ణోగ్రత మరియు ఆక్సిజన్ స్థాయిలను పర్యవేక్షించండి. తగినంత విశ్రాంతి తీసుకోండి మరియు గోరువెచ్చని నీటిని త్రాగండి.";
                    case "kn": return "24 ಗಂಟೆಗಳ ಒಳಗೆ ವೈದ್ಯರನ್ನು ಭೇಟಿ ಮಾಡಿ. ದೇಹದ ತಾಪಮಾನ ಮತ್ತು ಆಕ್ಸಿಜನ್ ಮಟ್ಟವನ್ನು ಮೇಲ್ವಿಚಾರಣೆ ಮಾಡಿ. ಸಾಕಷ್ಟು ವಿಶ್ರಾಂತಿ ಪಡೆಯಿರಿ ಮತ್ತು ಬೆಚ್ಚಗಿನ ನೀರನ್ನು ಕುಡಿಯಿರಿ.";
                    case "hi": return "24 घंटे के भीतर डॉक्टर से परामर्श लें। अपने शरीर का तापमान और ऑक्सीजन स्तर मापें। पर्याप्त आराम करें और गुनगुना पानी पिएं।";
                    case "ta": return "24 மணி நேரத்திற்குள் மருத்துவரை நேரில் அணுகவும். உடல் வெப்பநிலை மற்றும் ஆக்சிஜன் அளவை கண்காணிக்கவும். போதுமான ஓய்வு மற்றும் வெதுவெதுப்பான நீர் அருந்தவும்.";
                    case "ml": return "24 മണിക്കൂറിനുള്ളിൽ ഡോക്ടറെ കാണുക. ശരീര താപനിലയും ഓക്സിജൻ അളവും നിരീക്ഷിക്കുക. വിശ്രമിക്കുകയും ചൂടുവെള്ളം കുടിക്കുകയും ചെയ്യുക.";
                    case "bn": return "২৪ ঘণ্টার মধ্যে একজন ডাক্তারের সাথে পরামর্শ করুন। শরীরের তাপমাত্রা ও অক্সিজেন পর্যবেক্ষণ করুন। পর্যাপ্ত বিশ্রাম নিন ও গরম তরল পান করুন।";
                    case "mr": return "२४ तासांच्या आत डॉक्टरांचा सल्ला घ्या. शरीराचे तापमान आणि ऑक्सिजन पातळी तपासा. विश्रांती घ्या आणि कोमट पाणी प्या.";
                    case "ur": return "24 گھنٹوں کے اندر ڈاکٹر سے رجوع کریں۔ جسم کا درجہ حرارت اور آکسیجن کی سطح چیک کریں۔ آرام کریں اور نیم گرم پانی پئیں۔";
                    case "ar": return "حدد موعداً للفحص الطبي خلال 24 ساعة. راقب نسبة الأكسجين ودرجة الحرارة، واسترح وتناول سوائل دافئة.";
                    case "ru": return "Запишитесь на прием к врачу в течение 24 часов. Контролируйте температуру и уровень кислорода (SpO2). Больше отдыхайте и пейте теплое питье.";
                    case "ja": return "24時間以内に医師の診察を受けてください。体温と血中酸素濃度を測定し、安静にして温かい水分を摂取してください。";
                    case "ko": return "24시간 이내에 진료를 받으세요. 체온과 산소포화도를 수시로 측정하고 충분한 휴식과 따뜻한 수분을 섭취하세요.";
                    case "zh": return "请在24小时内就医检查。密切监测体温及血氧饱和度，保证充分休息，多饮用温水。";
                    case "th": return "นัดตรวจกับแพทย์ภายใน 24 ชั่วโมง ติดตามอุณหภูมิร่างกายและออกซิเจน พักผ่อนและดื่มน้ำอุ่น";
                    case "es": return "Programe una consulta médica dentro de las 24 horas. Monitoree su temperatura y saturación de oxígeno. Descanse e hidrátese bien.";
                    case "pt": return "Agende uma consulta médica dentro de 24 horas. Monitore sua temperatura e saturação de oxigênio. Descanse e beba líquidos mornos.";
                    case "fr": return "Prenez rendez-vous avec un médecin dans les 24 heures. Surveillez votre température et oxygénation. Reposez-vous et buvez chaud.";
                    case "de": return "Vereinbaren Sie innerhalb von 24 Stunden einen Arzttermin. Überwachen Sie Temperatur und Sauerstoffsättigung. Ruhen Sie sich aus.";
                    case "it": return "Fissi una visita medica entro 24 ore. Monitori la temperatura e la saturazione di ossigeno. Riposi e beva liquidi caldi.";
                    default: return "Schedule an in-person clinical examination within 24 hours. Monitor your oxygen saturation (SpO2) and temperature. Rest, stay well hydrated, and avoid strenuous activity.";
                }

            case "GI_DISTRESS_MODERATE_06":
                switch (lang) {
                    case "te": return "ఈరోజే వైద్యుడిని సంప్రదించండి. ఓఆర్ఎస్ ద్రావణం లేదా ఎలక్ట్రోలైట్ ద్రవాలను కొద్దికొద్దిగా తరచుగా తాగండి. నొప్పి పొత్తికడుపు కుడి వైపుకు మారితే వెంటనే అత్యవసర విభాగానికి వెళ్ళండి.";
                    case "kn": return "ಇಂದೇ ವೈದ್ಯರನ್ನು ಭೇಟಿ ಮಾಡಿ. ಒಆರ್‌ಎಸ್ ಅಥವಾ ಎಲೆಕ್ಟ್ರೋಲೈಟ್ ದ್ರಾವಣವನ್ನು ಆಗಾಗ ಸ್ವಲ್ಪ ಸ್ವಲ್ಪ ಕುಡಿಯಿರಿ. ನೋವು ಹೊಟ್ಟೆಯ ಬಲಭಾಗಕ್ಕೆ ಹೋದರೆ ತಕ್ಷಣ ತುರ್ತು ಚಿಕಿತ್ಸೆ ಪಡೆಯಿರಿ.";
                    case "hi": return "आज ही डॉक्टर से परामर्श लें। बार-बार घूंट-घूंट करके ओआरएस या इलेक्ट्रोलाइट तरल पदार्थ पिएं। यदि दर्द पेट के निचले दाहिने हिस्से में जाए, तो तुरंत अस्पताल जाएं।";
                    case "ta": return "இன்றே மருத்துவரை அணுகவும். ORS கரைசல் அல்லது எலக்ட்ரோலைட் திரவங்களை அடிக்கடி பருகவும். வலி அடிவயிற்றின் வலது பக்கத்திற்கு மாறினால் அவசர சிகிச்சை பெறவும்.";
                    case "ml": return "ഇന്നുതന്നെ ഒരു ഡോക്ടറെ കാണുക. ഒആർഎസ് ലായനി അല്പാൽപം കുടിക്കുക. വേദന അടിവയറ്റിന്റെ വലതുവശത്തേക്ക് മാറുകയാണെങ്കിൽ ഉടൻ ആശുപത്രിയിൽ എത്തുക.";
                    case "bn": return "আজই একজন ডাক্তারের পরামর্শ নিন। ঘন ঘন ওআরএস বা তরল পান করুন। পেটের ডান পাশে ব্যথা হলে জরুরি চিকিৎসকের কাছে যান।";
                    case "mr": return "आजच डॉक्टरांचा सल्ला घ्या. ओआरएस किंवा इलेक्ट्रोलाइट पाणी थोडे थोडे प्या. पोटात उजव्या बाजूला जास्त दुखू लागल्यास त्वरित दवाखान्यात जा.";
                    case "ur": return "آج ہی ڈاکٹر سے رجوع کریں۔ او آر ایس کے گھونٹ بار بار پئیں۔ اگر درد پیٹ کے نچلے دائیں حصے میں جائے تو فوری ہسپتال جائیں۔";
                    case "ar": return "استشر طبيباً اليوم. اشرب محلول الجفاف بجرعات صغيرة ومتكررة. إذا انتقل الألم لأسفل اليمين فتوجه للطوارئ.";
                    case "ru": return "Проконсультируйтесь с врачом сегодня. Пейте регидратационные растворы небольшими глотками. При смещении боли вправо обратитесь в скорую.";
                    case "ja": return "本日中に医師の診察を受けてください。経口補水液を少しずつこまめに摂取し、痛みが右下腹部に移った場合は至急受診してください。";
                    case "ko": return "오늘 중으로 진료를 받으세요. 경구수액을 소량씩 자주 마시고, 통증이 오른쪽 아랫배로 이동하면 즉시 응급실로 가세요.";
                    case "zh": return "请于今日就医咨询。少量多次饮用口服补液盐溶液，若疼痛转移至右下腹，请立即前往急诊。";
                    case "th": return "ปรึกษาแพทย์ในวันนี้ ดื่มน้ำเกลือแร่ทีละน้อยแต่บ่อยครั้ง หากปวดร้าวไปท้องน้อยด้านขวาให้ไปห้องฉุกเฉินทันที";
                    case "es": return "Consulte a un médico hoy. Beba suero oral en pequeños sorbos frecuentes. Si el dolor se desplaza al lado inferior derecho, acuda a urgencias.";
                    case "pt": return "Consulte um médico hoje. Beba soro de reidratação oral em pequenos goles frequentes. Se a dor migrar para o lado inferior direito, vá ao pronto-socorro.";
                    case "fr": return "Consultez un médecin aujourd'hui. Buvez des solutions de réhydratation par petites gorgées. Si la douleur migre vers la fosse iliaque droite, allez aux urgences.";
                    case "de": return "Suchen Sie heute einen Arzt auf. Trinken Sie elektrolytreiche Lösungen in kleinen Schlucken. Gehen Sie bei Schmerzen im rechten Unterbauch sofort in die Notaufnahme.";
                    case "it": return "Consulti un medico oggi stesso. Assuma soluzioni reidratanti orali a piccoli sorsi. Se il dolore migra in basso a destra, vada subito al pronto soccorso.";
                    default: return "Consult a physician today or visit an urgent care center. Drink oral rehydration solution (ORS) in frequent small sips. If pain migrates to lower right side, seek immediate emergency care.";
                }

            case "ORTHO_SPRAIN_MODERATE_07":
                switch (lang) {
                    case "te": return "ఎముకల వైద్యుడిని సంప్రదించి ఎక్స్-రే తీయించుకోండి. విశ్రాంతి, ఐస్ కాపడం, కట్టు కట్టడం మరియు ఎత్తుగా ఉంచడం పాటించండి. కీలుపై బరువు మోపవద్దు.";
                    case "kn": return "ಆರ್ಥೋಪೆಡಿಕ್ ವೈದ್ಯರನ್ನು ಸಂಪರ್ಕಿಸಿ ಎಕ್ಸ್-ರೇ ಮಾಡಿಸಿ. ವಿಶ್ರಾಂತಿ, ಐಸ್, ಬ್ಯಾಂಡೇಜ್ ಮತ್ತು ಎತ್ತರದಲ್ಲಿಡುವ ವಿಧಾನವನ್ನು ಪಾಲಿಸಿ. ಕೀಲಿನ ಮೇಲೆ ಭಾರ ಹಾಕಬೇಡಿ.";
                    case "hi": return "हड्डी के डॉक्टर से परामर्श लें और एक्स-रे करवाएं। आराम, बर्फ की सिकाई, पट्टी और ऊंचाई पर रखने की विधि अपनाएं। जोड़ पर वजन न डालें।";
                    case "ta": return "எலும்பியல் மருத்துவரை அணுகி எக்ஸ்-ரே எடுக்கவும். ஓய்வு, ஐஸ் ஒத்தடம், கட்டு, காலை உயர்த்தி வைத்தல் முறையைப் பின்பற்றவும். காலில் எடை வைக்க வேண்டாம்.";
                    case "ml": return "ഓർത്തോപീഡിക് ഡോക്ടറെ കണ്ട് എക്സ്-റേ എടുക്കുക. വിശ്രമം, ഐസ് വെയ്ക്കൽ, ബാൻഡേജ് കെട്ടൽ, ഉയർത്തി വെയ്ക്കൽ എന്നിവ പാലിക്കുക.";
                    case "bn": return "অর্থোপেডিক বিশেষজ্ঞের কাছে গিয়ে এক্স-রে করান। বিশ্রাম নিন, বরফ দিন, ব্যান্ডেজ বাঁধুন ও অঙ্গটি উঁচুতে রাখুন। ওজন দেবেন না।";
                    case "mr": return "अस्थिरोग तज्ञांकडे जाऊन एक्स-रे करून घ्या. विश्रांती, बर्फ, पट्टी बांधणे आणि पाय उंच ठेवणे ही पद्धत वापरा. भार टाकू नका.";
                    case "ur": return "ہڈیوں کے ڈاکٹر سے معائنہ کروا کر ایکسرے کروائیں۔ آرام کریں، برف لگائیں، پٹی باندھیں اور پاؤں اونچا رکھیں۔ جوڑ پر وزن نہ ڈالیں۔";
                    case "ar": return "راجع عيادة العظام لإجراء أشعة سينية. اتبع إرشادات الراحة والثلج والرباط الضاغط ورفع المفصل، ولا تضغط عليه.";
                    case "ru": return "Посетите ортопеда для рентгена. Соблюдайте покой, прикладывайте лед, наложите эластичный бинт и держите конечность приподнятой.";
                    case "ja": return "整形外科を受診してレントゲン検査を受けてください。安静・冷却・圧迫・挙上を行い、患部に体重をかけないでください。";
                    case "ko": return "정형외과를 방문하여 엑스레이 검사를 받으세요. 휴식, 얼음찜질, 압박붕대, 거상을 시행하고 관절에 체중을 싣지 마세요.";
                    case "zh": return "请前往骨科就诊并拍摄X光片排除骨折。遵循休息、冷敷、加压包扎和抬高的原则，切勿对受伤关节施加负重。";
                    case "th": return "ไปพบแพทย์กระดูกเพื่อตรวจเอกซเรย์ พักการใช้งาน ประคบเย็น พันผ้าพันแผล และยกข้อต่อให้สูง ห้ามลงน้ำหนัก";
                    case "es": return "Visite a un traumatólogo para una radiografía. Siga reposo, hielo, compresión y elevación, y no apoye peso sobre la articulación.";
                    case "pt": return "Consulte um ortopedista para raio-X. Siga repouso, gelo, compressão e elevação, e evite colocar peso sobre a articulação.";
                    case "fr": return "Consultez un orthopédiste pour une radio. Appliquez le protocole RICE (Repos, Glace, Compression, Élévation) et évitez l'appui.";
                    case "de": return "Suchen Sie einen Orthopäden für ein Röntgenbild auf. Befolgen Sie Schonung, Kühlung, Kompression und Hochlagerung; Gelenk nicht belasten.";
                    case "it": return "Consulti un ortopedico per una radiografia. Segua il riposo, ghiaccio, compressione ed elevazione, ed eviti di caricare sull'articolazione.";
                    default: return "Visit an orthopedic clinic or urgent care facility for an X-ray to rule out fracture or ligament rupture. Follow R.I.C.E. (Rest, Ice, Compression, Elevation) and do not put weight on the joint.";
                }

            case "VIRAL_UPPER_RESPIRATORY_SELFCARE_08":
                switch (lang) {
                    case "te": return "ఇంటి వద్దే తగినంత విశ్రాంతి తీసుకోండి, గోరువెచ్చని నీరు మరియు హెర్బల్ టీ తాగండి. గొంతు నొప్పి కోసం గోరువెచ్చని ఉప్పు నీటితో పుక్కిలించండి మరియు ఆవిరి పట్టండి.";
                    case "kn": return "ಮನೆಯಲ್ಲೇ ಸಾಕಷ್ಟು ವಿಶ್ರಾಂತಿ ಪಡೆಯಿರಿ, ಬೆಚ್ಚಗಿನ ನೀರು ಮತ್ತು ಕಷಾಯ ಕುಡಿಯಿರಿ. ಗಂಟಲು ನೋವಿಗೆ ಉಪ್ಪು ನೀರಿನಿಂದ ಮುಕ್ಕಳಿಸಿ ಮತ್ತು ಹಬೆ ತೆಗೆದುಕೊಳ್ಳಿ.";
                    case "hi": return "घर पर पर्याप्त आराम करें, गुनगुने तरल पदार्थ (हर्बल चाय, गर्म पानी) पिएं, गले में खराश के लिए नमक के पानी से गरारे करें और भाप लें।";
                    case "ta": return "வீட்டிலேயே போதுமான ஓய்வெடுக்கவும், வெதுவெதுப்பான நீர் மற்றும் மூலிகை டீ அருந்தவும். தொண்டை வலிக்கு வெதுவெதுப்பான உப்பு நீரில் வாய் கொப்பளிக்கவும். நீராவி பிடிக்கவும்.";
                    case "ml": return "വീട്ടിൽ പൂർണ്ണ വിശ്രമം എടുക്കുക, ചൂടുവെള്ളവും ചായയും കുടിക്കുക. തൊണ്ടവേദനയ്ക്ക് ഉപ്പുവെള്ളം കവിൾക്കൊള്ളുകയും ആവി പിടിക്കുകയും ചെയ്യുക.";
                    case "bn": return "ঘরে পর্যাপ্ত বিশ্রাম নিন, গরম পানীয় ও তুলসী চা পান করুন। গলা ব্যথার জন্য লবণ পানিতে কুলকুচি করুন এবং ভাপ নিন।";
                    case "mr": return "घरी पुरेशी विश्रांती घ्या, कोमट पाणी व काढा प्या. घसा खवखवत असल्यास मिठाच्या पाण्याच्या गुळण्या करा आणि वाफ घ्या.";
                    case "ur": return "گھر پر آرام کریں، گرم مشروبات پئیں، گلے کی خراش کے لیے نمک کے نیم گرم پانی کے غرارے کریں اور بھاپ لیں۔";
                    case "ar": return "استرح في المنزل واشرب سوائل دافئة، وتغرغر بماء دافئ وملح لتسكين الحلق واستنشق البخار.";
                    case "ru": return "Соблюдайте постельный режим, пейте больше теплой жидкости, полощите горло раствором соли и делайте паровые ингаляции.";
                    case "ja": return "十分な休養をとり、温かい水分をこまめに補給してください。喉の痛みにはぬるま湯でのうがいや吸入が効果的です。";
                    case "ko": return "자택에서 충분한 휴식을 취하고 따뜻한 차나 물을 자주 드세요. 목 통증에는 미온수 소금물 가글과 스팀 흡입이 도움이 됩니다.";
                    case "zh": return "居家充分休息，多饮用温水或草本热茶。咽喉肿痛可用温盐水漱口并进行蒸汽吸入。";
                    case "th": return "พักผ่อนให้เพียงพอที่บ้าน ดื่มน้ำอุ่นและชาสมุนไพร กลั้วคอด้วยน้ำเกลืออุ่น และสูดดมไอน้ำ";
                    case "es": return "Descanse adecuadamente, manténgase bien hidratado con líquidos tibios, realice gárgaras con agua tibia con sal e inhalaciones de vapor.";
                    case "pt": return "Repouse bastante, beba líquidos mornos em abundância, faça gargarejos com água morna e sal e inalações de vapor.";
                    case "fr": return "Reposez-vous, hydratez-vous avec des boissons chaudes, faites des gargarismes à l'eau tiède salée et des inhalations de vapeur.";
                    case "de": return "Gönnen Sie sich Ruhe, trinken Sie warme Flüssigkeiten, gurgeln Sie mit warmem Salzwasser und inhalieren Sie Wasserdampf.";
                    case "it": return "Riposi adeguatamente, beva liquidi caldi, faccia gargarismi con acqua tiepida e sale e inalazioni di vapore.";
                    default: return "Rest adequately, stay well hydrated with warm liquids (herbal tea, clear broth), perform warm saline gargles for sore throat, and use steam inhalation. Over-the-counter paracetamol can help with mild discomfort.";
                }

            case "MINOR_WOUND_SELFCARE_09":
                switch (lang) {
                    case "te": return "గాయాన్ని శుభ్రమైన చల్లని నీటితో కడిగి, యాంటీసెప్టిక్ లేపనం రాసి శుభ్రమైన బ్యాండేజ్ వేయండి. చిన్న కాలిన గాయాలకు 10-15 నిమిషాలు చల్లని నీటి ప్రవాహం కింద ఉంచండి.";
                    case "kn": return "ಗಾಯವನ್ನು ತಣ್ಣೀರಿನಿಂದ ನಿಧಾನವಾಗಿ ತೊಳೆದು ಆಂಟಿಸೆಪ್ಟಿಕ್ ಹಚ್ಚಿ ಬ್ಯಾಂಡೇಜ್ ಹಾಕಿ. ಸಣ್ಣ ಸುಟ್ಟ ಗಾಯಕ್ಕೆ 10-15 ನಿಮಿಷಗಳ ಕಾಲ ಹರಿಯುವ ತಣ್ಣೀರಿನಲ್ಲಿ ಇಡಿ.";
                    case "hi": return "घाव को ठंडे पानी से साफ करें, एंटीसेप्टिक मलहम लगाएं और पट्टी बांधें। मामूली जलने पर 10-15 मिनट तक बहते ठंडे पानी के नीचे रखें।";
                    case "ta": return "வெட்டுக்காயத்தை சுத்தமான குளிர்ந்த நீரால் கழுவி ஆன்டிசெப்டிக் களிம்பு பூசி சுத்தமான பேண்டேஜ் போடவும். தீக்காயத்திற்கு 10-15 நிமிடங்கள் குளிர்ந்த ஓடும் நீரை ஊற்றவும்.";
                    case "ml": return "മുറിവ് തണുത്ത വെള്ളത്തിൽ വൃത്തിയാക്കി ആന്റിസെപ്റ്റിക് പുരട്ടി ബാൻഡേജ് ഇടുക. പൊള്ളലേറ്റ ഭാഗം 10-15 മിനിറ്റ് തണുത്ത വെള്ളത്തിൽ കാണിക്കുക.";
                    case "bn": return "ক্ষতটি ঠান্ডা পানি দিয়ে ধুয়ে অ্যান্টিসেপটিক মলম লাগান এবং ব্যান্ডেজ দিয়ে ঢেকে দিন। পোড়া জায়গায় ১০-১৫ মিনিট ঠান্ডা পানি ঢালুন।";
                    case "mr": return "जखम थंड पाण्याने स्वच्छ धुवा, अँटीसेप्टिक मलम लावा आणि मलमपट्टी करा. भाजलेल्या भागावर १०-१५ मिनिटे थंड पाणी टाका.";
                    case "ur": return "زخم کو ٹھنڈے پانی سے صاف کریں، اینٹی سیپٹک مرہم لگائیں اور پٹی باندھیں۔ معمولی جلنے کی صورت میں 10-15 منٹ ٹھنڈے پانی کے نیچے رکھیں۔";
                    case "ar": return "نظف الجرح بلطف بالماء البارد، وضع مرهماً مطهراً وغطه بضمادة نظيفة. في الحروق الطفيفة ضعها تحت الماء الجاري البارد لمدة 10 دقائق.";
                    case "ru": return "Промойте рану чистой прохладной водой, обработайте антисептиком и наложите стерильную повязку. При ожоге держите под струей холодной воды 10 минут.";
                    case "ja": return "傷口を清潔な冷水で洗い流し、消毒軟膏を塗って滅菌包帯で保護してください。軽度のやけどは10分間流水で冷やしてください。";
                    case "ko": return "상처를 깨끗한 찬물로 씻고 소독 연고를 바른 후 멸균 밴드로 덮으세요. 경미한 화상은 10분간 흐르는 찬물에 식히세요.";
                    case "zh": return "用洁净冷水冲洗伤口，涂抹抗感染软膏并覆盖无菌敷料。轻微烫伤请置于温和流动冷水下冲洗10至15分钟。";
                    case "th": return "ล้างแผลด้วยน้ำสะอาดเย็น ทายาฆ่าเชื้อและปิดแผลด้วยผ้าก๊อซ หากแผลไหม้ให้เปิดน้ำเย็นไหลผ่าน 10-15 นาที";
                    case "es": return "Lave la herida suavemente con agua fresca, aplique pomada antiséptica y cubra con vendaje estéril. En quemaduras leves, enfríe bajo agua corriente 10 minutos.";
                    case "pt": return "Limpe a ferida com água corrente fria, aplique pomada antisséptica e cubra com curativo limpo. Em queimaduras leves, resfrie com água corrente por 10 minutos.";
                    case "fr": return "Nettoyez la plaie à l'eau fraîche, appliquez une pommade antiseptique et pansez. Pour les brûlures superficielles, refroidissez 10 minutes sous l'eau courante.";
                    case "de": return "Wunde vorsichtig mit kaltem Wasser reinigen, Antiseptikum auftragen und steril verbinden. Leichte Verbrennungen 10 Minuten unter fließendem Wasser kühlen.";
                    case "it": return "Pulisca la ferita con acqua fresca, applichi una pomata antisettica e una benda sterile. Per lievi ustioni raffreddi sotto acqua corrente per 10 minuti.";
                    default: return "Follow our integrated First Aid Guide: Clean the wound gently with cool water, apply an antiseptic ointment, and cover with a sterile bandage. For minor burns, cool under gentle running water for 10-15 minutes.";
                }

            case "SYNCOPE_DIZZINESS_PROTOCOL_10":
                switch (lang) {
                    case "te": return "వెంటనే కాళ్లను 12 అంగుళాల ఎత్తులో ఉంచి పడుకోండి. అకస్మాత్తుగా లేచి నిలబడటం నివారించండి. ఛాతీ నొప్పి ఉంటే లేదా 1 నిమిషం కంటే ఎక్కువ స్పృహ కోల్పోతే వెంటనే అత్యవసర విభాగానికి వెళ్ళండి.";
                    case "kn": return "ತಕ್ಷಣವೇ ಕಾಲುಗಳನ್ನು 12 ಇಂಚು ಮೇಲಕ್ಕೆತ್ತಿ ಮಲಗಿರಿ. ಒಮ್ಮೆಗೆ ಎದ್ದು ನಿಲ್ಲಬೇಡಿ. ಎದೆ ನೋವು ಇದ್ದರೆ ಅಥವಾ 1 ನಿಮಿಷಕ್ಕಿಂತ ಹೆಚ್ಚು ಮೂರ್ಛೆ ಹೋದರೆ ತಕ್ಷಣ ತುರ್ತು ಚಿಕಿತ್ಸೆ ಪಡೆಯಿರಿ.";
                    case "hi": return "तुरंत पैरों को 12 इंच ऊपर उठाकर लेट जाएं। अचानक खड़े होने से बचें। यदि सीने में दर्द हो या 1 मिनट से अधिक बेहोशी रहे तो तुरंत अस्पताल जाएं।";
                    case "ta": return "உடனடியாக கால்களை 12 அங்குலம் உயர்த்தி படுக்கவும். திடீரென எழுந்து நிற்பதைத் தவிர்க்கவும். மார்பு வலி அல்லது 1 நிமிடத்திற்கு மேல் மயக்கம் நீடித்தால் அவசர சிகிச்சை பெறவும்.";
                    case "ml": return "ഉടൻ തന്നെ കാലുകൾ 12 ഇഞ്ച് ഉയർത്തി കിടക്കുക. പെട്ടെന്ന് എഴുന്നേറ്റു നിൽക്കരുത്. നെഞ്ചുവേദന ഉണ്ടെങ്കിൽ ഉടൻ ചികിത്സ തേടുക.";
                    case "bn": return "অবিলম্বে পা ১২ ইঞ্চি উঁচু করে শুয়ে পড়ুন। হঠাৎ উঠে দাঁড়াবেন না। বুকে ব্যথা থাকলে অবিলম্বে জরুরি চিকিৎসা নিন।";
                    case "mr": return "ताबडतोब पाय १२ इंच वर करून झोपा. अचानक उठून उभे राहू नका. छातीत दुखत असल्यास लगेच दवाखान्यात जा.";
                    case "ur": return "فوراً پاؤں 12 انچ اونچے کر کے لیٹ جائیں۔ اچانک اٹھ کر کھڑے ہونے سے گریز کریں۔ اگر سینے میں درد ہو تو فوری ایمرجنسی میں جائیں۔";
                    case "ar": return "استلقِ فوراً مع رفع القدمين بمقدار 12 بوصة. تجنب الوقوف المفاجئ، وإذا صاحب ذلك ألم بالصدر فاطلب الإسعاف فوراً.";
                    case "ru": return "Немедленно прилягте, приподняв ноги на 30 см. Избегайте резких подъемов. При боли в груди немедленно вызовите скорую.";
                    case "ja": return "直ちに横になり、足を30センチほど高くしてください。急に立ち上がらないようにし、胸痛がある場合は至急受診してください。";
                    case "ko": return "즉시 다리를 30cm 정도 높인 채 누우세요. 갑자기 일어서지 마시고, 흉통이 동반되면 즉시 응급실로 가세요.";
                    case "zh": return "请立即平卧并将双腿垫高约30厘米以增加脑部供血。避免猛烈起身站立，如伴有胸痛请立即就医。";
                    case "th": return "นอนราบลงทันทีโดยยกขาสูงขึ้น 12 นิ้ว หลีกเลี่ยงการลุกขึ้นยืนกะทันหัน หากเจ็บหน้าอกให้ไปห้องฉุกเฉินทันที";
                    case "es": return "Acuéstese inmediatamente con los pies elevados unos 30 cm. Evite levantarse de golpe. Si hay dolor en el pecho, acuda a urgencias.";
                    case "pt": return "Deite-se imediatamente com as pernas elevadas cerca de 30 cm. Evite levantar-se bruscamente. Se sentir dor no peito, procure socorro.";
                    case "fr": return "Allongez-vous immédiatement jambes surélevées de 30 cm. Évitez les levers brusques. En cas de douleur thoracique, appelez les urgences.";
                    case "de": return "Legen Sie sich sofort hin und lagern Sie die Beine etwa 30 cm hoch. Vermeiden Sie plötzliches Aufstehen; bei Brustschmerz Notruf wählen.";
                    case "it": return "Si sdrai immediatamente con i piedi sollevati di 30 cm. Eviti di alzarsi bruscamente. Se avverte dolore al petto chiami il 118.";
                    default: return "Lie down immediately with feet elevated 12 inches to restore blood flow to the brain. Avoid sudden standing. If accompanied by chest pain or loss of consciousness over 1 minute, seek immediate emergency care.";
                }

            case "GYNECOLOGY_MENSTRUAL_HEALTH_12":
                switch (lang) {
                    case "te": return "హార్మోన్ల పరీక్షలు మరియు పెల్విక్ అల్ట్రాసౌండ్ కోసం స్త్రీ రోగ నిపుణుడిని (గైనకాలజిస్ట్) సంప్రదించండి. వైద్యుని పర్యవేక్షణ లేకుండా మీ ప్రస్తుత మందుల మోతాదులను స్వయంగా మార్చవద్దు. పొత్తికడుపుపై వెచ్చని హీటింగ్ ప్యాడ్ ఉంచి, పుష్కలంగా నీరు త్రాగండి. తీవ్రమైన ఆకస్మిక నొప్పి లేదా అధిక రక్తస్రావం ఉంటే వెంటనే అత్యవసర విభాగానికి వెళ్ళండి.";
                    case "kn": return "ಹಾರ್ಮೋನು ಪರೀಕ್ಷೆ ಮತ್ತು ಪೆಲ್ವಿಕ್ ಅಲ್ಟ್ರಾಸೌಂಡ್‌ಗಾಗಿ ಸ್ತ್ರೀರೋಗ ತಜ್ಞರನ್ನು ಸಂಪರ್ಕಿಸಿ. ವೈದ್ಯರ ಮಾರ್ಗದರ್ಶನವಿಲ್ಲದೆ ಔಷಧಿಗಳ ಪ್ರಮಾಣವನ್ನು ಬದಲಾಯಿಸಬೇಡಿ. ಹೊಟ್ಟೆಯ ಕೆಳಭಾಗದಲ್ಲಿ ಬೆಚ್ಚನೆಯ ಶಾಖ ನೀಡಿ ಮತ್ತು ಸಾಕಷ್ಟು ನೀರು ಕುಡಿಯಿರಿ.";
                    case "hi": return "हार्मोनल प्रोफाइल और पेल्विक अल्ट्रासाउंड के लिए स्त्री रोग विशेषज्ञ (Gynecologist) से परामर्श लें। डॉक्टर की सलाह के बिना अपनी निर्धारित दवाओं की खुराक में स्वयं कोई बदलाव न करें। पेट के निचले हिस्से पर गर्म सेक लगाएं और पर्याप्त पानी पिएं। यदि अचानक असहनीय तेज दर्द या अत्यधिक रक्तस्राव हो, तो तुरंत आपातकालीन चिकित्सा सहायता लें।";
                    case "ta": return "ஹார்மோன் பரிசோதனை மற்றும் இடுப்புப் பகுதி அல்ட்ராசவுண்ட் ஸ்கேன் மேற்கொள்ள பெண்ணோயியல் மருத்துவரை (Gynecologist) அணுகவும். மருத்துவரின் ஆலோசனையின்றி உங்கள் மருந்துகளின் அளவை நீங்களாகவே மாற்ற வேண்டாம். அடிவயிற்றில் வெந்நீர் ஒத்தடம் கொடுக்கவும், நன்கு நீர்ச்சத்து பராமரிக்கவும். திடீர் கடுமையான வலி அல்லது தீவிர ரத்தப்போக்கு ஏற்பட்டால் உடனடியாக அவசர சிகிச்சையை நாடவும்.";
                    case "ml": return "ഹോർമോൺ പരിശോധനകൾക്കും പെൽവിക് അൾട്രാസൗണ്ടിനുമായി ഗൈനക്കോളജിസ്റ്റിനെ കാണുക. ഡോക്ടറുടെ നിർദ്ദേശമില്ലാതെ മരുന്നുകളുടെ അളവ് മാറ്റരുത്. അടിവയറ്റിൽ ചൂട് പിടിക്കുകയും ധാരാളം വെള്ളം കുടിക്കുകയും ചെയ്യുക.";
                    case "bn": return "হরমোন পরীক্ষা এবং পেলভিক আল্ট্রাসাউন্ডের জন্য একজন স্ত্রীরোগ বিশেষজ্ঞের পরামর্শ নিন। ডাক্তারের পরামর্শ ছাড়া ওষুধের ডোজ পরিবর্তন করবেন না। তলপেটে গরম সেঁক দিন এবং প্রচুর জল পান করুন।";
                    case "mr": return "हार्मोनल तपासणी आणि पेल्व्हिक अल्ट्रासाऊंडसाठी स्त्रीरोग तज्ज्ञांचा सल्ला घ्या. डॉक्टरांच्या सल्ल्याशिवाय औषधांमध्ये कोणताही बदल करू नका. पोटाच्या खालच्या भागावर गरम शेक द्या.";
                    case "ur": return "ہارمونل ٹیسٹ اور پیلوک الٹراساؤنڈ کے لیے ماہر امراض نسواں سے رجوع کریں۔ ڈاکٹر کے مشورے کے بغیر ادویات میں خود کوئی تبدیلی نہ کریں۔ نچلے پیٹ پر گرم ٹکور کریں اور پانی زیادہ پئیں۔";
                    case "ar": return "احجزي موعداً مع طبيبة أمراض النساء لإجراء الفحوصات الهرمونية والموجات فوق الصوتية. لا تقومي بتعديل جرعات الأدوية دون إشراف طبي. ضعي كمادات دافئة على أسفل البطن وتناولي السوائل الكافية.";
                    case "ru": return "Запишитесь на прием к гинекологу для гормонального обследования и УЗИ органов малого таза. Не изменяйте дозировки назначенных препаратов самостоятельно. Прикладывайте тепло к низу живота и соблюдайте питьевой режим.";
                    case "ja": return "ホルモン検査や骨盤部超音波検査のため、産婦人科を受診してください。医師の指導なしに自己判断で薬の用量を変更しないでください。下腹部を温め、水分を十分に摂取してください。";
                    case "ko": return "호르몬 검사와 골반 초음파 검사를 위해 산부인과 전문의의 진료를 받으세요. 의사의 지도 없이 처방약을 임의로 조절하거나 중단하지 마세요. 아랫배에 온찜질을 하고 수분을 충분히 섭취하세요.";
                    case "zh": return "请前往妇科就诊以进行内分泌激素六项检查及盆腔B超。切勿在没有医生指导的情况下擅自调整处方药用量。可在下腹部热敷并保持充足水分。";
                    case "th": return "ควรพบสูตินรีแพทย์เพื่อตรวจระดับฮอร์โมนและอัลตราซาวด์อุ้งเชิงกราน ห้ามปรับขนาดยาตามใบสั่งแพทย์ด้วยตนเอง ประคบอุ่นที่ท้องน้อยและดื่มน้ำให้เพียงพอ";
                    case "es": return "Programe una consulta con un ginecólogo para evaluación hormonal y ecografía pélvica. No ajuste sus medicamentos recetados sin supervisión médica. Aplique calor local y mantenga una buena hidratación.";
                    case "pt": return "Agende consulta com um ginecologista para avaliação hormonal e ultrassonografia pélvica. Não altere dosagens de medicamentos prescritos por conta própria. Utilize compressa morna no baixo ventre.";
                    case "fr": return "Consultez un gynécologue pour un bilan hormonal et une échographie pelvienne. N'ajustez pas vos médicaments sans avis médical. Appliquez une bouillotte tiède sur le bas-ventre et hydratez-vous bien.";
                    case "de": return "Konsultieren Sie einen Gynäkologen zur Hormondiagnostik und Ultraschalluntersuchung. Passen Sie verschreibungspflichtige Medikamente nicht eigenmächtig an. Nutzen Sie eine Wärmflasche und trinken Sie ausreichend.";
                    case "it": return "Prenoti una visita ginecologica per un profilo ormonale ed ecografia pelvica. Non modifichi il dosaggio dei farmaci senza consultare il medico. Applichi una borsa dell'acqua calda sull'addome.";
                    default: return "Schedule an outpatient consultation with a licensed Obstetrician-Gynecologist for hormonal evaluation (thyroid, LH/FSH, prolactin) and a pelvic ultrasound. Do NOT self-adjust or stop prescribed medications without physician guidance. Apply a warm heating pad to the lower abdomen, stay well hydrated, and consume anti-inflammatory foods (ginger, turmeric). Seek immediate emergency medical care if you experience unbearable sudden sharp pelvic pain, heavy hemorrhaging (soaking more than one pad per hour), or dizziness/fainting.";
                }

            case "CLINICAL_FOLLOWUP_REQUIRED_11":
            default:
                switch (lang) {
                    case "te": return "మీ లక్షణాల గురించి మరింత వివరమైన సమాచారం అవసరం. ఈ అసౌకర్యం ఎన్ని రోజులుగా ఉంది, శ్వాస తీసుకోవడంలో ఇబ్బంది, జ్వరం లేదా తలతిరగడం ఉన్నాయా అని వివరంగా తెలపండి.";
                    case "kn": return "ನಿಮ್ಮ ರೋಗಲಕ್ಷಣಗಳ ಬಗ್ಗೆ ಹೆಚ್ಚಿನ ವಿವರಗಳು ಬೇಕಾಗುತ್ತವೆ. ಈ ತೊಂದರೆ ಎಷ್ಟು ದಿನಗಳಿಂದ ಇದೆ, ಉಸಿರಾಟದ ತೊಂದರೆ, ಜ್ವರ ಅಥವಾ ತಲೆತಿರುಗುವಿಕೆ ಇದೆಯೇ ಎಂಬುದನ್ನು ದಯವಿಟ್ಟು ವಿವರಿಸಿ.";
                    case "hi": return "आपके लक्षणों के बारे में अधिक विवरण की आवश्यकता है। कृपया बताएं कि यह समस्या कितने दिनों से है, क्या सांस लेने में तकलीफ, बुखार या चक्कर आ रहे हैं?";
                    case "ta": return "உங்கள் அறிகுறிகள் குறித்து மேலும் விரிவான விவரங்கள் தேவை. இந்த அசௌகரியம் எத்தனை நாட்களாக உள்ளது, மூச்சுத்திணறல், காய்ச்சல் அல்லது மயக்கம் உள்ளதா என்பதை விவரிக்கவும்.";
                    case "ml": return "നിങ്ങളുടെ ലക്ഷണങ്ങളെക്കുറിച്ച് കൂടുതൽ വിവരങ്ങൾ ആവശ്യമുണ്ട്. എത്ര ദിവസമായി ഈ ബുദ്ധിമുട്ട് അനുഭവപ്പെടുന്നു എന്ന് വിശദീകരിക്കാമോ?";
                    case "bn": return "আপনার লক্ষণগুলি সম্পর্কে আরও তথ্যের প্রয়োজন। এই অস্বস্তি কতদিন ধরে আছে এবং শ্বাসকষ্ট বা জ্বর আছে কি না তা বিশদভাবে জানান।";
                    case "mr": return "तुमच्या लक्षणांबद्दल अधिक माहिती आवश्यक आहे. हा त्रास किती दिवसांपासून आहे, धाप लागणे, ताप किंवा चक्कर येत आहे का ते सांगा.";
                    case "ur": return "آپ کی علامات کے بارے میں مزید تفصیلات درکار ہیں۔ یہ تکلیف کتنے دنوں سے ہے اور کیا سانس لینے میں دشواری یا بخار ہے؟";
                    case "ar": return "تتطلب أعراضك سياقاً أكثر تفصيلاً. يُرجى وصف مدة استمرار هذا الانزعاج وما إذا كان يصاحبه ضيق في التنفس أو حمى.";
                    case "ru": return "Для точной оценки необходимо больше информации. Опишите, как давно появились симптомы, есть ли одышка, температура или головокружение.";
                    case "ja": return "症状についてより詳細な情報が必要です。この不快感がいつから続いているか、呼吸困難や発熱、めまいがあるかお知らせください。";
                    case "ko": return "증상에 대한 더 자세한 설명이 필요합니다. 증상이 언제부터 시작되었는지, 호흡 곤란이나 발열, 어지럼증이 동반되는지 알려주세요.";
                    case "zh": return "评估您的病情需要补充更详细的症状描述。请说明不适已持续多久、是否加重，以及是否伴有呼吸困难、发热或眩晕。";
                    case "th": return "ต้องการข้อมูลอาการเพิ่มเติม โปรดระบุว่ามีอาการมานานกี่วันแล้ว มีอาการหายใจลำบาก มีไข้ หรือวิงเวียนศีรษะร่วมด้วยหรือไม่";
                    case "es": return "Sus síntomas requieren más contexto. Por favor describa cuánto tiempo ha tenido esta molestia y si tiene dificultad para respirar o fiebre.";
                    case "pt": return "Seus sintomas necessitam de mais informações. Descreva há quantos dias sente esse desconforto e se há febre ou falta de ar associada.";
                    case "fr": return "Vos symptômes nécessitent des précisions. Depuis quand ressentez-vous cette gêne et présentez-vous de la fièvre ou un essoufflement ?";
                    case "de": return "Ihre Symptome erfordern genauere Angaben. Bitte beschreiben Sie, seit wann die Beschwerden bestehen und ob Atemnot oder Fieber vorliegt.";
                    case "it": return "I suoi sintomi richiedono maggiori dettagli. Da quanti giorni avverte questo disturbo e ha difficoltà a respirare o febbre?";
                    default: return "Your symptoms require more detailed context. Could you describe how long you have had this discomfort, whether it is worsening, and if you have any difficulty breathing, fever, or dizziness?";
                }
        }
    }

    public String getReason(String ruleId, String language) {
        String lang = normalizeLang(language);
        switch (ruleId) {
            case "CARDIAC_EMERGENCY_PROTOCOL_01":
                switch (lang) {
                    case "te": return "ఛాతీ నొప్పితో పాటు శ్వాస తీసుకోవడంలో ఇబ్బంది లేదా చేతి నొప్పి ఉండటం తీవ్ర గుండెపోటు ప్రమాదాన్ని సూచిస్తుంది. తక్షణ అత్యవసర వైద్యం అవసరం.";
                    case "kn": return "ಎದೆ ನೋವಿನೊಂದಿಗೆ ಉಸಿರಾಟದ ತೊಂದರೆ ಅಥವಾ ಕೈ ನೋವು ತೀವ್ರ ಹೃದಯಾಘಾತದ ಅಪಾಯವನ್ನು ಸೂಚಿಸುತ್ತದೆ. ತುರ್ತು ಚಿಕಿತ್ಸೆ ಅಗತ್ಯ.";
                    case "hi": return "सीने में दर्द के साथ सांस लेने में तकलीफ या बांह में दर्द गंभीर दिल के दौरे का संकेत देता है। तत्काल आपातकालीन देखभाल आवश्यक है।";
                    case "ta": return "மார்பு வலியுடன் மூச்சுத்திணறல் அல்லது கை வலி இருப்பது கடுமையான மாரடைப்பு அபாயத்தைக் குறிக்கிறது.";
                    case "ml": return "നെഞ്ചുവേദനയും ശ്വാസതടസ്സവും ഗുരുതരമായ ഹൃദയാഘാത സാധ്യതയെ സൂചിപ്പിക്കുന്നു.";
                    case "bn": return "বুকে ব্যথার সাথে শ্বাসকষ্ট মারাত্মক হার্ট অ্যাটাকের ঝুঁকি নির্দেশ করে।";
                    case "mr": return "छातीत दुखण्यासोबत धाप लागणे गंभीर हृदयविकाराचा झटका दर्शवते.";
                    case "ur": return "سینے میں درد کے ساتھ سانس کی تکلیف شدید ہارٹ اٹیک کے خطرے کی علامت ہے۔";
                    case "ar": return "ألم الصدر المصحوب بضيق التنفس يشير إلى احتمالية عالية لمتلازمة الشريان التاجي الحادة.";
                    case "ru": return "Боль в груди в сочетании с одышкой указывает на высокий риск острого коронарного синдрома (инфаркта миокарда).";
                    case "ja": return "胸痛に伴う呼吸困難や放散痛は、急性冠症候群（心筋梗塞）の強い疑いを示しています。";
                    case "ko": return "호흡 곤란이나 방사통을 동반한 흉통은 급성 관상동맥 증후군(심근경색)의 위험성을 시사합니다.";
                    case "zh": return "胸痛伴随呼吸困难或放射痛高度提示急性冠脉综合征（心肌梗死）发作，必须争分夺秒抢救。";
                    case "th": return "อาการเจ็บหน้าอกร่วมกับหายใจลำบากบ่งบอกถึงภาวะหลอดเลือดหัวใจเฉียบพลันที่มีความเสี่ยงสูง";
                    case "es": return "El dolor de pecho con dificultad respiratoria o irradiación activa el protocolo de infarto agudo de miocardio.";
                    case "pt": return "A dor torácica combinada com falta de ar ou irradiação indica alta probabilidade de infarto agudo do miocárdio.";
                    case "fr": return "La douleur thoracique associée à une détresse respiratoire déclenche le protocole de syndrome coronarien aigu.";
                    case "de": return "Brustschmerz mit Atemnot löst ein Notfallprotokoll für ein akutes Koronarsyndrom (Herzinfarkt) aus.";
                    case "it": return "Il dolore toracico con dispnea o irradiazione indica un forte rischio di sindrome coronarica acuta.";
                    default: return "Symptom combination (Chest pain with respiratory distress / radiation / acute presentation) triggers high-probability Acute Coronary Syndrome (Myocardial Infarction) protocol.";
                }

            case "NEURO_FAST_EMERGENCY_02":
                switch (lang) {
                    case "te": return "ముఖం వంకరపోవడం మరియు మాట తడబడటం తీవ్ర పక్షవాతాన్ని సూచిస్తాయి. తక్షణ అత్యవసర వైద్యం అవసరం.";
                    case "kn": return "ಮುಖದ ಬಾಗುವಿಕೆ ಮತ್ತು ಮಾತಿನ ತಡವರಿಸುವಿಕೆ ತೀವ್ರ ಪಾರ್ಶ್ವವಾಯುವಿನ ಲಕ್ಷಣವಾಗಿದೆ. ತುರ್ತು ಚಿಕಿತ್ಸೆ ಅಗತ್ಯವಿದೆ.";
                    case "hi": return "चेहरे का टेढ़ापन और बोलने में लड़खड़ाहट तीव्र आघात (स्ट्रोक) का संकेत देती है। तत्काल आपातकालीन देखभाल आवश्यक है।";
                    case "ta": return "முகக் கோணல் மற்றும் பேச்சு தடுமாற்றம் கடுமையான பக்கவாதத்தைக் குறிக்கிறது. உடனடி அவசர சிகிச்சை தேவை.";
                    default: return "Symptoms match acute cerebrovascular accident (Stroke / Hemorrhage) or subarachnoid hemorrhage. Immediate thrombolysis or neurosurgical assessment required within the golden window.";
                }

            case "GI_BLEED_ACUTE_ABDOMEN_03":
                switch (lang) {
                    case "te": return "జీర్ణకోశ రక్తస్రావం లేదా తీవ్రమైన కడుపు నొప్పి లక్షణాలు ఉన్నాయి. తక్షణ వైద్య పరీక్ష అవసరం.";
                    case "kn": return "ಜಠರಗರುಳಿನ ರಕ್ತಸ್ರಾವ ಅಥವಾ ತೀವ್ರ ಹೊಟ್ಟೆಯ ನೋವಿನ ಲಕ್ಷಣಗಳಿವೆ. ತುರ್ತು ವೈದ್ಯಕೀಯ ತಪಾಸಣೆ ಅಗತ್ಯವಿದೆ.";
                    case "hi": return "गैस्ट्रोइंटेस्टाइनल रक्तस्राव या तीव्र पेट की समस्या के लक्षण हैं। तत्काल चिकित्सा मूल्यांकन की आवश्यकता है।";
                    case "ta": return "இரைப்பை இரத்தப்போக்கு அல்லது கடுமையான வயிற்று பாதிப்புக்கான அறிகுறிகள் உள்ளன. உடனடி மருத்துவ பரிசோதனை தேவை.";
                    default: return "Potential gastrointestinal hemorrhage or acute peritonitis requiring urgent hemodynamic stabilization and surgical evaluation.";
                }

            case "ANAPHYLAXIS_EMERGENCY_04":
                switch (lang) {
                    case "te": return "శ్వాస మార్గాన్ని అడ్డుకునే తీవ్రమైన అలర్జీ ప్రతిస్పందన. తక్షణ అత్యవసర సహాయం అవసరం.";
                    case "kn": return "ಉಸಿರಾಟದ ನಾಳವನ್ನು ನಿರ್ಬಂಧಿಸುವ ತೀವ್ರ ಅಲರ್ಜಿ. ತಕ್ಷಣದ ತುರ್ತು ಚಿಕಿತ್ಸೆ ಅಗತ್ಯ.";
                    case "hi": return "श्वसन मार्ग को अवरुद्ध करने वाली गंभीर एलर्जी प्रतिक्रिया। तत्काल आपातकालीन उपचार की आवश्यकता है।";
                    case "ta": return "சுவாசப் பாதையை அடைக்கும் தீவிர ஒவ்வாமை நிலை. உடனடி அவசர சிகிச்சை தேவைப்படுகிறது.";
                    default: return "Rapid-onset systemic anaphylaxis with upper/lower airway compromise.";
                }

            case "ORTHOPEDIC_FRACTURE_TRAUMA_07":
                switch (lang) {
                    case "te": return "మెట్లపై నుంచి పడిపోవడం వల్ల మోకాలికి తీవ్ర గాయం, ఎముక పగులు మరియు అంతర్గత నొప్పి సంభవించాయి. దీనికి తక్షణ ఎక్స్-రే, కదల్చకుండా ఉంచడం మరియు ఆర్థోపెడిక్ పరీక్ష అవసరం.";
                    case "kn": return "ಮೆಟ್ಟಿಲುಗಳಿಂದ ಬಿದ್ದಿದ್ದರಿಂದ ಮೊಣಕಾಲಿಗೆ ತೀವ್ರ ಪೆಟ್ಟು, ಮೂಳೆ ಮುರಿತ ಮತ್ತು ಒಳ ನೋವು ಉಂಟಾಗಿದೆ. ಇದಕ್ಕೆ ತಕ್ಷಣದ ಎಕ್ಸ್-ರೇ ಮತ್ತು ಆರ್ಥೋಪೆಡಿಕ್ ತಪಾಸಣೆ ಅಗತ್ಯವಿದೆ.";
                    case "hi": return "सीढ़ियों से गिरने के कारण घुटने में गंभीर चोट, संदिग्ध हड्डी फ्रैक्चर और तीव्र आंतरिक दर्द है। तत्काल एक्स-रे, स्थिरीकरण और अस्थि रोग विशेषज्ञ की जांच आवश्यक है।";
                    case "ta": return "படியிலிருந்து கீழே விழுந்ததால் முட்டி பகுதியில் பலத்த அடிபட்டு எலும்பு முறிவு, மூட்டு காயம் மற்றும் தீவிர உள் வலி ஏற்பட்டுள்ளது. இதற்கு உடனடி எலும்பியல் பரிசோதனை, எக்ஸ்-ரே மற்றும் அசைக்காமல் கட்டுப்போடுதல் தேவைப்படுகிறது.";
                    case "ml": return "വീഴ്ചയിൽ കാൽമുട്ടിന് പരിക്കേറ്റതും അസ്ഥി ഒടിവ്, ആന്തരിക വേദന എന്നിവ ഉണ്ടായതും അടിയന്തര എക്സ്-റേ പരിശോധനയും പരിചരണവും ആവശ്യപ്പെടുന്നു.";
                    case "bn": return "সিঁড়ি থেকে পড়ে যাওয়ার ফলে হাঁটুতে আঘাত, হাড় ভাঙা এবং অভ্যন্তরীণ তীব্র ব্যথার জন্য জরুরি এক্স-রে ও অর্থোপেডিক পরীক্ষা প্রয়োজন।";
                    case "mr": return "पडल्यामुळे गुडघ्याला झालेली दुखापत, हाड मोडल्याची शंका आणि तीव्र अंतर्गत दुखणे यासाठी त्वरित एक्स-रे आणि तपासणी आवश्यक आहे.";
                    case "ur": return "سیڑھیوں سے گرنے سے گھٹنے کی چوٹ، ہڈی میں فریکچر اور شدید اندرونی درد کے لیے فوری ایکسرے اور آرتھوپیڈک معائنے کی ضرورت ہے۔";
                    case "ar": return "صدمة ناتجة عن السقوط تؤدي إلى اشتباه في كسر بالعظام وإصابة في الركبة مع ألم حاد يتطلب تصويراً إشعاعياً وتثبيتاً فورياً.";
                    case "ru": return "Травма в результате падения с подозрением на перелом кости, травму колена и острую локализованную боль требует срочного рентгенологического обследования и иммобилизации.";
                    case "ja": return "転倒による膝の強打、骨折の疑い、および激しい局所痛のため、至急の画像検査と患部の固定が必要です。";
                    case "ko": return "낙상으로 인한 무릎 부상, 골절 의심 및 급성 통증으로 즉각적인 방사선 촬영 및 깁스 고정이 필요합니다.";
                    case "zh": return "跌倒导致的膝关节钝挫伤、疑似骨折和剧烈内部疼痛，需要紧急放射学影像学检查和骨科固定。";
                    case "th": return "การบาดเจ็บจากการตกบันไดทำให้สงสัยว่ามีกระดูกหัก เจ็บเข่าและปวดมาก จำเป็นต้องตรวจเอกซเรย์และดามกระดูกทันที";
                    case "es": return "Traumatismo por caída con sospecha de fractura ósea, lesión de rodilla y dolor localizado agudo que requiere radiografía e inmovilización ortopédica urgente.";
                    case "pt": return "Trauma por queda com suspeita de fratura óssea, lesão no joelho e dor aguda localizada, exigindo radiografia urgente e imobilização ortopédica.";
                    case "fr": return "Traumatisme suite à une chute avec suspicion de fracture osseuse, lésion du genou et douleur aiguë nécessitant une radiographie urgente et une immobilisation.";
                    case "de": return "Sturzverletzung mit Verdacht auf Knochenfraktur, Knieverletzung und akuten lokalen Schmerzen, die eine sofortige radiologische Bildgebung und Ruhigstellung erfordert.";
                    case "it": return "Trauma da caduta con sospetta frattura ossea, lesione al ginocchio e dolore acuto localizzato che richiede radiografia urgente e immobilizzazione.";
                    default: return "Blunt impact trauma from fall resulting in suspected bone fracture, knee/joint injury, and acute localized pain requiring urgent radiological imaging and orthopedic immobilization.";
                }

            case "RESPIRATORY_INFECTION_MODERATE_05":
                switch (lang) {
                    case "te": return "తీవ్ర జ్వరం మరియు దగ్గు శ్వాసనాళాల ఇన్ఫెక్షన్ లక్షణాలను సూచిస్తాయి. స్టెతస్కోప్ పరీక్ష మరియు వైద్యుల సలహా అవసరం.";
                    case "kn": return "ತೀವ್ರ ಜ್ವರ ಮತ್ತು ಕೆಮ್ಮು ಶ್ವಾಸನಾಳದ ಸೋಂಕಿನ ಸಂಕೇತವಾಗಿದೆ. ವೈದ್ಯಕೀಯ ತಪಾಸಣೆ ಅಗತ್ಯವಿದೆ.";
                    case "hi": return "तेज बुखार और खांसी श्वसन तंत्र के संक्रमण का संकेत देते हैं। चिकित्सीय जांच आवश्यक है।";
                    case "ta": return "அதிக காய்ச்சலுடன் கூடிய சளி இருமல் தீவிர கீழ் சுவாசப் பாதை தொற்றுக்கான அறிகுறிகளைக் காட்டுகிறது.";
                    default: return "Symptoms indicate acute lower respiratory tract infection (e.g. Bronchitis or Pneumonia) requiring stethoscope auscultation and potential chest radiography.";
                }

            case "GI_DISTRESS_MODERATE_06":
                switch (lang) {
                    case "te": return "తీవ్రమైన కడుపు నొప్పి మరియు వాంతులు డీహైడ్రేషన్ లేదా అపెండిసైటిస్ ప్రమాదాన్ని సూచిస్తాయి. వైద్యుల పరీక్ష అవసరం.";
                    case "kn": return "ತೀವ್ರ ಹೊಟ್ಟೆ ನೋವು ಮತ್ತು ವಾಂತಿ ನಿರ್ಜಲೀಕರಣ ಅಥವಾ ಅಪೆಂಡಿಸೈಟಿಸ್ ಅಪಾಯವನ್ನು ಸೂಚಿಸುತ್ತದೆ.";
                    case "hi": return "लगातार पेट दर्द और उल्टी डिहाइड्रेशन या अपेंडिसाइटिस का जोखिम पैदा कर सकते हैं।";
                    case "ta": return "தீவிர இரைப்பை அழற்சி அல்லது குடல்வால் அழற்சி அபாயம் உள்ளதால் மருத்துவ பரிசோதனை தேவை.";
                    default: return "Acute gastrointestinal inflammation or early appendicitis risk requiring physician palpation and hydration assessment.";
                }

            case "ORTHO_SPRAIN_MODERATE_07":
                switch (lang) {
                    case "te": return "తీవ్రమైన బెణుకు మరియు నడవలేకపోవడం స్నాయువు తెగిపోవడం లేదా ఎముక చీలికను సూచిస్తాయి. ఎక్స్-రే పరీక్ష అవసరం.";
                    case "kn": return "ಕೀಲು ಉಳುಕು ಮತ್ತು ನಡೆಯಲಾಗದಿರುವುದು ಲಿಗಮೆಂಟ್ ಹರಿತ ಅಥವಾ ಮೂಳೆ ಬಿರುಕನ್ನು ಸೂಚಿಸುತ್ತದೆ.";
                    case "hi": return "जोड़ में गंभीर मोच और चलने में असमर्थता लिगामेंट क्षति या फ्रैक्चर का संकेत हो सकती है।";
                    case "ta": return "மூட்டு உளுக்கு மற்றும் வீக்கம் ஏற்பட்டுள்ளதால் தசைநார் கிழிவு அல்லது எலும்பு விரிசலை எக்ஸ்-ரே மூலம் சரிபார்க்க வேண்டும்.";
                    default: return "Significant joint trauma with functional weight-bearing limitation requiring radiological diagnostic imaging.";
                }

            case "VIRAL_UPPER_RESPIRATORY_SELFCARE_08":
                switch (lang) {
                    case "te": return "తేలికపాటి జలుబు మరియు దగ్గు సాధారణ వైరల్ ఇన్ఫెక్షన్ సంకేతాలు. ప్రమాదకర లక్షణాలు లేనందున ఇంటి వద్ద స్వీయ సంరక్షణ సరిపోతుంది.";
                    case "kn": return "ಸೌಮ್ಯ ಶೀತ ಮತ್ತು ಕೆಮ್ಮು ಸಾಮಾನ್ಯ ವೈರಲ್ ಸೋಂಕಿನ ಲಕ್ಷಣವಾಗಿದೆ. ಮನೆಯಲ್ಲೇ ಸ್ವಯಂ ಆರೈಕೆ ಸಾಕು.";
                    case "hi": return "हल्की खांसी और सामान्य जुकाम वायरल संक्रमण है। कोई खतरे के लक्षण न होने के कारण घरेलू देखभाल उपयुक्त है।";
                    case "ta": return "லேசான சளி இருமல் சாதாரண வைரஸ் தொற்றாகும். ஆபத்தான அறிகுறிகள் இல்லை என்பதால் வீட்டு சுய பராமரிப்பு போதுமானது.";
                    default: return "Isolated mild cough or low-grade viral illness with no red flag indicators. Suitable for home conservative management.";
                }

            case "MINOR_WOUND_SELFCARE_09":
                switch (lang) {
                    case "te": return "ఉపరితల చిన్న గాయం; తీవ్రమైన రక్తస్రావం లేనందున ప్రథమ చికిత్స మరియు ఇంటి సంరక్షణ సరిపోతుంది.";
                    case "kn": return "ಮೇಲ್ಮೈ ಸಣ್ಣ ಗಾಯ; ಯಾವುದೇ ಗಂಭೀರ ಅಪಾಯವಿಲ್ಲದ್ದರಿಂದ ಪ್ರಥಮ ಚಿಕಿತ್ಸೆ ಮತ್ತು ಮನೆ ಆರೈಕೆ ಸೂಕ್ತವಾಗಿದೆ.";
                    case "hi": return "सतही चोट या मामूली जलन; कोई गंभीर खतरा न होने से घरेलू प्राथमिक उपचार पर्याप्त है।";
                    case "ta": return "மேலோட்டமான காயம்; எவ்வித தீவிர ஆபத்துகளும் இல்லை என்பதால் முதலுதவி மற்றும் வீட்டுப் பராமரிப்பு போதுமானது.";
                    default: return "Superficial skin injury without signs of arterial bleeding or extensive tissue loss.";
                }

            case "SYNCOPE_DIZZINESS_PROTOCOL_10":
                switch (lang) {
                    case "te": return "తలతిరగడం మరియు స్పృహ తప్పడం రక్తపోటు లేదా నరాల సంబంధిత సమస్యలను సూచిస్తాయి. వైద్య పరీక్ష అవసరం.";
                    case "kn": return "ತಲೆತಿರುಗುವಿಕೆ ಮತ್ತು ಮೂರ್ಛೆ ರಕ್ತದೊತ್ತಡ ಅಥವಾ ನರ ಸಂಬಂಧಿ ತಪಾಸಣೆಯನ್ನು ಬಯಸುತ್ತದೆ.";
                    case "hi": return "चक्कर आना और बेहोशी रक्तचाप या न्यूरोलॉजिकल मूल्यांकन की आवश्यकता दर्शाते हैं।";
                    case "ta": return "மயக்கம் மற்றும் தலைச்சுற்றல் இரத்த அழுத்தம் அல்லது நரம்பியல் பரிசோதனை தேவை என்பதை உணர்த்துகிறது.";
                    default: return "Reported syncope or acute dizziness episode requiring clinical blood pressure and neurological evaluation.";
                }

            case "GYNECOLOGY_MENSTRUAL_HEALTH_12":
                switch (lang) {
                    case "te": return "క్రమరహిత పీరియడ్స్ మరియు తీవ్రమైన రుతుక్రమ నొప్పికి PCOS, హార్మోన్ల అసమతుల్యత లేదా ఎండోమెట్రియోసిస్ వంటి కారణాలను నిర్ధారించడానికి మరియు సురక్షితమైన ఔషధ సమీక్ష కోసం గైనకాలజిస్ట్ మూల్యాంకనం అవసరం.";
                    case "kn": return "ಅನಿಯಮಿತ ಮುಟ್ಟು ಮತ್ತು ತೀವ್ರ ಮುಟ್ಟಿನ ನೋವಿಗೆ ಹಾರ್ಮೋನ್ ಅಸಮತೋಲನ ಅಥವಾ ಪಿಸಿಓಎಸ್ ಕಾರಣಗಳನ್ನು ಪತ್ತೆಹಚ್ಚಲು ಸ್ತ್ರೀರೋಗ ತಜ್ಞರ ತಪಾಸಣೆ ಅತ್ಯಗತ್ಯ.";
                    case "hi": return "अनियमित माहवारी और गंभीर मासिक दर्द के लिए पीसीओएस (PCOS), हार्मोनल असंतुलन या एंडोमेट्रियोसिस जैसे कारणों का पता लगाने और दवाओं की सुरक्षित समीक्षा के लिए स्त्री रोग विशेषज्ञ की जांच आवश्यक है।";
                    case "ta": return "ஒழுங்கற்ற மாதவிடாய் மற்றும் கடுமையான வயிற்று வலிக்கு பிசிஓஎஸ் (PCOS) அல்லது ஹார்மோன் சமநிலையின்மை காரணங்களை கண்டறியவும், பாதுகாப்பான மருந்து ஆலோசனையைப் பெறவும் மகளிர் மருத்துவ பரிசோதனை அவசியமாகும்.";
                    case "ml": return "ക്രമരഹിതമായ ആർത്തവവും കഠിനമായ ആർത്തവ വേദനയും ഹോർമോൺ അസന്തുലിതാവസ്ഥ അല്ലെങ്കിൽ പി.സി.ഒ.എസ് സാധ്യതകൾ പരിശോധിക്കാൻ ഗൈനക്കോളജിക്കൽ പരിശോധന ആവശ്യപ്പെടുന്നു.";
                    case "bn": return "অনিয়মিত মাসিক এবং তীব্র মাসিকের ব্যথার কারণ যেমন পিসিওএস বা হরমোনজনিত ভারসাম্যহীনতা নির্ধারণে এবং ওষুধের নিরাপদ পর্যালোচনার জন্য স্ত্রীরোগ বিশেষজ্ঞের পরামর্শ প্রয়োজন।";
                    case "mr": return "अनियमित मासिक पाळी आणि तीव्र पोटदुखीसाठी पीसीओएस किंवा हार्मोनल असंतुलन तपासण्यासाठी स्त्रीरोग तज्ज्ञांचे मूल्यांकन आवश्यक आहे.";
                    case "ur": return "بے قاعدہ ماہواری اور شدید درد کے لیے ہارمونل عدم توازن یا پی سی او ایس کے امکانات کو جانچنے کے لیے گائناکالوجسٹ سے معائنہ ضروری ہے۔";
                    case "ar": return "تستدعي الدورات الشهرية غير المنتظمة والتقلصات الشديدة تقييماً طبياً لاستبعاد تكيس المبايض أو الاضطرابات الهرمونية وضمان سلامة الأدوية.";
                    case "ru": return "Нерегулярный цикл и сильные менструальные боли требуют осмотра гинеколога для исключения СПКЯ, эндометриоза и безопасной коррекции терапии.";
                    case "ja": return "月経不順と強い生理痛は、PCOS（多嚢胞性卵巣症候群）やホルモンバランスの乱れ、子宮内膜症の精査および安全な服薬確認のため受診が必要です。";
                    case "ko": return "불규칙한 생리 주기와 심한 생리통은 다낭성 난소 증후군(PCOS), 호르몬 불균형 확인 및 안전한 약물 조정을 위해 산부인과 진료가 필요합니다.";
                    case "zh": return "月经不调及重度痛经需要妇科全面评估，以排查多囊卵巢综合征（PCOS）或子宫内膜异位症，并确保用药安全调整。";
                    case "th": return "รอบเดือนที่ผิดปกติและอาการปวดประจำเดือนอย่างรุนแรงจำเป็นต้องได้รับการตรวจวินิจฉัยจากสูตินรีแพทย์เพื่อหาสาเหตุของฮอร์โมนไม่สมดุลหรือภาวะ PCOS";
                    case "es": return "Los ciclos irregulares y la dismenorrea severa requieren evaluación ginecológica para descartar SOP o desequilibrios hormonales y revisar la medicación.";
                    case "pt": return "Ciclos irregulares e cólicas intensas exigem avaliação ginecológica para investigar SOP, desequilíbrio hormonal e adequação segura de medicamentos.";
                    case "fr": return "Les cycles irréguliers et les dysménorrhées intenses nécessitent une consultation gynécologique pour éliminer un SOPK et sécuriser les traitements.";
                    case "de": return "Unregelmäßige Zyklen und starke Dysmenorrhö erfordern eine gynäkologische Abklärung bezüglich PCOS, Hormonstörungen und sichere Medikamentenüberprüfung.";
                    case "it": return "I cicli irregolari e la dismenorrea severa richiedono una visita ginecologica per escludere PCOS o squilibri ormonali e verificare la terapia.";
                    default: return "Irregular cycles and severe dysmenorrhea warrant formal gynecological assessment to investigate underlying conditions such as PCOS, hormonal dysregulation, or endometriosis, while ensuring prescription safety.";
                }

            case "CLINICAL_FOLLOWUP_REQUIRED_11":
            default:
                switch (lang) {
                    case "te": return "లక్షణాల సమాచారం ఖచ్చితమైన అత్యవసర స్థాయిని నిర్ణయించడానికి సరిపోలేదు. సురక్షితమైన వైద్య మార్గదర్శకత్వం కోసం అదనపు వివరాలు అవసరం.";
                    case "kn": return "ಸ್ಪಷ್ಟ ವೈದ್ಯಕೀಯ ಮುನ್ಸೂಚನೆ ನಿರ್ಧರಿಸಲು ಹೆಚ್ಚಿನ ವಿವರಗಳ ಅಗತ್ಯವಿದೆ.";
                    case "hi": return "सटीक आपातकालीन स्तर निर्धारित करने के लिए अधिक चिकित्सीय जानकारी की आवश्यकता है।";
                    case "ta": return "வழங்கப்பட்ட தகவல்களில் போதிய தெளிவான மருத்துவக் குறியீடுகள் இல்லை. துல்லியமான வழிகாட்டுதலுக்கு கூடுதல் விவரங்கள் தேவை.";
                    default: return "Input does not contain sufficient specific clinical indicators to confidently categorize urgency. Safe escalation and inquiry initiated.";
                }
        }
    }

    public String localizeSymptom(String symptomName, String language) {
        String lang = normalizeLang(language);
        if ("en".equals(lang)) return symptomName;

        switch (lang) {
            case "te":
                switch (symptomName) {
                    case "Bone Fracture / Suspected Fracture": return "ఎముక పగులు / ఫ్రాక్చర్ (Bone Fracture)";
                    case "Fall / Physical Trauma": return "పడిపోవడం వల్ల గాయం (Fall Trauma)";
                    case "Knee & Lower Limb Injury": return "మోకాలు / కాలు గాయం (Knee Injury)";
                    case "Acute Pain & Internal Discomfort": return "తీవ్రమైన అంతర్గత నొప్పి (Internal Pain)";
                    case "Sprain / Joint Pain": return "కీళ్ల బెణుకు / నొప్పి (Sprain / Joint Pain)";
                    case "Chest Pain": return "ఛాతీ నొప్పి / గుండె నొప్పి (Chest Pain)";
                    case "Shortness of Breath": return "శ్వాస తీసుకోవడంలో ఇబ్బంది (Shortness of Breath)";
                    case "Radiating Arm Pain": return "చేయి నొప్పి (Radiating Arm Pain)";
                    case "Stroke Warning Signs": return "పక్షవాతం హెచ్చరిక సంకేతాలు (Stroke Signs)";
                    case "High Fever": return "తీవ్ర జ్వరం (High Fever)";
                    case "Mild Fever": return "తేలికపాటి జ్వరం (Mild Fever)";
                    case "Severe Headache": return "తీవ్ర తలనొప్పి (Severe Headache)";
                    case "Cough": return "దగ్గు / గొంతు నొప్పి (Cough)";
                    case "Abdominal Pain": return "కడుపు నొప్పి (Abdominal Pain)";
                    case "Vomiting / Diarrhea": return "వాంతులు / విరేచనాలు (Vomiting/Diarrhea)";
                    case "Blood in Stool or Vomit": return "రక్తస్రావం (Internal Bleeding)";
                    case "Cut or Bleeding": return "గాయం / రక్తస్రావం (Cut / Bleeding)";
                    case "Burn": return "కాలిన గాయం (Burn)";
                    case "Dizziness / Fainting": return "తలతిరగడం / స్పృహ తప్పడం (Dizziness/Fainting)";
                    case "Allergic Reaction": return "అలెర్జీ ప్రతిస్పందన (Allergic Reaction)";
                    case "Menstrual Cramps / Dysmenorrhea": return "రుతుక్రమ నొప్పి / పీరియడ్స్ నొప్పి (Menstrual Cramps)";
                    case "Irregular Menstrual Cycle": return "క్రమరహిత పీరియడ్స్ / హార్మోన్ల సమస్య (Irregular Periods)";
                    default: return symptomName;
                }

            case "kn":
                switch (symptomName) {
                    case "Bone Fracture / Suspected Fracture": return "ಮೂಳೆ ಮುರಿತ / ಫ್ರ್ಯಾಕ್ಚರ್ (Bone Fracture)";
                    case "Fall / Physical Trauma": return "ಬಿದ್ದ ಗಾಯ (Fall Trauma)";
                    case "Knee & Lower Limb Injury": return "ಮೊಣಕಾಲು / ಕಾಲು ಗಾಯ (Knee Injury)";
                    case "Acute Pain & Internal Discomfort": return "ತೀವ್ರ ಒಳ ನೋವು (Internal Pain)";
                    case "Sprain / Joint Pain": return "ಕೀಲು ಉಳುಕು / ನೋವು (Sprain / Joint Pain)";
                    case "Chest Pain": return "ಎದೆ ನೋವು (Chest Pain)";
                    case "Shortness of Breath": return "ಉಸಿರಾಟದ ತೊಂದರೆ (Shortness of Breath)";
                    case "Radiating Arm Pain": return "ಕೈ ನೋವು (Radiating Arm Pain)";
                    case "Stroke Warning Signs": return "ಪಾರ್ಶ್ವವಾಯು ಲಕ್ಷಣಗಳು (Stroke Signs)";
                    case "High Fever": return "ತೀವ್ರ ಜ್ವರ (High Fever)";
                    case "Mild Fever": return "ಸೌಮ್ಯ ಜ್ವರ (Mild Fever)";
                    case "Severe Headache": return "ತೀವ್ರ ತಲೆನೋವು (Severe Headache)";
                    case "Cough": return "ಕೆಮ್ಮು (Cough)";
                    case "Abdominal Pain": return "ಹೊಟ್ಟೆ ನೋವು (Abdominal Pain)";
                    case "Vomiting / Diarrhea": return "ವಾಂತಿ / ಭೇದಿ (Vomiting/Diarrhea)";
                    case "Blood in Stool or Vomit": return "ರಕ್ತಸ್ರಾವ (Internal Bleeding)";
                    case "Cut or Bleeding": return "ಗಾಯ / ರಕ್ತಸ್ರಾವ (Cut / Bleeding)";
                    case "Burn": return "ಸುಟ್ಟ ಗಾಯ (Burn)";
                    case "Dizziness / Fainting": return "ತಲೆತಿರುಗುವಿಕೆ / ಮೂರ್ಛೆ (Dizziness/Fainting)";
                    case "Allergic Reaction": return "ಅಲರ್ಜಿ ಪ್ರತಿಕ್ರಿಯೆ (Allergic Reaction)";
                    case "Menstrual Cramps / Dysmenorrhea": return "ಮುಟ್ಟಿನ ನೋವು / ತಿಂಗಳ ನೋವು (Menstrual Cramps)";
                    case "Irregular Menstrual Cycle": return "ಅನಿಯಮಿತ ಮುಟ್ಟು (Irregular Periods)";
                    default: return symptomName;
                }

            case "hi":
                switch (symptomName) {
                    case "Bone Fracture / Suspected Fracture": return "हड्डी टूटना / फ्रैक्चर (Bone Fracture)";
                    case "Fall / Physical Trauma": return "गिरने से चोट (Fall Trauma)";
                    case "Knee & Lower Limb Injury": return "घुटने / पैर की चोट (Knee Injury)";
                    case "Acute Pain & Internal Discomfort": return "तीव्र आंतरिक दर्द (Internal Pain)";
                    case "Sprain / Joint Pain": return "मोच / जोड़ों का दर्द (Sprain / Joint Pain)";
                    case "Chest Pain": return "सीने में दर्द (Chest Pain)";
                    case "Shortness of Breath": return "सांस लेने में तकलीफ (Shortness of Breath)";
                    case "Radiating Arm Pain": return "बांह में दर्द (Radiating Arm Pain)";
                    case "Stroke Warning Signs": return "स्ट्रोक के लक्षण (Stroke Signs)";
                    case "High Fever": return "तेज बुखार (High Fever)";
                    case "Mild Fever": return "हल्का बुखार (Mild Fever)";
                    case "Severe Headache": return "गंभीर सिरदर्द (Severe Headache)";
                    case "Cough": return "खांसी / जुकाम (Cough)";
                    case "Abdominal Pain": return "पेट दर्द (Abdominal Pain)";
                    case "Vomiting / Diarrhea": return "उल्टी / दस्त (Vomiting/Diarrhea)";
                    case "Blood in Stool or Vomit": return "आंतरिक रक्तस्राव (Internal Bleeding)";
                    case "Cut or Bleeding": return "घाव / रक्तस्राव (Cut / Bleeding)";
                    case "Burn": return "जलने की चोट (Burn)";
                    case "Dizziness / Fainting": return "चक्कर / बेहोशी (Dizziness/Fainting)";
                    case "Allergic Reaction": return "एलर्जी की प्रतिक्रिया (Allergic Reaction)";
                    case "Menstrual Cramps / Dysmenorrhea": return "मासिक धर्म दर्द / ऐंठन (Menstrual Cramps)";
                    case "Irregular Menstrual Cycle": return "अनियमित माहवारी (Irregular Periods)";
                    default: return symptomName;
                }

            case "ta":
                switch (symptomName) {
                    case "Bone Fracture / Suspected Fracture": return "எலும்பு முறிவு (Bone Fracture)";
                    case "Fall / Physical Trauma": return "விழுந்த காயம் (Fall Trauma)";
                    case "Knee & Lower Limb Injury": return "முட்டி / கால் காயம் (Knee Injury)";
                    case "Acute Pain & Internal Discomfort": return "உள் வலி & வேதனை (Internal Pain)";
                    case "Sprain / Joint Pain": return "மூட்டு உளுக்கு (Sprain / Joint Pain)";
                    case "Chest Pain": return "நெஞ்சு வலி (Chest Pain)";
                    case "Shortness of Breath": return "மூச்சுத் திணறல் (Shortness of Breath)";
                    case "Radiating Arm Pain": return "கை வலி (Radiating Arm Pain)";
                    case "Stroke Warning Signs": return "பக்கவாத அறிகுறிகள் (Stroke Warning Signs)";
                    case "High Fever": return "அதிக காய்ச்சல் (High Fever)";
                    case "Mild Fever": return "லேசான காய்ச்சல் (Mild Fever)";
                    case "Severe Headache": return "கடுமையான தலைவலி (Severe Headache)";
                    case "Cough": return "இருமல் / சளி (Cough)";
                    case "Abdominal Pain": return "வயிறு வலி (Abdominal Pain)";
                    case "Vomiting / Diarrhea": return "வாந்தி / வயிற்றுப்போக்கு (Vomiting/Diarrhea)";
                    case "Blood in Stool or Vomit": return "இரத்தப்போக்கு (Internal Bleeding)";
                    case "Cut or Bleeding": return "வெட்டுக் காயம் (Cut / Bleeding)";
                    case "Burn": return "தீக்காயம் (Burn)";
                    case "Dizziness / Fainting": return "மயக்கம் / தலைச்சுற்றல் (Dizziness/Fainting)";
                    case "Allergic Reaction": return "ஒவ்வாமை (Allergic Reaction)";
                    case "Menstrual Cramps / Dysmenorrhea": return "மாதவிடாய் வலி / அடிவயிற்று பிடிப்பு (Menstrual Cramps)";
                    case "Irregular Menstrual Cycle": return "ஒழுங்கற்ற மாதவிடாய் சுழற்சி (Irregular Periods)";
                    default: return symptomName;
                }

            case "ml":
                switch (symptomName) {
                    case "Bone Fracture / Suspected Fracture": return "അസ്ഥി ഒടിവ് (Bone Fracture)";
                    case "Fall / Physical Trauma": return "വീഴ്ചയിലെ പരിക്ക് (Fall Trauma)";
                    case "Knee & Lower Limb Injury": return "കാൽമുട്ട് പരിക്ക് (Knee Injury)";
                    case "Acute Pain & Internal Discomfort": return "ആന്തരിക വേദന (Internal Pain)";
                    case "Sprain / Joint Pain": return "ഉളുക്ക് / സന്ധി വേദന (Sprain / Joint Pain)";
                    case "Chest Pain": return "നെഞ്ചുവേദന (Chest Pain)";
                    case "Shortness of Breath": return "ശ്വാസതടസ്സം (Shortness of Breath)";
                    case "Menstrual Cramps / Dysmenorrhea": return "ആർത്തവ വേദന (Menstrual Cramps)";
                    case "Irregular Menstrual Cycle": return "ക്രമരഹിതമായ ആർത്തവം (Irregular Periods)";
                    default: return symptomName;
                }

            case "es":
                switch (symptomName) {
                    case "Bone Fracture / Suspected Fracture": return "Fractura ósea sospechada (Bone Fracture)";
                    case "Fall / Physical Trauma": return "Trauma por caída (Fall Trauma)";
                    case "Knee & Lower Limb Injury": return "Lesión de rodilla y pierna (Knee Injury)";
                    case "Acute Pain & Internal Discomfort": return "Dolor agudo interno (Internal Pain)";
                    case "Sprain / Joint Pain": return "Esguince / Dolor articular (Sprain / Joint Pain)";
                    case "Chest Pain": return "Dolor de pecho (Chest Pain)";
                    case "Shortness of Breath": return "Dificultad para respirar (Shortness of Breath)";
                    case "Menstrual Cramps / Dysmenorrhea": return "Cólicos menstruales / Dismenorrea (Menstrual Cramps)";
                    case "Irregular Menstrual Cycle": return "Ciclo menstrual irregular (Irregular Periods)";
                    default: return symptomName;
                }

            case "fr":
                switch (symptomName) {
                    case "Bone Fracture / Suspected Fracture": return "Fracture osseuse suspectée (Bone Fracture)";
                    case "Fall / Physical Trauma": return "Traumatisme suite à une chute (Fall Trauma)";
                    case "Knee & Lower Limb Injury": return "Lésion du genou et membre inférieur (Knee Injury)";
                    case "Acute Pain & Internal Discomfort": return "Douleur aiguë interne (Internal Pain)";
                    case "Sprain / Joint Pain": return "Entorse / Douleur articulaire (Sprain / Joint Pain)";
                    case "Chest Pain": return "Douleur thoracique (Chest Pain)";
                    case "Shortness of Breath": return "Difficulté à respirer (Shortness of Breath)";
                    case "Menstrual Cramps / Dysmenorrhea": return "Crampes menstruelles / Douleurs de règles (Menstrual Cramps)";
                    case "Irregular Menstrual Cycle": return "Règles irrégulières (Irregular Periods)";
                    default: return symptomName;
                }

            case "de":
                switch (symptomName) {
                    case "Bone Fracture / Suspected Fracture": return "Verdacht auf Knochenfraktur (Bone Fracture)";
                    case "Fall / Physical Trauma": return "Sturztrauma (Fall Trauma)";
                    case "Knee & Lower Limb Injury": return "Knie- und Beinverletzung (Knee Injury)";
                    case "Acute Pain & Internal Discomfort": return "Akuter innerer Schmerz (Internal Pain)";
                    case "Sprain / Joint Pain": return "Verstauchung / Gelenkschmerz (Sprain / Joint Pain)";
                    case "Chest Pain": return "Brustschmerzen (Chest Pain)";
                    case "Shortness of Breath": return "Atemnot (Shortness of Breath)";
                    case "Menstrual Cramps / Dysmenorrhea": return "Regelschmerzen / Menstruationsbeschwerden (Menstrual Cramps)";
                    case "Irregular Menstrual Cycle": return "Unregelmäßige Periode (Irregular Periods)";
                    default: return symptomName;
                }

            default:
                return symptomName;
        }
    }

    private String normalizeLang(String language) {
        if (language == null || language.trim().isEmpty() || "auto".equalsIgnoreCase(language)) {
            return "en";
        }
        return language.trim().toLowerCase();
    }
}
