package com.medvoiceassistant.service;

import java.util.*;

public class LanguageService {

    public static class SupportedLanguage {
        public String code;
        public String name;
        public String nativeName;

        public SupportedLanguage(String code, String name, String nativeName) {
            this.code = code;
            this.name = name;
            this.nativeName = nativeName;
        }
    }

    public List<SupportedLanguage> getSupportedLanguages() {
        List<SupportedLanguage> list = new ArrayList<>();
        list.add(new SupportedLanguage("en", "English", "English"));
        list.add(new SupportedLanguage("ta", "Tamil", "தமிழ்"));
        list.add(new SupportedLanguage("hi", "Hindi", "हिन्दी"));
        list.add(new SupportedLanguage("te", "Telugu", "తెలుగు"));
        list.add(new SupportedLanguage("kn", "Kannada", "ಕನ್ನಡ"));
        list.add(new SupportedLanguage("ml", "Malayalam", "മലയാളം"));
        list.add(new SupportedLanguage("bn", "Bengali", "বাংলা"));
        list.add(new SupportedLanguage("mr", "Marathi", "मराठी"));
        list.add(new SupportedLanguage("ur", "Urdu", "اردو"));
        list.add(new SupportedLanguage("ar", "Arabic", "العربية"));
        list.add(new SupportedLanguage("ru", "Russian", "Русский"));
        list.add(new SupportedLanguage("ja", "Japanese", "日本語"));
        list.add(new SupportedLanguage("ko", "Korean", "한국어"));
        list.add(new SupportedLanguage("zh", "Chinese", "中文"));
        list.add(new SupportedLanguage("th", "Thai", "ไทย"));
        list.add(new SupportedLanguage("es", "Spanish", "Español"));
        list.add(new SupportedLanguage("pt", "Portuguese", "Português"));
        list.add(new SupportedLanguage("fr", "French", "Français"));
        list.add(new SupportedLanguage("de", "German", "Deutsch"));
        list.add(new SupportedLanguage("it", "Italian", "Italiano"));
        return list;
    }

    public String detectLanguage(String text) {
        if (text == null || text.trim().isEmpty()) {
            return "en";
        }

        boolean hasTamil = false;
        boolean hasDevanagari = false;
        boolean hasTelugu = false;
        boolean hasKannada = false;
        boolean hasMalayalam = false;
        boolean hasBengali = false;
        boolean hasCyrillic = false;
        boolean hasHangul = false;
        boolean hasKana = false;
        boolean hasCJK = false;
        boolean hasThai = false;
        boolean hasArabic = false;
        boolean hasUrduSpecific = false;

        // Check Unicode Blocks for Non-Latin Scripts
        for (char c : text.toCharArray()) {
            if (c >= '\u0B80' && c <= '\u0BFF') hasTamil = true;
            else if (c >= '\u0900' && c <= '\u097F') hasDevanagari = true;
            else if (c >= '\u0980' && c <= '\u09FF') hasBengali = true;
            else if (c >= '\u0C00' && c <= '\u0C7F') hasTelugu = true;
            else if (c >= '\u0C80' && c <= '\u0CFF') hasKannada = true;
            else if (c >= '\u0D00' && c <= '\u0D7F') hasMalayalam = true;
            else if (c >= '\u0400' && c <= '\u04FF') hasCyrillic = true;
            else if ((c >= '\uAC00' && c <= '\uD7AF') || (c >= '\u1100' && c <= '\u11FF')) hasHangul = true;
            else if ((c >= '\u3040' && c <= '\u309F') || (c >= '\u30A0' && c <= '\u30FF')) hasKana = true;
            else if (c >= '\u4E00' && c <= '\u9FFF') hasCJK = true;
            else if (c >= '\u0E00' && c <= '\u0E7F') hasThai = true;
            else if (c >= '\u0600' && c <= '\u06FF') {
                hasArabic = true;
                if (c == '\u0679' || c == '\u0688' || c == '\u0691' || c == '\u06BA' || c == '\u06D2' || c == '\u06C1' || c == '\u06AF') {
                    hasUrduSpecific = true;
                }
            }
        }

        if (hasTamil) return "ta";
        if (hasTelugu) return "te";
        if (hasKannada) return "kn";
        if (hasMalayalam) return "ml";
        if (hasBengali) return "bn";
        if (hasCyrillic) return "ru";
        if (hasHangul) return "ko";
        if (hasKana) return "ja";
        if (hasThai) return "th";
        if (hasUrduSpecific) return "ur";
        if (hasArabic) {
            String l = text.toLowerCase();
            if (l.contains("درد") || l.contains("سانس") || l.contains("بخار") || l.contains("کھانسی") || l.contains("سینے") || l.contains("ہے") || l.contains("میں")) {
                return "ur";
            }
            return "ar";
        }
        if (hasCJK) return "zh";
        if (hasDevanagari) {
            String l = text.toLowerCase();
            if (l.contains("आहे") || l.contains("त्रास") || l.contains("पोटात") || l.contains("छातीत") || l.contains("डोके") || l.contains("ताप") || l.contains("खोकला")) {
                return "mr";
            }
            return "hi";
        }

        String lower = text.toLowerCase();

        // Check for Transliterated Asian / Middle Eastern / Indic Keywords
        if (lower.contains("noppi") || lower.contains("gunde") || lower.contains("daggu") || lower.contains("swasa")) {
            return "te"; // Telugu transliterated
        }
        if (lower.contains("noovu") || lower.contains("ede") || lower.contains("kemmu") || lower.contains("usiru")) {
            return "kn"; // Kannada transliterated
        }
        if (lower.contains("vedhana") || lower.contains("nenchu") || lower.contains("chuma") || lower.contains("shwasam")) {
            return "ml"; // Malayalam transliterated
        }
        if (lower.contains("betha") || lower.contains("shwash") || lower.contains("jhor") || lower.contains("kashi")) {
            return "bn"; // Bengali transliterated
        }
        if (lower.contains("chhatit") || lower.contains("dokedukhi") || lower.contains("potdukhi") || lower.contains("khokla") || lower.contains("aahe")) {
            return "mr"; // Marathi transliterated
        }
        if (lower.contains("seene me") || lower.contains("saans lene") || lower.contains("takleef") || lower.contains("sar dard")) {
            return "ur"; // Urdu transliterated
        }
        if (lower.contains("alam fi") || lower.contains("sadr") || lower.contains("tanaffus") || lower.contains("humma") || lower.contains("sual")) {
            return "ar"; // Arabic transliterated
        }
        if (lower.contains("bol v grudi") || lower.contains("odyshka") || lower.contains("kashel") || lower.contains("temperatura")) {
            return "ru"; // Russian transliterated
        }
        if (lower.contains("mune no itami") || lower.contains("ikigurushii") || lower.contains("zutsu") || lower.contains("fukutsu") || lower.contains("kokyu")) {
            return "ja"; // Japanese Romaji
        }
        if (lower.contains("tongjeung") || lower.contains("hoheup") || lower.contains("gichim") || lower.contains("dutoong") || lower.contains("boktong")) {
            return "ko"; // Korean Romaji
        }
        if (lower.contains("xiongtong") || lower.contains("huxi") || lower.contains("gaoshao") || lower.contains("kesou") || lower.contains("toutong")) {
            return "zh"; // Chinese Pinyin
        }
        if (lower.contains("naen na-ok") || lower.contains("hai jai") || lower.contains("puat hua") || lower.contains("puat thong")) {
            return "th"; // Thai transliterated
        }

        // Check for European Languages
        if (lower.contains("dor ") || lower.contains("peito") || lower.contains("cabeça") || lower.contains("febre") || lower.contains("remédio") || lower.contains("ajuda") || lower.contains("falta de ar") || lower.contains("coração") || lower.contains("barriga")) {
            return "pt"; // Portuguese
        }
        if (lower.contains("dolore") || lower.contains("testa") || lower.contains("petto") || lower.contains("aiuto") || lower.contains("difficoltà") || lower.contains("respiro") || lower.contains("febbre") || lower.contains("pancia") || lower.contains("tosse")) {
            return "it"; // Italian
        }
        if (lower.contains("dolor") || lower.contains("fiebre") || lower.contains("pecho") || lower.contains("ayuda") || lower.contains("respirar")) {
            return "es"; // Spanish
        }
        if (lower.contains("douleur") || lower.contains("fièvre") || lower.contains("fievre") || lower.contains("tête") || lower.contains("aide") || lower.contains("poitrine")) {
            return "fr"; // French
        }
        if (lower.contains("schmerz") || lower.contains("fieber") || lower.contains("kopf") || lower.contains("brust") || lower.contains("hilfe") || lower.contains("atemnot")) {
            return "de"; // German
        }

        return "en";
    }
}
