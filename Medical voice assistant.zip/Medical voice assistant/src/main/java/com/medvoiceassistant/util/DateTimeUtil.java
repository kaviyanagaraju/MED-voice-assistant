package com.medvoiceassistant.util;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class DateTimeUtil {
    private static final DateTimeFormatter ISO_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    private static final DateTimeFormatter READABLE_FORMATTER = DateTimeFormatter.ofPattern("MMM dd, yyyy hh:mm a");
    private static final DateTimeFormatter TIME_ONLY_FORMATTER = DateTimeFormatter.ofPattern("HH:mm");

    public static String now() {
        return LocalDateTime.now().format(ISO_FORMATTER);
    }

    public static String formatReadable(String isoDateTime) {
        if (isoDateTime == null || isoDateTime.trim().isEmpty()) {
            return "";
        }
        try {
            LocalDateTime ldt = LocalDateTime.parse(isoDateTime, ISO_FORMATTER);
            return ldt.format(READABLE_FORMATTER);
        } catch (Exception e) {
            return isoDateTime;
        }
    }

    public static String currentTimeOnly() {
        return LocalDateTime.now().format(TIME_ONLY_FORMATTER);
    }
}
