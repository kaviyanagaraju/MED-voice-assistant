package com.medvoiceassistant.util;

public class ValidationUtil {
    public static boolean isNotEmpty(String value) {
        return value != null && !value.trim().isEmpty();
    }

    public static boolean isValidAge(int age) {
        return age >= 0 && age <= 130;
    }

    public static boolean isValidHeight(double heightCm) {
        return heightCm >= 30.0 && heightCm <= 280.0;
    }

    public static boolean isValidWeight(double weightKg) {
        return weightKg >= 1.0 && weightKg <= 400.0;
    }

    public static double calculateBMI(double weightKg, double heightCm) {
        if (heightCm <= 0 || weightKg <= 0) {
            return 0.0;
        }
        double heightM = heightCm / 100.0;
        double bmi = weightKg / (heightM * heightM);
        return Math.round(bmi * 10.0) / 10.0;
    }

    public static String getBMICategory(double bmi) {
        if (bmi <= 0) return "Unknown";
        if (bmi < 18.5) return "Underweight";
        if (bmi < 25.0) return "Normal weight";
        if (bmi < 30.0) return "Overweight";
        return "Obese";
    }
}
