package com.medvoiceassistant.server;

import com.medvoiceassistant.controller.*;
import com.medvoiceassistant.database.DatabaseManager;
import com.medvoiceassistant.service.ReminderService;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;

import java.io.*;
import java.net.InetSocketAddress;
import java.nio.file.Files;
import java.util.concurrent.Executors;

public class MedicalVoiceAssistantServer {
    private final int port;
    private HttpServer server;
    private final ReminderService reminderService;

    public MedicalVoiceAssistantServer(int port) {
        this.port = port;
        this.reminderService = new ReminderService();
    }

    public void start() throws IOException {
        // Initialize Database
        DatabaseManager.getInstance();

        server = HttpServer.create(new InetSocketAddress(port), 0);
        server.setExecutor(Executors.newFixedThreadPool(10));

        // Register API Handlers
        AuthController authController = new AuthController();
        server.createContext("/api/auth", authController);
        server.createContext("/api/user", authController);

        TriageController triageController = new TriageController();
        server.createContext("/api/triage", triageController);
        server.createContext("/api/languages", triageController);

        ChatbotController chatbotController = new ChatbotController();
        server.createContext("/api/chat", chatbotController);

        FoodPlanController foodPlanController = new FoodPlanController();
        server.createContext("/api/food", foodPlanController);

        FirstAidController firstAidController = new FirstAidController();
        server.createContext("/api/firstaid", firstAidController);

        SOSController sosController = new SOSController();
        server.createContext("/api/sos", sosController);

        RecordController recordController = new RecordController();
        server.createContext("/api/records", recordController);

        MedicationController medController = new MedicationController(reminderService);
        server.createContext("/api/medication", medController);
        server.createContext("/api/reminder", medController);

        HistoryController historyController = new HistoryController();
        server.createContext("/api/history", historyController);

        TTSController ttsController = new TTSController();
        server.createContext("/api/tts", ttsController);

        // Static File Handler for Web Client
        server.createContext("/", new StaticFileHandler());

        server.start();
        System.out.println("==================================================================");
        System.out.println(" AI Medical Voice Assistant Server successfully started!");
        System.out.println(" Access Web Application at: http://localhost:" + port + "/");
        System.out.println("==================================================================");
    }

    public void stop() {
        if (server != null) {
            server.stop(0);
        }
    }

    static class StaticFileHandler implements HttpHandler {
        private final File staticDir = new File("src/main/resources/web");

        @Override
        public void handle(HttpExchange exchange) throws IOException {
            String path = exchange.getRequestURI().getPath();
            if (path == null || path.equals("/") || path.isEmpty()) {
                path = "/index.html";
            }

            File requestedFile = new File(staticDir, path.replace('/', File.separatorChar));
            if (!requestedFile.exists() || requestedFile.isDirectory()) {
                requestedFile = new File(staticDir, "index.html");
            }

            if (requestedFile.exists() && !requestedFile.isDirectory()) {
                String contentType = Files.probeContentType(requestedFile.toPath());
                if (contentType == null) {
                    if (path.endsWith(".css")) contentType = "text/css";
                    else if (path.endsWith(".js")) contentType = "application/javascript";
                    else if (path.endsWith(".html")) contentType = "text/html; charset=UTF-8";
                    else if (path.endsWith(".svg")) contentType = "image/svg+xml";
                    else if (path.endsWith(".json")) contentType = "application/json";
                    else contentType = "text/plain";
                }

                exchange.getResponseHeaders().set("Content-Type", contentType);
                exchange.getResponseHeaders().set("Access-Control-Allow-Origin", "*");
                byte[] bytes = Files.readAllBytes(requestedFile.toPath());
                exchange.sendResponseHeaders(200, bytes.length);
                try (OutputStream os = exchange.getResponseBody()) {
                    os.write(bytes);
                }
            } else {
                String notFound = "<h1>404 Not Found</h1>";
                exchange.sendResponseHeaders(404, notFound.length());
                try (OutputStream os = exchange.getResponseBody()) {
                    os.write(notFound.getBytes());
                }
            }
        }
    }
}
