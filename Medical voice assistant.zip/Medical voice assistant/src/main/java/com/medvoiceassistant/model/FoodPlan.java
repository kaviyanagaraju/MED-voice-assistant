package com.medvoiceassistant.model;

public class FoodPlan {
    private int planId;
    private int userId;
    private String query;
    private String mealType; // BREAKFAST, LUNCH, DINNER, SNACKS, FULL_DAY
    private String planText;
    private int caloriesTarget;
    private String dietaryAdvice;
    private String createdAt;

    public FoodPlan() {}

    public FoodPlan(int planId, int userId, String query, String mealType, String planText, int caloriesTarget, String dietaryAdvice, String createdAt) {
        this.planId = planId;
        this.userId = userId;
        this.query = query;
        this.mealType = mealType;
        this.planText = planText;
        this.caloriesTarget = caloriesTarget;
        this.dietaryAdvice = dietaryAdvice;
        this.createdAt = createdAt;
    }

    public int getPlanId() { return planId; }
    public void setPlanId(int planId) { this.planId = planId; }

    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }

    public String getQuery() { return query; }
    public void setQuery(String query) { this.query = query; }

    public String getMealType() { return mealType; }
    public void setMealType(String mealType) { this.mealType = mealType; }

    public String getPlanText() { return planText; }
    public void setPlanText(String planText) { this.planText = planText; }

    public int getCaloriesTarget() { return caloriesTarget; }
    public void setCaloriesTarget(int caloriesTarget) { this.caloriesTarget = caloriesTarget; }

    public String getDietaryAdvice() { return dietaryAdvice; }
    public void setDietaryAdvice(String dietaryAdvice) { this.dietaryAdvice = dietaryAdvice; }

    public String getCreatedAt() { return createdAt; }
    public void setCreatedAt(String createdAt) { this.createdAt = createdAt; }
}
