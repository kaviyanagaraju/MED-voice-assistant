package com.medvoiceassistant.model;

import java.util.ArrayList;
import java.util.List;

public class SymptomSession {
    private int sessionId;
    private int userId;
    private String inputText;
    private String language;
    private String createdAt;
    private List<Symptom> symptoms = new ArrayList<>();
    private TriageResult triageResult;

    public SymptomSession() {}

    public SymptomSession(int sessionId, int userId, String inputText, String language, String createdAt) {
        this.sessionId = sessionId;
        this.userId = userId;
        this.inputText = inputText;
        this.language = language;
        this.createdAt = createdAt;
    }

    public int getSessionId() { return sessionId; }
    public void setSessionId(int sessionId) { this.sessionId = sessionId; }

    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }

    public String getInputText() { return inputText; }
    public void setInputText(String inputText) { this.inputText = inputText; }

    public String getLanguage() { return language; }
    public void setLanguage(String language) { this.language = language; }

    public String getCreatedAt() { return createdAt; }
    public void setCreatedAt(String createdAt) { this.createdAt = createdAt; }

    public List<Symptom> getSymptoms() { return symptoms; }
    public void setSymptoms(List<Symptom> symptoms) { this.symptoms = symptoms; }

    public TriageResult getTriageResult() { return triageResult; }
    public void setTriageResult(TriageResult triageResult) { this.triageResult = triageResult; }
}
