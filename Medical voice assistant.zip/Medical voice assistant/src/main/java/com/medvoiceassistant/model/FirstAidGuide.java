package com.medvoiceassistant.model;

public class FirstAidGuide {
    private int guideId;
    private String scenario; // MINOR_CUT, MINOR_BURN, NOSEBLEED, SPRAIN, CHOKING, FAINTING, INSECT_BITE
    private String title;
    private String language;
    private String steps; // JSON or markdown formatted step instructions
    private String redFlags; // Warning triggers requiring immediate emergency care
    private String escalation; // Action if condition worsens

    public FirstAidGuide() {}

    public FirstAidGuide(int guideId, String scenario, String title, String language, String steps, String redFlags, String escalation) {
        this.guideId = guideId;
        this.scenario = scenario;
        this.title = title;
        this.language = language;
        this.steps = steps;
        this.redFlags = redFlags;
        this.escalation = escalation;
    }

    public int getGuideId() { return guideId; }
    public void setGuideId(int guideId) { this.guideId = guideId; }

    public String getScenario() { return scenario; }
    public void setScenario(String scenario) { this.scenario = scenario; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getLanguage() { return language; }
    public void setLanguage(String language) { this.language = language; }

    public String getSteps() { return steps; }
    public void setSteps(String steps) { this.steps = steps; }

    public String getRedFlags() { return redFlags; }
    public void setRedFlags(String redFlags) { this.redFlags = redFlags; }

    public String getEscalation() { return escalation; }
    public void setEscalation(String escalation) { this.escalation = escalation; }
}
