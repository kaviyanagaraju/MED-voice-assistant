package com.medvoiceassistant.model;

public class Symptom {
    private int symptomId;
    private int sessionId;
    private String name;
    private String severity; // MILD, MODERATE, SEVERE
    private int durationDays;
    private String bodyPart;
    private boolean isRedFlag;

    public Symptom() {}

    public Symptom(String name, String severity, int durationDays, String bodyPart, boolean isRedFlag) {
        this.name = name;
        this.severity = severity;
        this.durationDays = durationDays;
        this.bodyPart = bodyPart;
        this.isRedFlag = isRedFlag;
    }

    public int getSymptomId() { return symptomId; }
    public void setSymptomId(int symptomId) { this.symptomId = symptomId; }

    public int getSessionId() { return sessionId; }
    public void setSessionId(int sessionId) { this.sessionId = sessionId; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getSeverity() { return severity; }
    public void setSeverity(String severity) { this.severity = severity; }

    public int getDurationDays() { return durationDays; }
    public void setDurationDays(int durationDays) { this.durationDays = durationDays; }

    public String getBodyPart() { return bodyPart; }
    public void setBodyPart(String bodyPart) { this.bodyPart = bodyPart; }

    public boolean isRedFlag() { return isRedFlag; }
    public void setRedFlag(boolean redFlag) { isRedFlag = redFlag; }
}
