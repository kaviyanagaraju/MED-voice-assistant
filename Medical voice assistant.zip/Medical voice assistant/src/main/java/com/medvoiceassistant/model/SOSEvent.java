package com.medvoiceassistant.model;

public class SOSEvent {
    private int sosId;
    private int userId;
    private String timestamp;
    private String location;
    private String contact;
    private String phone;
    private String status; // TRIGGERED, ACKNOWLEDGED, RESOLVED, CANCELLED
    private String notes;

    public SOSEvent() {}

    public SOSEvent(int sosId, int userId, String timestamp, String location, String contact, String phone, String status, String notes) {
        this.sosId = sosId;
        this.userId = userId;
        this.timestamp = timestamp;
        this.location = location;
        this.contact = contact;
        this.phone = phone;
        this.status = status;
        this.notes = notes;
    }

    public int getSosId() { return sosId; }
    public void setSosId(int sosId) { this.sosId = sosId; }

    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }

    public String getTimestamp() { return timestamp; }
    public void setTimestamp(String timestamp) { this.timestamp = timestamp; }

    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }

    public String getContact() { return contact; }
    public void setContact(String contact) { this.contact = contact; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }
}
