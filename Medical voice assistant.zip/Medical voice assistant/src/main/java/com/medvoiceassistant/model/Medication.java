package com.medvoiceassistant.model;

public class Medication {
    private int medicationId;
    private int userId;
    private String medicineName;
    private String dosage; // e.g. "500 mg", "1 tablet", "5 ml"
    private String frequency; // e.g. "Once daily", "Twice daily", "Every 8 hours"
    private String instructions; // e.g. "After meals with water"
    private String createdAt;

    public Medication() {}

    public Medication(int medicationId, int userId, String medicineName, String dosage, String frequency, String instructions, String createdAt) {
        this.medicationId = medicationId;
        this.userId = userId;
        this.medicineName = medicineName;
        this.dosage = dosage;
        this.frequency = frequency;
        this.instructions = instructions;
        this.createdAt = createdAt;
    }

    public int getMedicationId() { return medicationId; }
    public void setMedicationId(int medicationId) { this.medicationId = medicationId; }

    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }

    public String getMedicineName() { return medicineName; }
    public void setMedicineName(String medicineName) { this.medicineName = medicineName; }

    public String getDosage() { return dosage; }
    public void setDosage(String dosage) { this.dosage = dosage; }

    public String getFrequency() { return frequency; }
    public void setFrequency(String frequency) { this.frequency = frequency; }

    public String getInstructions() { return instructions; }
    public void setInstructions(String instructions) { this.instructions = instructions; }

    public String getCreatedAt() { return createdAt; }
    public void setCreatedAt(String createdAt) { this.createdAt = createdAt; }
}
