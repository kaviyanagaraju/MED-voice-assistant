package com.medvoiceassistant.model;

public class Reminder {
    private int reminderId;
    private int medicationId;
    private String medicineName;
    private String dosage;
    private String reminderTime; // e.g. "08:00", "14:00", "20:00"
    private String frequency; // DAILY, WEEKLY, SPECIFIC_DAYS
    private boolean active;
    private String lastTriggered;

    public Reminder() {}

    public Reminder(int reminderId, int medicationId, String medicineName, String dosage, String reminderTime, String frequency, boolean active, String lastTriggered) {
        this.reminderId = reminderId;
        this.medicationId = medicationId;
        this.medicineName = medicineName;
        this.dosage = dosage;
        this.reminderTime = reminderTime;
        this.frequency = frequency;
        this.active = active;
        this.lastTriggered = lastTriggered;
    }

    public int getReminderId() { return reminderId; }
    public void setReminderId(int reminderId) { this.reminderId = reminderId; }

    public int getMedicationId() { return medicationId; }
    public void setMedicationId(int medicationId) { this.medicationId = medicationId; }

    public String getMedicineName() { return medicineName; }
    public void setMedicineName(String medicineName) { this.medicineName = medicineName; }

    public String getDosage() { return dosage; }
    public void setDosage(String dosage) { this.dosage = dosage; }

    public String getReminderTime() { return reminderTime; }
    public void setReminderTime(String reminderTime) { this.reminderTime = reminderTime; }

    public String getFrequency() { return frequency; }
    public void setFrequency(String frequency) { this.frequency = frequency; }

    public boolean isActive() { return active; }
    public void setActive(boolean active) { this.active = active; }

    public String getLastTriggered() { return lastTriggered; }
    public void setLastTriggered(String lastTriggered) { this.lastTriggered = lastTriggered; }
}
