package com.medvoiceassistant.model;

public class MedicalRecord {
    private int recordId;
    private int userId;
    private String type; // LAB_REPORT, PRESCRIPTION, DISCHARGE_SUMMARY, X_RAY, MRI, CT_SCAN, OTHER
    private String fileName;
    private String filePath;
    private long fileSize;
    private String uploadDate;
    private String description;

    public MedicalRecord() {}

    public MedicalRecord(int recordId, int userId, String type, String fileName, String filePath, long fileSize, String uploadDate, String description) {
        this.recordId = recordId;
        this.userId = userId;
        this.type = type;
        this.fileName = fileName;
        this.filePath = filePath;
        this.fileSize = fileSize;
        this.uploadDate = uploadDate;
        this.description = description;
    }

    public int getRecordId() { return recordId; }
    public void setRecordId(int recordId) { this.recordId = recordId; }

    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }

    public String getFileName() { return fileName; }
    public void setFileName(String fileName) { this.fileName = fileName; }

    public String getFilePath() { return filePath; }
    public void setFilePath(String filePath) { this.filePath = filePath; }

    public long getFileSize() { return fileSize; }
    public void setFileSize(long fileSize) { this.fileSize = fileSize; }

    public String getUploadDate() { return uploadDate; }
    public void setUploadDate(String uploadDate) { this.uploadDate = uploadDate; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
}
