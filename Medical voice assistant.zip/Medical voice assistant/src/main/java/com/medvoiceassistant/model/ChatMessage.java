package com.medvoiceassistant.model;

public class ChatMessage {
    private int messageId;
    private int chatId;
    private String sender; // USER, ASSISTANT, SYSTEM
    private String message;
    private String intent; // TRIAGE, FIRST_AID, FOOD_PLAN, MEDICATION, EMERGENCY, GENERAL
    private String createdAt;

    public ChatMessage() {}

    public ChatMessage(int messageId, int chatId, String sender, String message, String intent, String createdAt) {
        this.messageId = messageId;
        this.chatId = chatId;
        this.sender = sender;
        this.message = message;
        this.intent = intent;
        this.createdAt = createdAt;
    }

    public int getMessageId() { return messageId; }
    public void setMessageId(int messageId) { this.messageId = messageId; }

    public int getChatId() { return chatId; }
    public void setChatId(int chatId) { this.chatId = chatId; }

    public String getSender() { return sender; }
    public void setSender(String sender) { this.sender = sender; }

    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }

    public String getIntent() { return intent; }
    public void setIntent(String intent) { this.intent = intent; }

    public String getCreatedAt() { return createdAt; }
    public void setCreatedAt(String createdAt) { this.createdAt = createdAt; }
}
