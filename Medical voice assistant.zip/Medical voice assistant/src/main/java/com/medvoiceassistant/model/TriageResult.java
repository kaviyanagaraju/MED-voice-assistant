package com.medvoiceassistant.model;

public class TriageResult {
    private int resultId;
    private int sessionId;
    private String urgency; // EMERGENCY, MODERATE, SELF_CARE, UNCERTAIN
    private String recommendation;
    private String department;
    private String reason;
    private String ruleMatched;
    private double confidenceScore;
    private String speechResponse;
    private String createdAt;

    public TriageResult() {}

    public TriageResult(String urgency, String recommendation, String department, String reason, String ruleMatched, double confidenceScore, String speechResponse) {
        this.urgency = urgency;
        this.recommendation = recommendation;
        this.department = department;
        this.reason = reason;
        this.ruleMatched = ruleMatched;
        this.confidenceScore = confidenceScore;
        this.speechResponse = speechResponse;
    }

    public int getResultId() { return resultId; }
    public void setResultId(int resultId) { this.resultId = resultId; }

    public int getSessionId() { return sessionId; }
    public void setSessionId(int sessionId) { this.sessionId = sessionId; }

    public String getUrgency() { return urgency; }
    public void setUrgency(String urgency) { this.urgency = urgency; }

    public String getRecommendation() { return recommendation; }
    public void setRecommendation(String recommendation) { this.recommendation = recommendation; }

    public String getDepartment() { return department; }
    public void setDepartment(String department) { this.department = department; }

    public String getReason() { return reason; }
    public void setReason(String reason) { this.reason = reason; }

    public String getRuleMatched() { return ruleMatched; }
    public void setRuleMatched(String ruleMatched) { this.ruleMatched = ruleMatched; }

    public double getConfidenceScore() { return confidenceScore; }
    public void setConfidenceScore(double confidenceScore) { this.confidenceScore = confidenceScore; }

    public String getSpeechResponse() { return speechResponse; }
    public void setSpeechResponse(String speechResponse) { this.speechResponse = speechResponse; }

    public String getCreatedAt() { return createdAt; }
    public void setCreatedAt(String createdAt) { this.createdAt = createdAt; }
}
