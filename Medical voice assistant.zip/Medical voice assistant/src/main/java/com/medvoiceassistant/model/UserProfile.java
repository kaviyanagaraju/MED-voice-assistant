package com.medvoiceassistant.model;

import com.medvoiceassistant.util.ValidationUtil;

public class UserProfile {
    private int profileId;
    private int userId;
    private String name;
    private String gender;
    private int age;
    private double height;
    private double weight;
    private String bloodGroup;
    private String emergencyContact;
    private String contactPhone;
    private double bmi;
    private String bmiCategory;

    public UserProfile() {}

    public UserProfile(int profileId, int userId, String name, String gender, int age,
                       double height, double weight, String bloodGroup,
                       String emergencyContact, String contactPhone) {
        this.profileId = profileId;
        this.userId = userId;
        this.name = name;
        this.gender = gender;
        this.age = age;
        this.height = height;
        this.weight = weight;
        this.bloodGroup = bloodGroup;
        this.emergencyContact = emergencyContact;
        this.contactPhone = contactPhone;
        this.bmi = ValidationUtil.calculateBMI(weight, height);
        this.bmiCategory = ValidationUtil.getBMICategory(this.bmi);
    }

    public void recalculateBMI() {
        this.bmi = ValidationUtil.calculateBMI(weight, height);
        this.bmiCategory = ValidationUtil.getBMICategory(this.bmi);
    }

    public int getProfileId() { return profileId; }
    public void setProfileId(int profileId) { this.profileId = profileId; }

    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getGender() { return gender; }
    public void setGender(String gender) { this.gender = gender; }

    public int getAge() { return age; }
    public void setAge(int age) { this.age = age; }

    public double getHeight() { return height; }
    public void setHeight(double height) { this.height = height; recalculateBMI(); }

    public double getWeight() { return weight; }
    public void setWeight(double weight) { this.weight = weight; recalculateBMI(); }

    public String getBloodGroup() { return bloodGroup; }
    public void setBloodGroup(String bloodGroup) { this.bloodGroup = bloodGroup; }

    public String getEmergencyContact() { return emergencyContact; }
    public void setEmergencyContact(String emergencyContact) { this.emergencyContact = emergencyContact; }

    public String getContactPhone() { return contactPhone; }
    public void setContactPhone(String contactPhone) { this.contactPhone = contactPhone; }

    public double getBmi() { return bmi; }
    public void setBmi(double bmi) { this.bmi = bmi; }

    public String getBmiCategory() { return bmiCategory; }
    public void setBmiCategory(String bmiCategory) { this.bmiCategory = bmiCategory; }
}
