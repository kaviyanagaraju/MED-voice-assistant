package com.medvoiceassistant.model;

import java.util.ArrayList;
import java.util.List;

public class ChatSession {
    private int chatId;
    private int userId;
    private String language;
    private String createdAt;
    private List<ChatMessage> messages = new ArrayList<>();

    public ChatSession() {}

    public ChatSession(int chatId, int userId, String language, String createdAt) {
        this.chatId = chatId;
        this.userId = userId;
        this.language = language;
        this.createdAt = createdAt;
    }

    public int getChatId() { return chatId; }
    public void setChatId(int chatId) { this.chatId = chatId; }

    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }

    public String getLanguage() { return language; }
    public void setLanguage(String language) { this.language = language; }

    public String getCreatedAt() { return createdAt; }
    public void setCreatedAt(String createdAt) { this.createdAt = createdAt; }

    public List<ChatMessage> getMessages() { return messages; }
    public void setMessages(List<ChatMessage> messages) { this.messages = messages; }
}
