package com.medvoiceassistant;

import com.medvoiceassistant.server.MedicalVoiceAssistantServer;

import java.awt.Desktop;
import java.net.URI;

public class Main {
    private static final int DEFAULT_PORT = 8080;

    public static void main(String[] args) {
        int port = DEFAULT_PORT;
        if (args.length > 0) {
            try {
                port = Integer.parseInt(args[0]);
            } catch (NumberFormatException ignored) {}
        }

        try {
            MedicalVoiceAssistantServer server = new MedicalVoiceAssistantServer(port);
            server.start();

            // Try to open default browser if supported
            String appUrl = "http://localhost:" + port + "/";
            if (Desktop.isDesktopSupported() && Desktop.getDesktop().isSupported(Desktop.Action.BROWSE)) {
                try {
                    Desktop.getDesktop().browse(new URI(appUrl));
                } catch (Exception ignored) {}
            }

            // Keep main thread active
            Thread.currentThread().join();

        } catch (Exception e) {
            System.err.println("Fatal error starting Medical Voice Assistant: " + e.getMessage());
            e.printStackTrace();
            System.exit(1);
        }
    }
}
