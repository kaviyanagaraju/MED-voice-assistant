package com.medvoiceassistant.controller;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.medvoiceassistant.model.SymptomSession;
import com.medvoiceassistant.model.TriageResult;
import com.medvoiceassistant.repository.SymptomRepository;
import com.medvoiceassistant.repository.TriageRepository;
import com.medvoiceassistant.server.HttpHandlerUtil;
import com.medvoiceassistant.service.LanguageService;
import com.medvoiceassistant.service.TriageService;
import com.medvoiceassistant.util.DateTimeUtil;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TriageController implements HttpHandler {
    private final TriageService triageService = new TriageService();
    private final SymptomRepository symptomRepo = new SymptomRepository();
    private final TriageRepository triageRepo = new TriageRepository();
    private final LanguageService languageService = new LanguageService();

    @Override
    public void handle(HttpExchange exchange) throws IOException {
        String method = exchange.getRequestMethod();
        if ("OPTIONS".equalsIgnoreCase(method)) {
            HttpHandlerUtil.sendCorsPreflightResponse(exchange);
            return;
        }

        String path = exchange.getRequestURI().getPath();

        try {
            if (path.endsWith("/evaluate") && "POST".equalsIgnoreCase(method)) {
                handleEvaluate(exchange);
            } else if (path.endsWith("/history") && "GET".equalsIgnoreCase(method)) {
                handleHistory(exchange);
            } else if (path.endsWith("/languages") && "GET".equalsIgnoreCase(method)) {
                HttpHandlerUtil.sendJsonResponse(exchange, 200, languageService.getSupportedLanguages());
            } else {
                HttpHandlerUtil.sendJsonResponse(exchange, 404, Map.of("error", "Not Found"));
            }
        } catch (Exception e) {
            e.printStackTrace();
            HttpHandlerUtil.sendJsonResponse(exchange, 500, Map.of("error", e.getMessage()));
        }
    }

    private void handleEvaluate(HttpExchange exchange) throws IOException {
        String body = HttpHandlerUtil.readRequestBody(exchange);
        JsonObject json = JsonParser.parseString(body).getAsJsonObject();

        int userId = json.has("userId") ? json.get("userId").getAsInt() : 1;
        String text = json.has("inputText") ? json.get("inputText").getAsString() : "";
        String language = json.has("language") ? json.get("language").getAsString() : "auto";

        if (text == null || text.trim().isEmpty()) {
            HttpHandlerUtil.sendJsonResponse(exchange, 400, Map.of("error", "Input text is required for symptom assessment"));
            return;
        }

        TriageService.EvaluationOutcome outcome = triageService.evaluateSymptomText(userId, text, language);
        SymptomSession session = outcome.session;
        session.setCreatedAt(DateTimeUtil.now());

        // Persist session and symptoms
        int sessionId = symptomRepo.saveSession(session);
        TriageResult result = outcome.triageResult;
        result.setSessionId(sessionId);
        result.setCreatedAt(DateTimeUtil.now());

        // Persist triage outcome
        int resultId = triageRepo.saveTriageResult(result);
        result.setResultId(resultId);

        Map<String, Object> resp = new HashMap<>();
        resp.put("sessionId", sessionId);
        resp.put("resultId", resultId);
        resp.put("inputText", session.getInputText());
        resp.put("detectedLanguage", session.getLanguage());
        resp.put("urgency", result.getUrgency());
        resp.put("department", result.getDepartment());
        resp.put("recommendation", result.getRecommendation());
        resp.put("reason", result.getReason());
        resp.put("ruleMatched", result.getRuleMatched());
        resp.put("confidenceScore", result.getConfidenceScore());
        resp.put("speechResponse", result.getSpeechResponse());
        resp.put("symptoms", session.getSymptoms());
        resp.put("createdAt", result.getCreatedAt());

        HttpHandlerUtil.sendJsonResponse(exchange, 200, resp);
    }

    private void handleHistory(HttpExchange exchange) throws IOException {
        Map<String, String> q = HttpHandlerUtil.parseQueryParams(exchange.getRequestURI().getQuery());
        int userId = Integer.parseInt(q.getOrDefault("userId", "1"));
        List<TriageResult> history = triageRepo.getTriageHistoryByUserId(userId);
        HttpHandlerUtil.sendJsonResponse(exchange, 200, history);
    }
}
