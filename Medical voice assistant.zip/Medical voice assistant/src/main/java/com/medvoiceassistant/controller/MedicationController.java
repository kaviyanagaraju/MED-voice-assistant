package com.medvoiceassistant.controller;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.medvoiceassistant.model.Medication;
import com.medvoiceassistant.model.Reminder;
import com.medvoiceassistant.repository.MedicationRepository;
import com.medvoiceassistant.server.HttpHandlerUtil;
import com.medvoiceassistant.service.ReminderService;
import com.medvoiceassistant.util.DateTimeUtil;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import java.io.IOException;
import java.util.List;
import java.util.Map;

public class MedicationController implements HttpHandler {
    private final MedicationRepository medRepo = new MedicationRepository();
    private final ReminderService reminderService;

    public MedicationController(ReminderService reminderService) {
        this.reminderService = reminderService;
    }

    @Override
    public void handle(HttpExchange exchange) throws IOException {
        String method = exchange.getRequestMethod();
        if ("OPTIONS".equalsIgnoreCase(method)) {
            HttpHandlerUtil.sendCorsPreflightResponse(exchange);
            return;
        }

        String path = exchange.getRequestURI().getPath();

        try {
            if (path.contains("/medication/list") && "GET".equalsIgnoreCase(method)) {
                handleListMedications(exchange);
            } else if (path.contains("/medication/add") && "POST".equalsIgnoreCase(method)) {
                handleAddMedication(exchange);
            } else if (path.contains("/medication/delete") && "POST".equalsIgnoreCase(method)) {
                handleDeleteMedication(exchange);
            } else if (path.contains("/reminder/list") && "GET".equalsIgnoreCase(method)) {
                handleListReminders(exchange);
            } else if (path.contains("/reminder/add") && "POST".equalsIgnoreCase(method)) {
                handleAddReminder(exchange);
            } else if (path.contains("/reminder/toggle") && "POST".equalsIgnoreCase(method)) {
                handleToggleReminder(exchange);
            } else if (path.contains("/reminder/delete") && "POST".equalsIgnoreCase(method)) {
                handleDeleteReminder(exchange);
            } else if (path.contains("/reminder/poll") && "GET".equalsIgnoreCase(method)) {
                handlePollReminders(exchange);
            } else if (path.contains("/reminder/test-alert") && "POST".equalsIgnoreCase(method)) {
                handleTestAlert(exchange);
            } else {
                HttpHandlerUtil.sendJsonResponse(exchange, 404, Map.of("error", "Not Found"));
            }
        } catch (Exception e) {
            e.printStackTrace();
            HttpHandlerUtil.sendJsonResponse(exchange, 500, Map.of("error", e.getMessage()));
        }
    }

    private void handleListMedications(HttpExchange exchange) throws IOException {
        Map<String, String> q = HttpHandlerUtil.parseQueryParams(exchange.getRequestURI().getQuery());
        int userId = Integer.parseInt(q.getOrDefault("userId", "1"));
        List<Medication> list = medRepo.getMedicationsByUserId(userId);
        HttpHandlerUtil.sendJsonResponse(exchange, 200, list);
    }

    private void handleAddMedication(HttpExchange exchange) throws IOException {
        String body = HttpHandlerUtil.readRequestBody(exchange);
        JsonObject json = JsonParser.parseString(body).getAsJsonObject();

        int userId = json.has("userId") ? json.get("userId").getAsInt() : 1;
        String name = json.has("medicineName") ? json.get("medicineName").getAsString() : "";
        String dosage = json.has("dosage") ? json.get("dosage").getAsString() : "";
        String freq = json.has("frequency") ? json.get("frequency").getAsString() : "Daily";
        String instructions = json.has("instructions") ? json.get("instructions").getAsString() : "";

        Medication med = new Medication(0, userId, name, dosage, freq, instructions, DateTimeUtil.now());
        int medId = medRepo.saveMedication(med);

        // If reminderTime is provided, also create a reminder automatically
        if (json.has("reminderTime")) {
            String time = json.get("reminderTime").getAsString();
            Reminder rem = new Reminder(0, medId, name, dosage, time, "DAILY", true, null);
            reminderService.createReminder(rem);
        }

        HttpHandlerUtil.sendJsonResponse(exchange, 201, Map.of("success", true, "medicationId", medId));
    }

    private void handleDeleteMedication(HttpExchange exchange) throws IOException {
        String body = HttpHandlerUtil.readRequestBody(exchange);
        JsonObject json = JsonParser.parseString(body).getAsJsonObject();
        int medId = json.has("medicationId") ? json.get("medicationId").getAsInt() : 0;
        int userId = json.has("userId") ? json.get("userId").getAsInt() : 1;

        boolean ok = medRepo.deleteMedication(medId, userId);
        HttpHandlerUtil.sendJsonResponse(exchange, 200, Map.of("success", ok));
    }

    private void handleListReminders(HttpExchange exchange) throws IOException {
        Map<String, String> q = HttpHandlerUtil.parseQueryParams(exchange.getRequestURI().getQuery());
        int userId = Integer.parseInt(q.getOrDefault("userId", "1"));
        List<Reminder> list = reminderService.getRemindersByUserId(userId);
        HttpHandlerUtil.sendJsonResponse(exchange, 200, list);
    }

    private void handleAddReminder(HttpExchange exchange) throws IOException {
        String body = HttpHandlerUtil.readRequestBody(exchange);
        JsonObject json = JsonParser.parseString(body).getAsJsonObject();

        int medId = json.has("medicationId") ? json.get("medicationId").getAsInt() : 1;
        String medicineName = json.has("medicineName") ? json.get("medicineName").getAsString() : "Medication";
        String dosage = json.has("dosage") ? json.get("dosage").getAsString() : "1 dose";
        String time = json.has("reminderTime") ? json.get("reminderTime").getAsString() : "09:00";
        String freq = json.has("frequency") ? json.get("frequency").getAsString() : "DAILY";

        Reminder r = new Reminder(0, medId, medicineName, dosage, time, freq, true, null);
        int remId = reminderService.createReminder(r);
        HttpHandlerUtil.sendJsonResponse(exchange, 201, Map.of("success", true, "reminderId", remId));
    }

    private void handleToggleReminder(HttpExchange exchange) throws IOException {
        String body = HttpHandlerUtil.readRequestBody(exchange);
        JsonObject json = JsonParser.parseString(body).getAsJsonObject();
        int reminderId = json.has("reminderId") ? json.get("reminderId").getAsInt() : 0;
        boolean active = json.has("active") && json.get("active").getAsBoolean();

        boolean ok = reminderService.toggleActive(reminderId, active);
        HttpHandlerUtil.sendJsonResponse(exchange, 200, Map.of("success", ok));
    }

    private void handleDeleteReminder(HttpExchange exchange) throws IOException {
        String body = HttpHandlerUtil.readRequestBody(exchange);
        JsonObject json = JsonParser.parseString(body).getAsJsonObject();
        int reminderId = json.has("reminderId") ? json.get("reminderId").getAsInt() : 0;

        boolean ok = reminderService.deleteReminder(reminderId);
        HttpHandlerUtil.sendJsonResponse(exchange, 200, Map.of("success", ok));
    }

    private void handlePollReminders(HttpExchange exchange) throws IOException {
        List<ReminderService.ReminderAlert> alerts = reminderService.pollAlerts();
        HttpHandlerUtil.sendJsonResponse(exchange, 200, alerts);
    }

    private void handleTestAlert(HttpExchange exchange) throws IOException {
        String body = HttpHandlerUtil.readRequestBody(exchange);
        JsonObject json = JsonParser.parseString(body).getAsJsonObject();
        String medicineName = json.has("medicineName") ? json.get("medicineName").getAsString() : "Paracetamol";
        String dosage = json.has("dosage") ? json.get("dosage").getAsString() : "500 mg";

        reminderService.triggerTestAlert(1, medicineName, dosage);
        HttpHandlerUtil.sendJsonResponse(exchange, 200, Map.of("success", true, "message", "Test alert triggered"));
    }
}
