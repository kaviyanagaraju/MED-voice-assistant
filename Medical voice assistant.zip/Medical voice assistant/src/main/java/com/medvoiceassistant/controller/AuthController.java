package com.medvoiceassistant.controller;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.medvoiceassistant.model.User;
import com.medvoiceassistant.model.UserProfile;
import com.medvoiceassistant.repository.UserProfileRepository;
import com.medvoiceassistant.repository.UserRepository;
import com.medvoiceassistant.server.HttpHandlerUtil;
import com.medvoiceassistant.util.DateTimeUtil;
import com.medvoiceassistant.util.PasswordUtil;
import com.medvoiceassistant.util.ValidationUtil;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

public class AuthController implements HttpHandler {
    private final UserRepository userRepo = new UserRepository();
    private final UserProfileRepository profileRepo = new UserProfileRepository();

    @Override
    public void handle(HttpExchange exchange) throws IOException {
        String method = exchange.getRequestMethod();
        if ("OPTIONS".equalsIgnoreCase(method)) {
            HttpHandlerUtil.sendCorsPreflightResponse(exchange);
            return;
        }

        String path = exchange.getRequestURI().getPath();

        try {
            if (path.endsWith("/login") && "POST".equalsIgnoreCase(method)) {
                handleLogin(exchange);
            } else if (path.endsWith("/register") && "POST".equalsIgnoreCase(method)) {
                handleRegister(exchange);
            } else if (path.endsWith("/profile") && "GET".equalsIgnoreCase(method)) {
                handleGetProfile(exchange);
            } else if (path.endsWith("/profile") && "POST".equalsIgnoreCase(method)) {
                handleUpdateProfile(exchange);
            } else {
                Map<String, String> err = Map.of("error", "Not Found");
                HttpHandlerUtil.sendJsonResponse(exchange, 404, err);
            }
        } catch (Exception e) {
            Map<String, String> err = Map.of("error", e.getMessage());
            HttpHandlerUtil.sendJsonResponse(exchange, 500, err);
        }
    }

    private void handleLogin(HttpExchange exchange) throws IOException {
        String body = HttpHandlerUtil.readRequestBody(exchange);
        JsonObject json = JsonParser.parseString(body).getAsJsonObject();
        String username = json.has("username") ? json.get("username").getAsString().trim() : "";
        String password = json.has("password") ? json.get("password").getAsString() : "";

        if (!ValidationUtil.isNotEmpty(username) || !ValidationUtil.isNotEmpty(password)) {
            HttpHandlerUtil.sendJsonResponse(exchange, 400, Map.of("success", false, "message", "Username and password required"));
            return;
        }

        Optional<User> userOpt = userRepo.findByUsername(username);
        if (userOpt.isEmpty() || !PasswordUtil.verifyPassword(password, userOpt.get().getPasswordHash())) {
            HttpHandlerUtil.sendJsonResponse(exchange, 401, Map.of("success", false, "message", "Invalid username or password"));
            return;
        }

        User u = userOpt.get();
        Optional<UserProfile> profOpt = profileRepo.findByUserId(u.getUserId());

        Map<String, Object> resp = new HashMap<>();
        resp.put("success", true);
        resp.put("userId", u.getUserId());
        resp.put("username", u.getUsername());
        resp.put("profile", profOpt.orElse(null));

        HttpHandlerUtil.sendJsonResponse(exchange, 200, resp);
    }

    private void handleRegister(HttpExchange exchange) throws IOException {
        String body = HttpHandlerUtil.readRequestBody(exchange);
        JsonObject json = JsonParser.parseString(body).getAsJsonObject();

        String username = json.has("username") ? json.get("username").getAsString().trim() : "";
        String password = json.has("password") ? json.get("password").getAsString() : "";
        String name = json.has("name") ? json.get("name").getAsString().trim() : username;
        String gender = json.has("gender") ? json.get("gender").getAsString() : "Unspecified";
        int age = json.has("age") ? json.get("age").getAsInt() : 25;
        double height = json.has("height") ? json.get("height").getAsDouble() : 165.0;
        double weight = json.has("weight") ? json.get("weight").getAsDouble() : 60.0;
        String bloodGroup = json.has("bloodGroup") ? json.get("bloodGroup").getAsString() : "O+";
        String emergencyContact = json.has("emergencyContact") ? json.get("emergencyContact").getAsString() : "Family";
        String contactPhone = json.has("contactPhone") ? json.get("contactPhone").getAsString() : "108";

        if (!ValidationUtil.isNotEmpty(username) || !ValidationUtil.isNotEmpty(password)) {
            HttpHandlerUtil.sendJsonResponse(exchange, 400, Map.of("success", false, "message", "Username and password are required"));
            return;
        }

        if (userRepo.findByUsername(username).isPresent()) {
            HttpHandlerUtil.sendJsonResponse(exchange, 409, Map.of("success", false, "message", "Username already exists"));
            return;
        }

        int userId = userRepo.createUser(username, PasswordUtil.hashPassword(password), DateTimeUtil.now());
        if (userId <= 0) {
            HttpHandlerUtil.sendJsonResponse(exchange, 500, Map.of("success", false, "message", "Failed to create user"));
            return;
        }

        UserProfile profile = new UserProfile(0, userId, name, gender, age, height, weight, bloodGroup, emergencyContact, contactPhone);
        profileRepo.saveOrUpdate(profile);

        Map<String, Object> resp = new HashMap<>();
        resp.put("success", true);
        resp.put("userId", userId);
        resp.put("username", username);
        resp.put("profile", profile);

        HttpHandlerUtil.sendJsonResponse(exchange, 201, resp);
    }

    private void handleGetProfile(HttpExchange exchange) throws IOException {
        Map<String, String> q = HttpHandlerUtil.parseQueryParams(exchange.getRequestURI().getQuery());
        int userId = Integer.parseInt(q.getOrDefault("userId", "1"));
        Optional<UserProfile> profOpt = profileRepo.findByUserId(userId);
        if (profOpt.isPresent()) {
            HttpHandlerUtil.sendJsonResponse(exchange, 200, profOpt.get());
        } else {
            HttpHandlerUtil.sendJsonResponse(exchange, 404, Map.of("error", "Profile not found"));
        }
    }

    private void handleUpdateProfile(HttpExchange exchange) throws IOException {
        String body = HttpHandlerUtil.readRequestBody(exchange);
        UserProfile p = HttpHandlerUtil.GSON.fromJson(body, UserProfile.class);
        if (p == null || p.getUserId() <= 0) {
            HttpHandlerUtil.sendJsonResponse(exchange, 400, Map.of("success", false, "message", "Invalid profile data"));
            return;
        }
        p.recalculateBMI();
        boolean ok = profileRepo.saveOrUpdate(p);
        HttpHandlerUtil.sendJsonResponse(exchange, 200, Map.of("success", ok, "profile", p));
    }
}
