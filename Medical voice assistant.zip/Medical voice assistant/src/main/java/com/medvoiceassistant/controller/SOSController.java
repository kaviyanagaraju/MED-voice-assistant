package com.medvoiceassistant.controller;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.medvoiceassistant.model.SOSEvent;
import com.medvoiceassistant.server.HttpHandlerUtil;
import com.medvoiceassistant.service.SOSService;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import java.io.IOException;
import java.util.List;
import java.util.Map;

public class SOSController implements HttpHandler {
    private final SOSService sosService = new SOSService();

    @Override
    public void handle(HttpExchange exchange) throws IOException {
        String method = exchange.getRequestMethod();
        if ("OPTIONS".equalsIgnoreCase(method)) {
            HttpHandlerUtil.sendCorsPreflightResponse(exchange);
            return;
        }

        String path = exchange.getRequestURI().getPath();

        try {
            if (path.endsWith("/trigger") && "POST".equalsIgnoreCase(method)) {
                handleTrigger(exchange);
            } else if (path.endsWith("/history") && "GET".equalsIgnoreCase(method)) {
                handleHistory(exchange);
            } else {
                HttpHandlerUtil.sendJsonResponse(exchange, 404, Map.of("error", "Not Found"));
            }
        } catch (Exception e) {
            e.printStackTrace();
            HttpHandlerUtil.sendJsonResponse(exchange, 500, Map.of("error", e.getMessage()));
        }
    }

    private void handleTrigger(HttpExchange exchange) throws IOException {
        String body = HttpHandlerUtil.readRequestBody(exchange);
        JsonObject json = JsonParser.parseString(body).getAsJsonObject();

        int userId = json.has("userId") ? json.get("userId").getAsInt() : 1;
        String location = json.has("location") ? json.get("location").getAsString() : null;
        String reason = json.has("reason") ? json.get("reason").getAsString() : "Emergency SOS initiated by user";
        String customPhone = json.has("contactPhone") ? json.get("contactPhone").getAsString()
                : (json.has("phone") ? json.get("phone").getAsString() : null);

        Map<String, Object> result = sosService.triggerSOS(userId, location, reason, customPhone);
        HttpHandlerUtil.sendJsonResponse(exchange, 200, result);
    }

    private void handleHistory(HttpExchange exchange) throws IOException {
        Map<String, String> q = HttpHandlerUtil.parseQueryParams(exchange.getRequestURI().getQuery());
        int userId = Integer.parseInt(q.getOrDefault("userId", "1"));
        List<SOSEvent> events = sosService.getEventsByUserId(userId);
        HttpHandlerUtil.sendJsonResponse(exchange, 200, events);
    }
}
