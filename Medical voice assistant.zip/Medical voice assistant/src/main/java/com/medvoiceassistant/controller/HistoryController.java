package com.medvoiceassistant.controller;

import com.medvoiceassistant.model.*;
import com.medvoiceassistant.repository.*;
import com.medvoiceassistant.server.HttpHandlerUtil;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public class HistoryController implements HttpHandler {
    private final UserProfileRepository profileRepo = new UserProfileRepository();
    private final SymptomRepository symptomRepo = new SymptomRepository();
    private final TriageRepository triageRepo = new TriageRepository();
    private final MedicationRepository medRepo = new MedicationRepository();
    private final RecordRepository recordRepo = new RecordRepository();
    private final SOSRepository sosRepo = new SOSRepository();

    @Override
    public void handle(HttpExchange exchange) throws IOException {
        String method = exchange.getRequestMethod();
        if ("OPTIONS".equalsIgnoreCase(method)) {
            HttpHandlerUtil.sendCorsPreflightResponse(exchange);
            return;
        }

        try {
            Map<String, String> q = HttpHandlerUtil.parseQueryParams(exchange.getRequestURI().getQuery());
            int userId = Integer.parseInt(q.getOrDefault("userId", "1"));

            Optional<UserProfile> profile = profileRepo.findByUserId(userId);
            List<SymptomSession> sessions = symptomRepo.getSessionsByUserId(userId);
            List<TriageResult> triageResults = triageRepo.getTriageHistoryByUserId(userId);
            List<Medication> medications = medRepo.getMedicationsByUserId(userId);
            List<MedicalRecord> records = recordRepo.getRecordsByUserId(userId);
            List<SOSEvent> sosEvents = sosRepo.getEventsByUserId(userId);

            Map<String, Object> summary = new HashMap<>();
            summary.put("profile", profile.orElse(null));
            summary.put("symptomSessions", sessions);
            summary.put("triageResults", triageResults);
            summary.put("medications", medications);
            summary.put("records", records);
            summary.put("sosEvents", sosEvents);

            HttpHandlerUtil.sendJsonResponse(exchange, 200, summary);
        } catch (Exception e) {
            e.printStackTrace();
            HttpHandlerUtil.sendJsonResponse(exchange, 500, Map.of("error", e.getMessage()));
        }
    }
}
