package com.medvoiceassistant.controller;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.medvoiceassistant.model.ChatMessage;
import com.medvoiceassistant.model.UserProfile;
import com.medvoiceassistant.repository.ChatRepository;
import com.medvoiceassistant.repository.UserProfileRepository;
import com.medvoiceassistant.server.HttpHandlerUtil;
import com.medvoiceassistant.service.ChatbotService;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public class ChatbotController implements HttpHandler {
    private final ChatbotService chatbotService = new ChatbotService();
    private final ChatRepository chatRepo = new ChatRepository();
    private final UserProfileRepository profileRepo = new UserProfileRepository();

    @Override
    public void handle(HttpExchange exchange) throws IOException {
        String method = exchange.getRequestMethod();
        if ("OPTIONS".equalsIgnoreCase(method)) {
            HttpHandlerUtil.sendCorsPreflightResponse(exchange);
            return;
        }

        String path = exchange.getRequestURI().getPath();

        try {
            if (path.endsWith("/message") && "POST".equalsIgnoreCase(method)) {
                handleMessage(exchange);
            } else if (path.endsWith("/history") && "GET".equalsIgnoreCase(method)) {
                handleHistory(exchange);
            } else {
                HttpHandlerUtil.sendJsonResponse(exchange, 404, Map.of("error", "Not Found"));
            }
        } catch (Exception e) {
            e.printStackTrace();
            HttpHandlerUtil.sendJsonResponse(exchange, 500, Map.of("error", e.getMessage()));
        }
    }

    private void handleMessage(HttpExchange exchange) throws IOException {
        String body = HttpHandlerUtil.readRequestBody(exchange);
        JsonObject json = JsonParser.parseString(body).getAsJsonObject();

        int userId = json.has("userId") ? json.get("userId").getAsInt() : 1;
        String message = json.has("message") ? json.get("message").getAsString() : "";
        String language = json.has("language") ? json.get("language").getAsString() : "en";

        int chatId = json.has("chatId") && json.get("chatId").getAsInt() > 0
                ? json.get("chatId").getAsInt()
                : chatbotService.getOrCreateSession(userId, language);

        Optional<UserProfile> profile = profileRepo.findByUserId(userId);
        ChatbotService.ChatResponse resp = chatbotService.processUserMessage(userId, chatId, message, language, profile.orElse(null));

        Map<String, Object> map = new HashMap<>();
        map.put("chatId", chatId);
        map.put("reply", resp.reply);
        map.put("intent", resp.intent);
        map.put("isEmergency", resp.isEmergency);
        map.put("extraData", resp.extraData);

        HttpHandlerUtil.sendJsonResponse(exchange, 200, map);
    }

    private void handleHistory(HttpExchange exchange) throws IOException {
        Map<String, String> q = HttpHandlerUtil.parseQueryParams(exchange.getRequestURI().getQuery());
        int userId = Integer.parseInt(q.getOrDefault("userId", "1"));
        var sessionOpt = chatRepo.getLatestSessionForUser(userId);
        if (sessionOpt.isPresent()) {
            List<ChatMessage> msgs = chatRepo.getMessagesByChatId(sessionOpt.get().getChatId());
            HttpHandlerUtil.sendJsonResponse(exchange, 200, msgs);
        } else {
            HttpHandlerUtil.sendJsonResponse(exchange, 200, List.of());
        }
    }
}
