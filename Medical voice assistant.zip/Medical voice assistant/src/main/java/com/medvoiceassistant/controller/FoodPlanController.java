package com.medvoiceassistant.controller;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.medvoiceassistant.model.FoodPlan;
import com.medvoiceassistant.model.UserProfile;
import com.medvoiceassistant.repository.UserProfileRepository;
import com.medvoiceassistant.server.HttpHandlerUtil;
import com.medvoiceassistant.service.FoodPlanService;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public class FoodPlanController implements HttpHandler {
    private final FoodPlanService foodPlanService = new FoodPlanService();
    private final UserProfileRepository profileRepo = new UserProfileRepository();

    @Override
    public void handle(HttpExchange exchange) throws IOException {
        String method = exchange.getRequestMethod();
        if ("OPTIONS".equalsIgnoreCase(method)) {
            HttpHandlerUtil.sendCorsPreflightResponse(exchange);
            return;
        }

        String path = exchange.getRequestURI().getPath();

        try {
            if (path.endsWith("/generate") && "POST".equalsIgnoreCase(method)) {
                handleGenerate(exchange);
            } else if (path.endsWith("/history") && "GET".equalsIgnoreCase(method)) {
                handleHistory(exchange);
            } else {
                HttpHandlerUtil.sendJsonResponse(exchange, 404, Map.of("error", "Not Found"));
            }
        } catch (Exception e) {
            e.printStackTrace();
            HttpHandlerUtil.sendJsonResponse(exchange, 500, Map.of("error", e.getMessage()));
        }
    }

    private void handleGenerate(HttpExchange exchange) throws IOException {
        String body = HttpHandlerUtil.readRequestBody(exchange);
        JsonObject json = JsonParser.parseString(body).getAsJsonObject();

        int userId = json.has("userId") ? json.get("userId").getAsInt() : 1;
        String query = json.has("query") ? json.get("query").getAsString() : "Healthy balanced meal plan";
        String language = json.has("language") ? json.get("language").getAsString() : "en";

        Optional<UserProfile> profile = profileRepo.findByUserId(userId);
        FoodPlan plan = foodPlanService.generatePlan(userId, query, profile.orElse(null), language);

        HttpHandlerUtil.sendJsonResponse(exchange, 200, plan);
    }

    private void handleHistory(HttpExchange exchange) throws IOException {
        Map<String, String> q = HttpHandlerUtil.parseQueryParams(exchange.getRequestURI().getQuery());
        int userId = Integer.parseInt(q.getOrDefault("userId", "1"));
        List<FoodPlan> list = foodPlanService.getPlansByUserId(userId);
        HttpHandlerUtil.sendJsonResponse(exchange, 200, list);
    }
}
