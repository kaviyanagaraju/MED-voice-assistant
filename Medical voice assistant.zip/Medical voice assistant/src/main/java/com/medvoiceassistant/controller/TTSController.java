package com.medvoiceassistant.controller;

import com.medvoiceassistant.server.HttpHandlerUtil;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Universal High-Definition Audio TTS Controller
 * Provides natural speech synthesis across all 20 supported languages:
 * Tamil, Telugu, Kannada, Malayalam, Bengali, Marathi, Urdu, Hindi, English,
 * Arabic, Russian, Japanese, Korean, Chinese, Thai, Spanish, Portuguese, French, German, Italian.
 */
public class TTSController implements HttpHandler {

    private static final Map<String, byte[]> AUDIO_CACHE = new ConcurrentHashMap<>();

    @Override
    public void handle(HttpExchange exchange) throws IOException {
        String method = exchange.getRequestMethod();
        if ("OPTIONS".equalsIgnoreCase(method)) {
            HttpHandlerUtil.sendCorsPreflightResponse(exchange);
            return;
        }

        try {
            String query = exchange.getRequestURI().getQuery();
            Map<String, String> params = HttpHandlerUtil.parseQueryParams(query);
            String lang = params.getOrDefault("lang", "en").trim();
            String text = params.getOrDefault("text", "").trim();

            if (text.isEmpty()) {
                byte[] empty = new byte[0];
                exchange.getResponseHeaders().set("Content-Type", "audio/mpeg");
                exchange.sendResponseHeaders(200, 0);
                return;
            }

            // Normalize language code (e.g., "te-IN" -> "te", "ta-IN" -> "ta")
            if (lang.contains("-")) {
                lang = lang.split("-")[0].toLowerCase();
            } else if (lang.contains("_")) {
                lang = lang.split("_")[0].toLowerCase();
            }
            if ("zh".equals(lang)) lang = "zh-CN";

            String cacheKey = lang + ":" + text;
            byte[] audioBytes = AUDIO_CACHE.get(cacheKey);

            if (audioBytes == null) {
                audioBytes = synthesizeSpeech(text, lang);
                if (audioBytes != null && audioBytes.length > 0) {
                    if (AUDIO_CACHE.size() < 400) {
                        AUDIO_CACHE.put(cacheKey, audioBytes);
                    }
                }
            }

            if (audioBytes != null && audioBytes.length > 0) {
                exchange.getResponseHeaders().set("Content-Type", "audio/mpeg");
                exchange.getResponseHeaders().set("Cache-Control", "public, max-age=86400");
                exchange.getResponseHeaders().set("Access-Control-Allow-Origin", "*");
                exchange.sendResponseHeaders(200, audioBytes.length);
                try (OutputStream os = exchange.getResponseBody()) {
                    os.write(audioBytes);
                }
            } else {
                HttpHandlerUtil.sendJsonResponse(exchange, 503, Map.of("error", "TTS synthesis failed"));
            }
        } catch (Exception e) {
            e.printStackTrace();
            HttpHandlerUtil.sendJsonResponse(exchange, 500, Map.of("error", e.getMessage()));
        }
    }

    private byte[] synthesizeSpeech(String text, String lang) {
        // Strip markdown stars, hashes, and formatting
        String cleaned = text.replaceAll("[*#_`~>]+", " ")
                             .replaceAll("\\s{2,}", " ")
                             .trim();

        List<String> chunks = splitTextIntoChunks(cleaned, 160);
        ByteArrayOutputStream baos = new ByteArrayOutputStream();

        for (String chunk : chunks) {
            if (chunk.trim().isEmpty()) continue;
            byte[] b = fetchTtsAudioChunk(chunk.trim(), lang);
            if (b != null && b.length > 0) {
                baos.write(b, 0, b.length);
            }
        }

        return baos.toByteArray();
    }

    private byte[] fetchTtsAudioChunk(String chunk, String lang) {
        try {
            String encoded = URLEncoder.encode(chunk, StandardCharsets.UTF_8);
            String urlStr = "https://translate.google.com/translate_tts?ie=UTF-8&tl=" + lang + "&client=tw-ob&q=" + encoded;
            URI uri = URI.create(urlStr);
            HttpURLConnection conn = (HttpURLConnection) uri.toURL().openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36");
            conn.setConnectTimeout(6000);
            conn.setReadTimeout(6000);

            if (conn.getResponseCode() == 200) {
                try (InputStream is = conn.getInputStream(); ByteArrayOutputStream chunkBaos = new ByteArrayOutputStream()) {
                    byte[] buf = new byte[4096];
                    int r;
                    while ((r = is.read(buf)) != -1) {
                        chunkBaos.write(buf, 0, r);
                    }
                    return chunkBaos.toByteArray();
                }
            }
        } catch (Exception e) {
            System.err.println("TTS chunk error for lang " + lang + ": " + e.getMessage());
        }
        return null;
    }

    private List<String> splitTextIntoChunks(String text, int maxLen) {
        List<String> result = new ArrayList<>();
        // Split by punctuation or newlines
        String[] sentences = text.split("(?<=[.!?\\n;।॥])\\s+");
        StringBuilder current = new StringBuilder();

        for (String s : sentences) {
            if (current.length() + s.length() <= maxLen) {
                if (current.length() > 0) current.append(" ");
                current.append(s);
            } else {
                if (current.length() > 0) {
                    result.add(current.toString());
                    current.setLength(0);
                }
                if (s.length() <= maxLen) {
                    current.append(s);
                } else {
                    String[] words = s.split(" ");
                    for (String w : words) {
                        if (current.length() + w.length() + 1 <= maxLen) {
                            if (current.length() > 0) current.append(" ");
                            current.append(w);
                        } else {
                            if (current.length() > 0) {
                                result.add(current.toString());
                                current.setLength(0);
                            }
                            current.append(w);
                        }
                    }
                }
            }
        }
        if (current.length() > 0) {
            result.add(current.toString());
        }
        return result;
    }
}
