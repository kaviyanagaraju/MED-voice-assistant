package com.medvoiceassistant.controller;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.medvoiceassistant.model.MedicalRecord;
import com.medvoiceassistant.server.HttpHandlerUtil;
import com.medvoiceassistant.service.RecordService;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.util.Base64;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public class RecordController implements HttpHandler {
    private final RecordService recordService = new RecordService();

    @Override
    public void handle(HttpExchange exchange) throws IOException {
        String method = exchange.getRequestMethod();
        if ("OPTIONS".equalsIgnoreCase(method)) {
            HttpHandlerUtil.sendCorsPreflightResponse(exchange);
            return;
        }

        String path = exchange.getRequestURI().getPath();

        try {
            if (path.endsWith("/upload") && "POST".equalsIgnoreCase(method)) {
                handleUpload(exchange);
            } else if (path.endsWith("/list") && "GET".equalsIgnoreCase(method)) {
                handleList(exchange);
            } else if (path.endsWith("/file") && "GET".equalsIgnoreCase(method)) {
                handleServeFile(exchange);
            } else if (path.endsWith("/delete") && "POST".equalsIgnoreCase(method)) {
                handleDelete(exchange);
            } else {
                HttpHandlerUtil.sendJsonResponse(exchange, 404, Map.of("error", "Not Found"));
            }
        } catch (Exception e) {
            e.printStackTrace();
            HttpHandlerUtil.sendJsonResponse(exchange, 500, Map.of("error", e.getMessage()));
        }
    }

    private void handleUpload(HttpExchange exchange) throws IOException {
        String body = HttpHandlerUtil.readRequestBody(exchange);
        JsonObject json = JsonParser.parseString(body).getAsJsonObject();

        int userId = json.has("userId") ? json.get("userId").getAsInt() : 1;
        String type = json.has("type") ? json.get("type").getAsString() : "LAB_REPORT";
        String fileName = json.has("fileName") ? json.get("fileName").getAsString() : "document.pdf";
        String description = json.has("description") ? json.get("description").getAsString() : "";
        String base64Data = json.has("fileBase64") ? json.get("fileBase64").getAsString() : "";

        byte[] content;
        if (base64Data != null && !base64Data.isEmpty()) {
            if (base64Data.contains(",")) {
                base64Data = base64Data.split(",", 2)[1];
            }
            content = Base64.getDecoder().decode(base64Data);
        } else {
            content = "Sample Medical Document Content".getBytes();
        }

        MedicalRecord record = recordService.saveFileRecord(userId, type, fileName, content, description);
        HttpHandlerUtil.sendJsonResponse(exchange, 201, Map.of("success", true, "record", record));
    }

    private void handleList(HttpExchange exchange) throws IOException {
        Map<String, String> q = HttpHandlerUtil.parseQueryParams(exchange.getRequestURI().getQuery());
        int userId = Integer.parseInt(q.getOrDefault("userId", "1"));
        List<MedicalRecord> list = recordService.getRecordsByUserId(userId);
        HttpHandlerUtil.sendJsonResponse(exchange, 200, list);
    }

    private void handleServeFile(HttpExchange exchange) throws IOException {
        Map<String, String> q = HttpHandlerUtil.parseQueryParams(exchange.getRequestURI().getQuery());
        int recordId = Integer.parseInt(q.getOrDefault("recordId", "0"));
        Optional<MedicalRecord> recOpt = recordService.getRecordById(recordId);

        if (recOpt.isPresent()) {
            File f = new File(recOpt.get().getFilePath());
            if (f.exists()) {
                String contentType = Files.probeContentType(f.toPath());
                if (contentType == null) contentType = "application/octet-stream";

                exchange.getResponseHeaders().set("Content-Type", contentType);
                exchange.getResponseHeaders().set("Content-Disposition", "inline; filename=\"" + recOpt.get().getFileName() + "\"");
                exchange.sendResponseHeaders(200, f.length());
                try (OutputStream os = exchange.getResponseBody(); FileInputStream fis = new FileInputStream(f)) {
                    byte[] buf = new byte[8192];
                    int r;
                    while ((r = fis.read(buf)) != -1) {
                        os.write(buf, 0, r);
                    }
                }
                return;
            }
        }
        HttpHandlerUtil.sendJsonResponse(exchange, 404, Map.of("error", "File not found"));
    }

    private void handleDelete(HttpExchange exchange) throws IOException {
        String body = HttpHandlerUtil.readRequestBody(exchange);
        JsonObject json = JsonParser.parseString(body).getAsJsonObject();
        int recordId = json.has("recordId") ? json.get("recordId").getAsInt() : 0;
        int userId = json.has("userId") ? json.get("userId").getAsInt() : 1;

        boolean ok = recordService.deleteRecord(recordId, userId);
        HttpHandlerUtil.sendJsonResponse(exchange, 200, Map.of("success", ok));
    }
}
