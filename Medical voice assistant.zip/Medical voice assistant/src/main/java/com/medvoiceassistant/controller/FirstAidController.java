package com.medvoiceassistant.controller;

import com.medvoiceassistant.model.FirstAidGuide;
import com.medvoiceassistant.server.HttpHandlerUtil;
import com.medvoiceassistant.service.FirstAidService;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public class FirstAidController implements HttpHandler {
    private final FirstAidService firstAidService = new FirstAidService();

    @Override
    public void handle(HttpExchange exchange) throws IOException {
        String method = exchange.getRequestMethod();
        if ("OPTIONS".equalsIgnoreCase(method)) {
            HttpHandlerUtil.sendCorsPreflightResponse(exchange);
            return;
        }

        try {
            if ("GET".equalsIgnoreCase(method)) {
                Map<String, String> q = HttpHandlerUtil.parseQueryParams(exchange.getRequestURI().getQuery());
                String scenario = q.get("scenario");
                if (scenario != null && !scenario.isEmpty()) {
                    Optional<FirstAidGuide> guide = firstAidService.getGuideByScenario(scenario);
                    if (guide.isPresent()) {
                        HttpHandlerUtil.sendJsonResponse(exchange, 200, guide.get());
                    } else {
                        HttpHandlerUtil.sendJsonResponse(exchange, 404, Map.of("error", "First aid scenario not found"));
                    }
                } else {
                    List<FirstAidGuide> guides = firstAidService.getAllGuides();
                    HttpHandlerUtil.sendJsonResponse(exchange, 200, guides);
                }
            } else {
                HttpHandlerUtil.sendJsonResponse(exchange, 405, Map.of("error", "Method Not Allowed"));
            }
        } catch (Exception e) {
            e.printStackTrace();
            HttpHandlerUtil.sendJsonResponse(exchange, 500, Map.of("error", e.getMessage()));
        }
    }
}
