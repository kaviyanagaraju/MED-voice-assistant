package com.medvoiceassistant.repository;

import com.medvoiceassistant.database.DatabaseManager;
import com.medvoiceassistant.model.Reminder;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ReminderRepository {
    private final DatabaseManager db = DatabaseManager.getInstance();

    public int saveReminder(Reminder reminder) {
        String sql = """
            INSERT INTO reminder (medication_id, medicine_name, dosage, reminder_time, frequency, active, last_triggered)
            VALUES (?, ?, ?, ?, ?, ?, ?);
        """;
        try (Connection conn = db.getConnection(); PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, reminder.getMedicationId());
            ps.setString(2, reminder.getMedicineName());
            ps.setString(3, reminder.getDosage());
            ps.setString(4, reminder.getReminderTime());
            ps.setString(5, reminder.getFrequency());
            ps.setInt(6, reminder.isActive() ? 1 : 0);
            ps.setString(7, reminder.getLastTriggered());
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    int id = rs.getInt(1);
                    reminder.setReminderId(id);
                    return id;
                }
            }
        } catch (SQLException e) {
            System.err.println("Error saving reminder: " + e.getMessage());
        }
        return -1;
    }

    public List<Reminder> getRemindersByUserId(int userId) {
        List<Reminder> list = new ArrayList<>();
        String sql = """
            SELECT r.reminder_id, r.medication_id, r.medicine_name, r.dosage, r.reminder_time, r.frequency, r.active, r.last_triggered
            FROM reminder r
            JOIN medication m ON r.medication_id = m.medication_id
            WHERE m.user_id = ?
            ORDER BY r.reminder_time ASC;
        """;
        try (Connection conn = db.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(new Reminder(
                        rs.getInt("reminder_id"),
                        rs.getInt("medication_id"),
                        rs.getString("medicine_name"),
                        rs.getString("dosage"),
                        rs.getString("reminder_time"),
                        rs.getString("frequency"),
                        rs.getInt("active") == 1,
                        rs.getString("last_triggered")
                    ));
                }
            }
        } catch (SQLException e) {
            System.err.println("Error getting reminders by user: " + e.getMessage());
        }
        return list;
    }

    public List<Reminder> getAllActiveReminders() {
        List<Reminder> list = new ArrayList<>();
        String sql = """
            SELECT reminder_id, medication_id, medicine_name, dosage, reminder_time, frequency, active, last_triggered
            FROM reminder WHERE active = 1;
        """;
        try (Connection conn = db.getConnection(); PreparedStatement ps = conn.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                list.add(new Reminder(
                    rs.getInt("reminder_id"),
                    rs.getInt("medication_id"),
                    rs.getString("medicine_name"),
                    rs.getString("dosage"),
                    rs.getString("reminder_time"),
                    rs.getString("frequency"),
                    rs.getInt("active") == 1,
                    rs.getString("last_triggered")
                ));
            }
        } catch (SQLException e) {
            System.err.println("Error getting active reminders: " + e.getMessage());
        }
        return list;
    }

    public boolean updateLastTriggered(int reminderId, String timestamp) {
        String sql = "UPDATE reminder SET last_triggered = ? WHERE reminder_id = ?;";
        try (Connection conn = db.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, timestamp);
            ps.setInt(2, reminderId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error updating last triggered: " + e.getMessage());
            return false;
        }
    }

    public boolean toggleActive(int reminderId, boolean active) {
        String sql = "UPDATE reminder SET active = ? WHERE reminder_id = ?;";
        try (Connection conn = db.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, active ? 1 : 0);
            ps.setInt(2, reminderId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error toggling reminder: " + e.getMessage());
            return false;
        }
    }

    public boolean deleteReminder(int reminderId) {
        String sql = "DELETE FROM reminder WHERE reminder_id = ?;";
        try (Connection conn = db.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, reminderId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error deleting reminder: " + e.getMessage());
            return false;
        }
    }
}
