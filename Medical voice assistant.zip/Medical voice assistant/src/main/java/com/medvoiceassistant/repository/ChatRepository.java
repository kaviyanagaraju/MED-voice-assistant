package com.medvoiceassistant.repository;

import com.medvoiceassistant.database.DatabaseManager;
import com.medvoiceassistant.model.ChatMessage;
import com.medvoiceassistant.model.ChatSession;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class ChatRepository {
    private final DatabaseManager db = DatabaseManager.getInstance();

    public int createSession(int userId, String language, String createdAt) {
        String sql = "INSERT INTO chat_session (user_id, language, created_at) VALUES (?, ?, ?);";
        try (Connection conn = db.getConnection(); PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, userId);
            ps.setString(2, language);
            ps.setString(3, createdAt);
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error creating chat session: " + e.getMessage());
        }
        return -1;
    }

    public int saveMessage(ChatMessage msg) {
        String sql = "INSERT INTO chat_message (chat_id, sender, message, intent, created_at) VALUES (?, ?, ?, ?, ?);";
        try (Connection conn = db.getConnection(); PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, msg.getChatId());
            ps.setString(2, msg.getSender());
            ps.setString(3, msg.getMessage());
            ps.setString(4, msg.getIntent());
            ps.setString(5, msg.getCreatedAt());
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    int id = rs.getInt(1);
                    msg.setMessageId(id);
                    return id;
                }
            }
        } catch (SQLException e) {
            System.err.println("Error saving chat message: " + e.getMessage());
        }
        return -1;
    }

    public List<ChatMessage> getMessagesByChatId(int chatId) {
        List<ChatMessage> list = new ArrayList<>();
        String sql = "SELECT message_id, chat_id, sender, message, intent, created_at FROM chat_message WHERE chat_id = ? ORDER BY message_id ASC;";
        try (Connection conn = db.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, chatId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(new ChatMessage(
                        rs.getInt("message_id"),
                        rs.getInt("chat_id"),
                        rs.getString("sender"),
                        rs.getString("message"),
                        rs.getString("intent"),
                        rs.getString("created_at")
                    ));
                }
            }
        } catch (SQLException e) {
            System.err.println("Error getting chat messages: " + e.getMessage());
        }
        return list;
    }

    public Optional<ChatSession> getLatestSessionForUser(int userId) {
        String sql = "SELECT chat_id, user_id, language, created_at FROM chat_session WHERE user_id = ? ORDER BY chat_id DESC LIMIT 1;";
        try (Connection conn = db.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    ChatSession cs = new ChatSession(
                        rs.getInt("chat_id"),
                        rs.getInt("user_id"),
                        rs.getString("language"),
                        rs.getString("created_at")
                    );
                    cs.setMessages(getMessagesByChatId(cs.getChatId()));
                    return Optional.of(cs);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error getting latest chat session: " + e.getMessage());
        }
        return Optional.empty();
    }
}
