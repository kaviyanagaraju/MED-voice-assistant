package com.medvoiceassistant.repository;

import com.medvoiceassistant.database.DatabaseManager;
import com.medvoiceassistant.model.FirstAidGuide;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class FirstAidRepository {
    private final DatabaseManager db = DatabaseManager.getInstance();

    public List<FirstAidGuide> getAllGuides() {
        List<FirstAidGuide> list = new ArrayList<>();
        String sql = "SELECT guide_id, scenario, title, language, steps, red_flags, escalation FROM first_aid_guide ORDER BY guide_id ASC;";
        try (Connection conn = db.getConnection(); PreparedStatement ps = conn.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                list.add(new FirstAidGuide(
                    rs.getInt("guide_id"),
                    rs.getString("scenario"),
                    rs.getString("title"),
                    rs.getString("language"),
                    rs.getString("steps"),
                    rs.getString("red_flags"),
                    rs.getString("escalation")
                ));
            }
        } catch (SQLException e) {
            System.err.println("Error getting all first aid guides: " + e.getMessage());
        }
        return list;
    }

    public Optional<FirstAidGuide> getByScenario(String scenario) {
        String sql = "SELECT guide_id, scenario, title, language, steps, red_flags, escalation FROM first_aid_guide WHERE scenario = ? LIMIT 1;";
        try (Connection conn = db.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, scenario);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(new FirstAidGuide(
                        rs.getInt("guide_id"),
                        rs.getString("scenario"),
                        rs.getString("title"),
                        rs.getString("language"),
                        rs.getString("steps"),
                        rs.getString("red_flags"),
                        rs.getString("escalation")
                    ));
                }
            }
        } catch (SQLException e) {
            System.err.println("Error getting first aid guide by scenario: " + e.getMessage());
        }
        return Optional.empty();
    }
}
