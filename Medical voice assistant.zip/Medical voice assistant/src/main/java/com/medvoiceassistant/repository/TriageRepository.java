package com.medvoiceassistant.repository;

import com.medvoiceassistant.database.DatabaseManager;
import com.medvoiceassistant.model.TriageResult;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class TriageRepository {
    private final DatabaseManager db = DatabaseManager.getInstance();

    public int saveTriageResult(TriageResult result) {
        String sql = """
            INSERT INTO triage_result (session_id, urgency, recommendation, department, reason, rule_matched, confidence_score, speech_response, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?);
        """;
        try (Connection conn = db.getConnection(); PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, result.getSessionId());
            ps.setString(2, result.getUrgency());
            ps.setString(3, result.getRecommendation());
            ps.setString(4, result.getDepartment());
            ps.setString(5, result.getReason());
            ps.setString(6, result.getRuleMatched());
            ps.setDouble(7, result.getConfidenceScore());
            ps.setString(8, result.getSpeechResponse());
            ps.setString(9, result.getCreatedAt());
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    int id = rs.getInt(1);
                    result.setResultId(id);
                    return id;
                }
            }
        } catch (SQLException e) {
            System.err.println("Error saving triage result: " + e.getMessage());
        }
        return -1;
    }

    public Optional<TriageResult> getBySessionId(int sessionId) {
        String sql = """
            SELECT result_id, session_id, urgency, recommendation, department, reason, rule_matched, confidence_score, speech_response, created_at
            FROM triage_result WHERE session_id = ?;
        """;
        try (Connection conn = db.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, sessionId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    TriageResult tr = new TriageResult(
                        rs.getString("urgency"),
                        rs.getString("recommendation"),
                        rs.getString("department"),
                        rs.getString("reason"),
                        rs.getString("rule_matched"),
                        rs.getDouble("confidence_score"),
                        rs.getString("speech_response")
                    );
                    tr.setResultId(rs.getInt("result_id"));
                    tr.setSessionId(rs.getInt("session_id"));
                    tr.setCreatedAt(rs.getString("created_at"));
                    return Optional.of(tr);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error getting triage result by session: " + e.getMessage());
        }
        return Optional.empty();
    }

    public List<TriageResult> getTriageHistoryByUserId(int userId) {
        List<TriageResult> list = new ArrayList<>();
        String sql = """
            SELECT tr.result_id, tr.session_id, tr.urgency, tr.recommendation, tr.department, tr.reason, tr.rule_matched, tr.confidence_score, tr.speech_response, tr.created_at
            FROM triage_result tr
            JOIN symptom_session ss ON tr.session_id = ss.session_id
            WHERE ss.user_id = ?
            ORDER BY tr.result_id DESC;
        """;
        try (Connection conn = db.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    TriageResult tr = new TriageResult(
                        rs.getString("urgency"),
                        rs.getString("recommendation"),
                        rs.getString("department"),
                        rs.getString("reason"),
                        rs.getString("rule_matched"),
                        rs.getDouble("confidence_score"),
                        rs.getString("speech_response")
                    );
                    tr.setResultId(rs.getInt("result_id"));
                    tr.setSessionId(rs.getInt("session_id"));
                    tr.setCreatedAt(rs.getString("created_at"));
                    list.add(tr);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error getting triage history: " + e.getMessage());
        }
        return list;
    }
}
