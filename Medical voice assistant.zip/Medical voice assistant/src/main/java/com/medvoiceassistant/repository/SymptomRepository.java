package com.medvoiceassistant.repository;

import com.medvoiceassistant.database.DatabaseManager;
import com.medvoiceassistant.model.Symptom;
import com.medvoiceassistant.model.SymptomSession;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class SymptomRepository {
    private final DatabaseManager db = DatabaseManager.getInstance();

    public int saveSession(SymptomSession session) {
        String sql = "INSERT INTO symptom_session (user_id, input_text, language, created_at) VALUES (?, ?, ?, ?);";
        try (Connection conn = db.getConnection(); PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, session.getUserId());
            ps.setString(2, session.getInputText());
            ps.setString(3, session.getLanguage());
            ps.setString(4, session.getCreatedAt());
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    int sessionId = rs.getInt(1);
                    session.setSessionId(sessionId);
                    // Save extracted symptoms
                    for (Symptom s : session.getSymptoms()) {
                        saveSymptom(conn, sessionId, s);
                    }
                    return sessionId;
                }
            }
        } catch (SQLException e) {
            System.err.println("Error saving symptom session: " + e.getMessage());
        }
        return -1;
    }

    private void saveSymptom(Connection conn, int sessionId, Symptom s) throws SQLException {
        String sql = """
            INSERT INTO symptom (session_id, name, severity, duration_days, body_part, is_red_flag)
            VALUES (?, ?, ?, ?, ?, ?);
        """;
        try (PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, sessionId);
            ps.setString(2, s.getName());
            ps.setString(3, s.getSeverity());
            ps.setInt(4, s.getDurationDays());
            ps.setString(5, s.getBodyPart());
            ps.setInt(6, s.isRedFlag() ? 1 : 0);
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    s.setSymptomId(rs.getInt(1));
                    s.setSessionId(sessionId);
                }
            }
        }
    }

    public List<Symptom> getSymptomsBySessionId(int sessionId) {
        List<Symptom> list = new ArrayList<>();
        String sql = "SELECT symptom_id, session_id, name, severity, duration_days, body_part, is_red_flag FROM symptom WHERE session_id = ?;";
        try (Connection conn = db.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, sessionId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Symptom s = new Symptom(
                        rs.getString("name"),
                        rs.getString("severity"),
                        rs.getInt("duration_days"),
                        rs.getString("body_part"),
                        rs.getInt("is_red_flag") == 1
                    );
                    s.setSymptomId(rs.getInt("symptom_id"));
                    s.setSessionId(rs.getInt("session_id"));
                    list.add(s);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error getting symptoms: " + e.getMessage());
        }
        return list;
    }

    public List<SymptomSession> getSessionsByUserId(int userId) {
        List<SymptomSession> list = new ArrayList<>();
        String sql = "SELECT session_id, user_id, input_text, language, created_at FROM symptom_session WHERE user_id = ? ORDER BY session_id DESC;";
        try (Connection conn = db.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    SymptomSession session = new SymptomSession(
                        rs.getInt("session_id"),
                        rs.getInt("user_id"),
                        rs.getString("input_text"),
                        rs.getString("language"),
                        rs.getString("created_at")
                    );
                    session.setSymptoms(getSymptomsBySessionId(session.getSessionId()));
                    list.add(session);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error getting symptom sessions: " + e.getMessage());
        }
        return list;
    }

    public Optional<SymptomSession> getSessionById(int sessionId) {
        String sql = "SELECT session_id, user_id, input_text, language, created_at FROM symptom_session WHERE session_id = ?;";
        try (Connection conn = db.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, sessionId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    SymptomSession session = new SymptomSession(
                        rs.getInt("session_id"),
                        rs.getInt("user_id"),
                        rs.getString("input_text"),
                        rs.getString("language"),
                        rs.getString("created_at")
                    );
                    session.setSymptoms(getSymptomsBySessionId(sessionId));
                    return Optional.of(session);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error getting session by id: " + e.getMessage());
        }
        return Optional.empty();
    }
}
