package com.medvoiceassistant.repository;

import com.medvoiceassistant.database.DatabaseManager;
import com.medvoiceassistant.model.FoodPlan;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class FoodPlanRepository {
    private final DatabaseManager db = DatabaseManager.getInstance();

    public int saveFoodPlan(FoodPlan plan) {
        String sql = """
            INSERT INTO food_plan (user_id, query, meal_type, plan_text, calories_target, dietary_advice, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?);
        """;
        try (Connection conn = db.getConnection(); PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, plan.getUserId());
            ps.setString(2, plan.getQuery());
            ps.setString(3, plan.getMealType());
            ps.setString(4, plan.getPlanText());
            ps.setInt(5, plan.getCaloriesTarget());
            ps.setString(6, plan.getDietaryAdvice());
            ps.setString(7, plan.getCreatedAt());
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    int id = rs.getInt(1);
                    plan.setPlanId(id);
                    return id;
                }
            }
        } catch (SQLException e) {
            System.err.println("Error saving food plan: " + e.getMessage());
        }
        return -1;
    }

    public List<FoodPlan> getPlansByUserId(int userId) {
        List<FoodPlan> list = new ArrayList<>();
        String sql = """
            SELECT plan_id, user_id, query, meal_type, plan_text, calories_target, dietary_advice, created_at
            FROM food_plan WHERE user_id = ? ORDER BY plan_id DESC;
        """;
        try (Connection conn = db.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(new FoodPlan(
                        rs.getInt("plan_id"),
                        rs.getInt("user_id"),
                        rs.getString("query"),
                        rs.getString("meal_type"),
                        rs.getString("plan_text"),
                        rs.getInt("calories_target"),
                        rs.getString("dietary_advice"),
                        rs.getString("created_at")
                    ));
                }
            }
        } catch (SQLException e) {
            System.err.println("Error getting food plans: " + e.getMessage());
        }
        return list;
    }
}
