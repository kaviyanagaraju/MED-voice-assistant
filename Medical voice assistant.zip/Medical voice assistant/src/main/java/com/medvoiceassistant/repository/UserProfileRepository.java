package com.medvoiceassistant.repository;

import com.medvoiceassistant.database.DatabaseManager;
import com.medvoiceassistant.model.UserProfile;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Optional;

public class UserProfileRepository {
    private final DatabaseManager db = DatabaseManager.getInstance();

    public Optional<UserProfile> findByUserId(int userId) {
        String sql = """
            SELECT profile_id, user_id, name, gender, age, height, weight, blood_group, emergency_contact, contact_phone
            FROM user_profile WHERE user_id = ?;
        """;
        try (Connection conn = db.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(new UserProfile(
                        rs.getInt("profile_id"),
                        rs.getInt("user_id"),
                        rs.getString("name"),
                        rs.getString("gender"),
                        rs.getInt("age"),
                        rs.getDouble("height"),
                        rs.getDouble("weight"),
                        rs.getString("blood_group"),
                        rs.getString("emergency_contact"),
                        rs.getString("contact_phone")
                    ));
                }
            }
        } catch (SQLException e) {
            System.err.println("Error finding profile by userId: " + e.getMessage());
        }
        return Optional.empty();
    }

    public boolean saveOrUpdate(UserProfile profile) {
        Optional<UserProfile> existing = findByUserId(profile.getUserId());
        if (existing.isPresent()) {
            String updateSql = """
                UPDATE user_profile
                SET name = ?, gender = ?, age = ?, height = ?, weight = ?, blood_group = ?, emergency_contact = ?, contact_phone = ?
                WHERE user_id = ?;
            """;
            try (Connection conn = db.getConnection(); PreparedStatement ps = conn.prepareStatement(updateSql)) {
                ps.setString(1, profile.getName());
                ps.setString(2, profile.getGender());
                ps.setInt(3, profile.getAge());
                ps.setDouble(4, profile.getHeight());
                ps.setDouble(5, profile.getWeight());
                ps.setString(6, profile.getBloodGroup());
                ps.setString(7, profile.getEmergencyContact());
                ps.setString(8, profile.getContactPhone());
                ps.setInt(9, profile.getUserId());
                return ps.executeUpdate() > 0;
            } catch (SQLException e) {
                System.err.println("Error updating profile: " + e.getMessage());
                return false;
            }
        } else {
            String insertSql = """
                INSERT INTO user_profile (user_id, name, gender, age, height, weight, blood_group, emergency_contact, contact_phone)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?);
            """;
            try (Connection conn = db.getConnection(); PreparedStatement ps = conn.prepareStatement(insertSql)) {
                ps.setInt(1, profile.getUserId());
                ps.setString(2, profile.getName());
                ps.setString(3, profile.getGender());
                ps.setInt(4, profile.getAge());
                ps.setDouble(5, profile.getHeight());
                ps.setDouble(6, profile.getWeight());
                ps.setString(7, profile.getBloodGroup());
                ps.setString(8, profile.getEmergencyContact());
                ps.setString(9, profile.getContactPhone());
                return ps.executeUpdate() > 0;
            } catch (SQLException e) {
                System.err.println("Error inserting profile: " + e.getMessage());
                return false;
            }
        }
    }
}
