package com.medvoiceassistant.repository;

import com.medvoiceassistant.database.DatabaseManager;
import com.medvoiceassistant.model.Medication;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class MedicationRepository {
    private final DatabaseManager db = DatabaseManager.getInstance();

    public int saveMedication(Medication med) {
        String sql = """
            INSERT INTO medication (user_id, medicine_name, dosage, frequency, instructions, created_at)
            VALUES (?, ?, ?, ?, ?, ?);
        """;
        try (Connection conn = db.getConnection(); PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, med.getUserId());
            ps.setString(2, med.getMedicineName());
            ps.setString(3, med.getDosage());
            ps.setString(4, med.getFrequency());
            ps.setString(5, med.getInstructions());
            ps.setString(6, med.getCreatedAt());
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    int id = rs.getInt(1);
                    med.setMedicationId(id);
                    return id;
                }
            }
        } catch (SQLException e) {
            System.err.println("Error saving medication: " + e.getMessage());
        }
        return -1;
    }

    public List<Medication> getMedicationsByUserId(int userId) {
        List<Medication> list = new ArrayList<>();
        String sql = """
            SELECT medication_id, user_id, medicine_name, dosage, frequency, instructions, created_at
            FROM medication WHERE user_id = ? ORDER BY medication_id DESC;
        """;
        try (Connection conn = db.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(new Medication(
                        rs.getInt("medication_id"),
                        rs.getInt("user_id"),
                        rs.getString("medicine_name"),
                        rs.getString("dosage"),
                        rs.getString("frequency"),
                        rs.getString("instructions"),
                        rs.getString("created_at")
                    ));
                }
            }
        } catch (SQLException e) {
            System.err.println("Error getting medications: " + e.getMessage());
        }
        return list;
    }

    public Optional<Medication> getById(int medicationId) {
        String sql = """
            SELECT medication_id, user_id, medicine_name, dosage, frequency, instructions, created_at
            FROM medication WHERE medication_id = ?;
        """;
        try (Connection conn = db.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, medicationId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(new Medication(
                        rs.getInt("medication_id"),
                        rs.getInt("user_id"),
                        rs.getString("medicine_name"),
                        rs.getString("dosage"),
                        rs.getString("frequency"),
                        rs.getString("instructions"),
                        rs.getString("created_at")
                    ));
                }
            }
        } catch (SQLException e) {
            System.err.println("Error getting medication by id: " + e.getMessage());
        }
        return Optional.empty();
    }

    public boolean deleteMedication(int medicationId, int userId) {
        String sql = "DELETE FROM medication WHERE medication_id = ? AND user_id = ?;";
        try (Connection conn = db.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, medicationId);
            ps.setInt(2, userId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error deleting medication: " + e.getMessage());
            return false;
        }
    }
}
