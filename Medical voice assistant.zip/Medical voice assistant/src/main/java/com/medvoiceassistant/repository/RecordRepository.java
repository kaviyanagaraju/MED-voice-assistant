package com.medvoiceassistant.repository;

import com.medvoiceassistant.database.DatabaseManager;
import com.medvoiceassistant.model.MedicalRecord;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class RecordRepository {
    private final DatabaseManager db = DatabaseManager.getInstance();

    public int saveRecord(MedicalRecord record) {
        String sql = """
            INSERT INTO medical_record (user_id, type, file_name, file_path, file_size, upload_date, description)
            VALUES (?, ?, ?, ?, ?, ?, ?);
        """;
        try (Connection conn = db.getConnection(); PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, record.getUserId());
            ps.setString(2, record.getType());
            ps.setString(3, record.getFileName());
            ps.setString(4, record.getFilePath());
            ps.setLong(5, record.getFileSize());
            ps.setString(6, record.getUploadDate());
            ps.setString(7, record.getDescription());
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    int id = rs.getInt(1);
                    record.setRecordId(id);
                    return id;
                }
            }
        } catch (SQLException e) {
            System.err.println("Error saving medical record: " + e.getMessage());
        }
        return -1;
    }

    public List<MedicalRecord> getRecordsByUserId(int userId) {
        List<MedicalRecord> list = new ArrayList<>();
        String sql = """
            SELECT record_id, user_id, type, file_name, file_path, file_size, upload_date, description
            FROM medical_record WHERE user_id = ? ORDER BY record_id DESC;
        """;
        try (Connection conn = db.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(new MedicalRecord(
                        rs.getInt("record_id"),
                        rs.getInt("user_id"),
                        rs.getString("type"),
                        rs.getString("file_name"),
                        rs.getString("file_path"),
                        rs.getLong("file_size"),
                        rs.getString("upload_date"),
                        rs.getString("description")
                    ));
                }
            }
        } catch (SQLException e) {
            System.err.println("Error getting medical records: " + e.getMessage());
        }
        return list;
    }

    public Optional<MedicalRecord> getRecordById(int recordId) {
        String sql = """
            SELECT record_id, user_id, type, file_name, file_path, file_size, upload_date, description
            FROM medical_record WHERE record_id = ?;
        """;
        try (Connection conn = db.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, recordId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(new MedicalRecord(
                        rs.getInt("record_id"),
                        rs.getInt("user_id"),
                        rs.getString("type"),
                        rs.getString("file_name"),
                        rs.getString("file_path"),
                        rs.getLong("file_size"),
                        rs.getString("upload_date"),
                        rs.getString("description")
                    ));
                }
            }
        } catch (SQLException e) {
            System.err.println("Error getting medical record by id: " + e.getMessage());
        }
        return Optional.empty();
    }

    public boolean deleteRecord(int recordId, int userId) {
        String sql = "DELETE FROM medical_record WHERE record_id = ? AND user_id = ?;";
        try (Connection conn = db.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, recordId);
            ps.setInt(2, userId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error deleting medical record: " + e.getMessage());
            return false;
        }
    }
}
