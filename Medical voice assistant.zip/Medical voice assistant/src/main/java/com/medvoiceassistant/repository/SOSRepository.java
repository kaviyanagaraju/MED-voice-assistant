package com.medvoiceassistant.repository;

import com.medvoiceassistant.database.DatabaseManager;
import com.medvoiceassistant.model.SOSEvent;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SOSRepository {
    private final DatabaseManager db = DatabaseManager.getInstance();

    public int saveEvent(SOSEvent event) {
        String sql = """
            INSERT INTO sos_event (user_id, timestamp, location, contact, phone, status, notes)
            VALUES (?, ?, ?, ?, ?, ?, ?);
        """;
        try (Connection conn = db.getConnection(); PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, event.getUserId());
            ps.setString(2, event.getTimestamp());
            ps.setString(3, event.getLocation());
            ps.setString(4, event.getContact());
            ps.setString(5, event.getPhone());
            ps.setString(6, event.getStatus());
            ps.setString(7, event.getNotes());
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    int id = rs.getInt(1);
                    event.setSosId(id);
                    return id;
                }
            }
        } catch (SQLException e) {
            System.err.println("Error saving SOS event: " + e.getMessage());
        }
        return -1;
    }

    public List<SOSEvent> getEventsByUserId(int userId) {
        List<SOSEvent> list = new ArrayList<>();
        String sql = """
            SELECT sos_id, user_id, timestamp, location, contact, phone, status, notes
            FROM sos_event WHERE user_id = ? ORDER BY sos_id DESC;
        """;
        try (Connection conn = db.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(new SOSEvent(
                        rs.getInt("sos_id"),
                        rs.getInt("user_id"),
                        rs.getString("timestamp"),
                        rs.getString("location"),
                        rs.getString("contact"),
                        rs.getString("phone"),
                        rs.getString("status"),
                        rs.getString("notes")
                    ));
                }
            }
        } catch (SQLException e) {
            System.err.println("Error getting SOS events: " + e.getMessage());
        }
        return list;
    }
}
