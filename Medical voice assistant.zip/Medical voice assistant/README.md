# MediVoice AI — AI-Powered Voice Assistant for Automated Medical Symptom Triage and Patient Care Support

**Course:** Application Programming Practices (APP)  
**Domain:** Healthcare / Artificial Intelligence / Voice Computing  
**Team Members:**  
- **Priyadharshini M** — RA2511026050160  
- **Kaviyadharshini N** — RA2511026050168  

---

## 📌 Executive Summary & Problem Addressed
Access to timely and accurate preliminary medical guidance remains a significant challenge in healthcare settings. Patients often struggle to evaluate symptom urgency, leading to unnecessary emergency room visits for minor ailments or dangerous delays when urgent care is needed. This is compounded for elderly patients or individuals with limited literacy who find text-based apps difficult.

**MediVoice AI** is a modular, standalone, Java-based medical voice assistant that provides:
1. **Voice-Driven Symptom Intake:** Speak naturally in multiple languages (English, Tamil, Hindi, Spanish, French, German) with real-time waveform visualization.
2. **Clinical Symptom Parser:** Extracts medical keywords, body parts, duration, severity, and red-flag risk factors.
3. **Automated Triage Engine:** Classifies cases into **EMERGENCY**, **MODERATE**, **SELF-CARE**, or **UNCERTAIN/FOLLOW-UP** using transparent, explainable clinical guideline rules and confidence scoring.
4. **Specialty Department Routing:** Recommends appropriate medical departments (Cardiology, Neurology, Pulmonology, Gastroenterology, Orthopedics, General Medicine).
5. **Text-to-Speech (TTS) Synthesis:** Delivers clear, conversational spoken medical guidance back to the patient.
6. **Medication & Voice Reminders:** Daemon scheduler runs in the background and delivers spoken voice alerts at scheduled times.
7. **Conversational Medical Chatbot:** Handles health Q&A, dietary questions, and immediate emergency redirection.
8. **Validated First-Aid Guides:** Step-by-step guidance for minor cuts, burns, nosebleeds, sprains (R.I.C.E.), choking (Heimlich), fainting, and insect stings with red-flag escalation.
9. **Instant SOS Emergency Workflow:** High-visibility emergency trigger with safety countdown, GPS coordinate sharing, and emergency hotline (108/911/112) integration.
10. **Medical Records & Scans:** Secure archive for lab reports, doctor prescriptions, and X-Ray/CT/MRI scans.
11. **Longitudinal Patient History:** Complete interaction timeline formatted for doctor consultation.

---

## 🏛️ System Architecture

```
+-------------------------------------------------------------------------+
|                           Presentation Layer                            |
|  - Modern Web Dashboard (HTML5, Vanilla CSS, Responsive Glassmorphism)   |
|  - Web Speech API (Microphone Speech-to-Text & Spoken Audio Synthesis)  |
|  - Animated Audio Waveform & Pulse Indicators                           |
+-------------------------------------------------------------------------+
                                    │  HTTP / REST API (Port 8080)
                                    ▼
+-------------------------------------------------------------------------+
|                  Java Application & Controller Layer                    |
|  - MedicalVoiceAssistantServer (Embedded HttpServer)                    |
|  - AuthController, TriageController, ChatbotController                 |
|  - FoodPlanController, FirstAidController, SOSController                |
|  - MedicationController, RecordController, HistoryController            |
+-------------------------------------------------------------------------+
                                    │
                                    ▼
+-------------------------------------------------------------------------+
|                          Service Layer (Logic)                          |
|  - TriageService (Clinical Decision Rules & Confidence Scorer)          |
|  - SpeechService (Natural Spoken Diagnosis Synthesis)                   |
|  - LanguageService (Multilingual Script Detection & Routing)            |
|  - ChatbotService (Conversational Health & Intent Routing)              |
|  - FoodPlanService (Personalized Nutrition & BMI Targeting)             |
|  - FirstAidService (Validated Clinical First-Aid Retrieval)             |
|  - ReminderService (ScheduledExecutorService Background Daemon)         |
|  - SOSService (Emergency Dispatch & Coordinate Broadcasting)            |
|  - RecordService (Document & Scan File Storage)                         |
+-------------------------------------------------------------------------+
                                    │
                                    ▼
+-------------------------------------------------------------------------+
|                     Repository & Persistence Layer                      |
|  - UserRepository, UserProfileRepository, SymptomRepository             |
|  - TriageRepository, ChatRepository, FoodPlanRepository                 |
|  - FirstAidRepository, SOSRepository, MedicationRepository              |
|  - ReminderRepository, RecordRepository                                 |
+-------------------------------------------------------------------------+
                                    │  JDBC
                                    ▼
+-------------------------------------------------------------------------+
|                        SQLite Database (medical.db)                     |
|  - 13 Normalized Tables with WAL mode & Foreign Keys enabled             |
+-------------------------------------------------------------------------+
```

---

## 🗄️ Database Design (13 Tables)

1. `users` — Authentication credentials & account metadata.
2. `user_profile` — Patient vitals: Name, Gender, Age, Height, Weight, Blood Group, Emergency Contact, Phone.
3. `symptom_session` — User voice/text interaction sessions.
4. `symptom` — Extracted clinical entities (name, severity, duration, body part, red-flag status).
5. `triage_result` — Urgency level, recommendation, department, rule matched, confidence, spoken text.
6. `chat_session` — Chatbot interaction sessions.
7. `chat_message` — Chat history with intent classification tags.
8. `food_plan` — Nutritional suggestions, target calories, and advice.
9. `medical_record` — Uploaded lab reports, prescriptions, and imaging scans.
10. `first_aid_guide` — Validated clinical protocols and red-flag triggers.
11. `sos_event` — Emergency distress events with GPS coordinates.
12. `medication` — Prescribed drugs, dosage, and frequency.
13. `reminder` — Active reminder schedules and last-triggered timestamps.

---

## ☕ Where Did We Use Java? (Viva & Evaluation Defense)

Java is the **core backbone** of MediVoice AI:
- **Object-Oriented Design:** Encapsulation in entity models (`User`, `UserProfile`, `Symptom`, `TriageResult`, `Medication`, `Reminder`), clean abstraction through service interfaces, and modular repositories.
- **Embedded Web Server:** Pure Java `com.sun.net.httpserver.HttpServer` on port 8080 with multi-threaded request execution.
- **Decision Engine:** Java-driven clinical rule evaluation matrix verifying cardiac, neurological, respiratory, and surgical red flags with explainable reasoning traces.
- **JDBC Persistence:** Direct SQL query execution, transaction management, connection reuse, and schema migration via SQLite JDBC.
- **Background Daemon Concurrency:** `ScheduledExecutorService` running every 30 seconds to monitor medication schedules and dispatch voice alerts.
- **File Management:** Safe streaming and storage of medical scans and reports.

---

## 🚀 How to Run the Application

### Prerequisites:
- Java JDK 21 or later installed (OpenJDK 25 tested).

### Method 1: One-Click Windows Launch
Double-click `run.bat` or run in terminal:
```powershell
.\run.bat
```

### Method 2: Recompile & Run
```powershell
.\build.bat
```

### Method 3: Direct Java Command
```powershell
java -cp "bin;lib/*" com.medvoiceassistant.Main
```

Once started, open your web browser at:
👉 **`http://localhost:8080/`**

---

## 🧪 Testing the Clinical Triage Scenarios

1. **Cardiac Emergency:** Select preset *"Severe chest pressure radiating to left arm & shortness of breath"* ➡️ **EMERGENCY** (Cardiology & Emergency Medicine) with immediate 108 dial guidance.
2. **Stroke Emergency:** Select preset *"Slurred speech and facial drooping on right side"* ➡️ **EMERGENCY** (Neurology / FAST protocol).
3. **Moderate Respiratory:** Select preset *"High fever with productive phlegm cough for 3 days"* ➡️ **MODERATE** (Pulmonology).
4. **Self-Care:** Select preset *"Mild dry cough and runny nose since yesterday, no fever"* ➡️ **SELF-CARE** (General Medicine / Home Care).
5. **Medication Voice Alert:** Click **"Test Voice Alert Now"** in the Medications tab to verify real-time voice speech synthesis and desktop toast alert!
