@echo off
echo Starting AI Medical Voice Assistant...
java -cp "bin;lib/*" com.medvoiceassistant.Main
pause
